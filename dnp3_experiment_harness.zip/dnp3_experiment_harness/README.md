# DNP3 Experiment Harness

A reproducible, scriptable harness for generating controlled DNP3 READ/RESPONSE
traffic, capturing PCAPs, extracting raw response bytes, replaying them
(verbatim and split across TCP writes), mapping DNP3 header fields, and
analyzing TCP ACK behavior.

It is built on `pydnp3` (OpenDNP3 bindings).

## Quick Start — No-IP Short Commands

All lab settings (IPs, port, DNP3 link addresses, default payload, split mode)
live in **`lab_config.py`**. Edit that one file if the lab roles change; you
never type an IP in a command. Three short runners cover the whole experiment —
each is a thin wrapper over the reusable classes and works with no arguments:

```bash
python run_outstation.py   # baseline: start the real outstation (large DB)
python run_master.py       # send one READ (baseline OR replay/split phase)
python split_server.py     # replay/split: replace the outstation, serve captured bytes
```

**Baseline phase** (master <-> real outstation):

```bash
# outstation host
python run_outstation.py
# master host
python run_master.py        # baseline -> logs/master/baseline_soe.csv
```

**Replay / split phase** (split server replaces the outstation at its IP:port):

```bash
# outstation host: free the port, then serve the captured response
sudo fuser -k 20000/tcp
python split_server.py      # crc-boundary split by default; bytes preserved exactly
# master host (same command as baseline -- it cannot tell the difference)
python run_master.py
```

Default split mode is **`crc-boundary`**: the captured stream is cut only on
existing DNP3 CRC block boundaries, so every chunk ends on an already-valid CRC —
no CRC is recomputed and `b"".join(chunks) == original`. The split server holds
the socket open after sending and logs any follow-up DNP3 CONFIRM.

Convenience wrappers (also no-IP, reading `lab_config.py`):

```bash
python extract_payloads.py  # PCAP -> payloads/baseline/*.bin + metadata.json
python map_response.py      # decode DNP3 header fields -> reports/field_map_results.md
python analyze_ack.py       # TCP ACK/timing fingerprint -> reports/tcp_ack_*.csv
```

The longer `--flag` commands in the sections below still work and override the
config defaults (the runners forward any extra arguments to the underlying CLI).

## 1. Purpose

Experimentally answer, in order:

1. Can we generate clean, controlled DNP3 READ/RESPONSE traffic?
2. Can we scale the outstation database to force larger responses?
3. Does OpenDNP3 naturally split large responses into multiple TCP payloads or
   DNP3 frames?
4. Can we capture and extract the raw DNP3 TCP payload bytes?
5. Can a plain TCP socket replay server send captured responses back to the
   OpenDNP3 master?
6. Can the same response be delivered in multiple TCP writes without breaking
   the master?
7. What fields are needed later for true DNP3-aware splitting and padding?

This is a **protocol experiment harness**, not a final obfuscation
implementation, and not a P4 project.

## 2. Why It Is General (Not Project-Branded)

The harness uses neutral, descriptive names and carries no project-specific
branding so it can serve as a general DNP3 protocol lab. All active Python
sources live in a single flat folder (`dnp3_experiment_harness/`) and share one
configuration file, `lab_config.py`.

## 3. Install

```bash
pip install -r requirements.txt
```

`pydnp3` is a native extension (OpenDNP3 bindings); `scapy` is used by the PCAP
tools. The argparse `--help` of the replay/analysis scripts works even without
`pydnp3` installed (heavy imports are deferred until after argument parsing).
`run_master.py` and `run_outstation.py` import `pydnp3` at load, so those two
require the native extension. `split_server.py` is a plain TCP socket server and
needs **no** pydnp3 (it imports only `lab_config.py`).

## Layout

All active Python sources are in this one flat folder and read their settings
from the single `lab_config.py` (no IPs are ever typed in commands).

```
lab_config.py                  single source of truth for all lab settings
run_master.py                  master (ExperimentMaster + visitors + per-phase CSV SOE)
run_outstation.py              outstation (ExperimentOutstation + command handler)
split_server.py                canonical replay/split server (--delivery full|crc-boundary; no pydnp3)
extract_payloads.py            PCAP -> raw DNP3 payloads + metadata.json (no-IP; flags override)
map_response.py                decode DNP3 header fields -> reports/ (no-IP; flags override)
analyze_ack.py                 TCP ACK behavior analyzer -> reports/ (no-IP; flags override)
dnp3_crc.py                    CRC-16/DNP helpers (used by map_response.py)
docs/                  implementation_guide.md (the governing spec)
payloads/              extracted raw DNP3 bytes (baseline / from_live / replay)
trace/                 PCAP traces (see trace/README.md)
trace/before_split/      native, un-split capture: master + outstation side, ground truth
trace/split/             the CRC-boundary split capture + blocks-per-chunk sweep
reports/               results write-ups + ACK-fingerprint CSVs
```

`split_server.py` is the single replay/split server: `--delivery full` is exact
verbatim replay, `--delivery crc-boundary` (default) is the byte-preserving CRC
split. Run-time output (`logs/` with the per-phase SOE CSVs) is created on first
run.

## 3. Run the Outstation

No-IP runner (settings from `lab_config.py`):

```bash
python run_outstation.py
```

Or with explicit flags (the runner forwards them):

```bash
python run_outstation.py \
  --host 0.0.0.0 --port 20000 --local-addr 10 --remote-addr 1 \
  --db-size 20 --num-analog 5 --num-binary 5 --num-counter 0 \
  --log-dir logs/outstation
```

Defaults are safety-first: **unsolicited responses OFF** and **controls
rejected** (`NOT_SUPPORTED`) unless `--allow-unsolicited` / `--allow-controls`
are passed. A no-arg run applies initial values and holds until Ctrl+C; pass
`--no-apply-initial-values` / `--no-hold` to change that.

## 4. Run the Master

No-IP runner (settings from `lab_config.py`):

```bash
python run_master.py        # baseline -> logs/master/baseline_soe.csv
```

Or with explicit flags:

```bash
python run_master.py \
  --host <OUTSTATION_IP> --local 0.0.0.0 --port 20000 \
  --master-addr 1 --outstation-addr 10 \
  --action scan-all-classes --repeat 1 --wait-after-action 5 \
  --csv logs/master/baseline_soe.csv --log-dir logs/master
```

Actions: `connect-only`, `scan-class0`, `scan-all-classes`, `scan-range`,
`scan-all-objects`, `disable-unsolicited`. Periodic background scans are OFF
unless `--enable-periodic-scans` is given. The CLI exposes **no control
commands** (DirectOperate/SelectAndOperate); those remain only as warning-gated
methods on the `ExperimentMaster` class.

### Measurement receipt (decoded SOE)

After the scan settles, the master prints a human-readable **receipt** of the
measurements it actually decoded from the SOE callback — grouped by type, sorted
by index — and writes the full listing to `logs/master/<phase>_summary.txt`
alongside the raw `<phase>_soe.csv`. This is the application-level proof (the
master *decoded* the values), distinct from the DNP3 CONFIRM (protocol-level
proof that it *accepted* the response, visible in the split-server log / pcap).

Pass `--baseline <soe.csv>` to compare the decoded values against a reference run
on `group/variation + type + index + value` and append a PASS/FAIL block:

```bash
python run_master.py --action scan-class0 --phase crc-split \
  --baseline logs/master/baseline_soe.csv --receipt-rows 3
```

```
DNP3 Measurement Receipt Summary
Run: crc-split
Measurements decoded: 2400
Duplicate points: 0
Analog Inputs - Group 30 Variation 1
  Index 0 = 100.0
  ...
Baseline comparison:
  Expected points: 2400   Received points: 2400
  Missing points: 0   Extra points: 0   Changed values: 0
  Status: PASS
```

`--receipt-rows N` caps console rows per group (0 = all; the `.txt` always lists
every point); `--summary <path>` overrides the file location; `--no-summary`
disables it. **Duplicate points: 0** confirms a single clean scan (a non-zero
count flags repeated/appended measurements). Use a fresh CSV per run — the
per-phase default already does.

## 5. Capture Traffic

Start a packet capture on the link under test, then run the master (section 4)
against the outstation (section 3):

```bash
sudo tcpdump -i <INTERFACE> -w trace/before_split/run.pcap 'tcp port 20000'
```

The response size — and therefore how much OpenDNP3 segments it — is set by the
database sizing in `lab_config.py` (`DEFAULT_DB_SIZE` / `DEFAULT_NUM_ANALOG` /
`DEFAULT_NUM_BINARY` / `DEFAULT_NUM_COUNTER`), which `run_outstation.py` reads.
A single Class 0 read of the default 200+50+50-point DB produces the multi-
fragment response used throughout these write-ups. The native, un-split captures
are in `trace/before_split/`; the CRC-split captures are in `trace/split/`.

## 9. Extract Payloads

```bash
python extract_payloads.py          # no args: uses lab_config defaults
# or override any default with flags:
python extract_payloads.py \
  --pcap trace/before_split/read_exchange.pcap \
  --master-ip <MASTER_IP> --outstation-ip <OUTSTATION_IP> \
  --port 20000 --output-dir payloads/baseline
```

Writes `orig_NNNN.bin` (master→outstation), `resp_NNNN.bin`
(outstation→master), and `metadata.json` (timestamps, IPs, ports, lengths, TCP
flags/seq/ack, direction). Only raw application bytes are saved — no
Ethernet/IP/TCP headers.

## 10. Replay Exact Responses

Exact (verbatim) replay is `--delivery full` on the same canonical server: each
matched response group is sent in a single write, unmodified.

```bash
# outstation host
sudo fuser -k 20000/tcp
python split_server.py --delivery full
# master host
python run_master.py --phase exact-replay   # -> logs/master/exact-replay_soe.csv
```

It uses an ordinary OS socket — the kernel owns TCP seq/ACK/retransmit/checksums —
and the captured bytes are sent unmodified.

## 11. Split Replay Responses (request-aware)

`--delivery crc-boundary` (the default) stands in for the outstation, reassembles
whole DNP3 frames from the TCP stream, matches each master request to its captured
response, and splits every **data-bearing RESPONSE** on existing DNP3 CRC
boundaries:

```bash
sudo fuser -k 20000/tcp
python split_server.py                       # crc-boundary split (default)
python run_master.py --phase crc-split       # -> logs/master/crc-split_soe.csv
```

A multi-fragment READ answer spans two captured groups: the READ produces the
first RESPONSE fragment (confirm requested); after the master's CONFIRM the
outstation sends the continuation fragment. **Both fragments are split** — the
READ response and its CONFIRM-triggered continuation — while small handshake
replies (ENABLE_UNSOLICITED / WRITE) are sent whole. (With the captured set this
is 141 chunks for the first fragment and 97 for the continuation, `bpc=1`.)

`split_server.py` needs no pydnp3: the frame reassembler, request parser,
CRC-boundary splitter, captured-exchange map, and TCP server all live in that one
file (it imports only `lab_config.py`). The accepted socket sets `TCP_NODELAY`
so chunk write boundaries are not coalesced by Nagle. To vary granularity, use
`--blocks-per-chunk` / `--chunk-delay-ms` (or edit `DEFAULT_BLOCKS_PER_CHUNK` /
`DEFAULT_CHUNK_DELAY_MS` in `lab_config.py`).

Before sending, the server asserts `b"".join(chunks) == response`; bytes are never
altered, only the TCP write boundaries change. It refuses to serve a captured
response to a request it cannot match (no blind byte dumping).

## 12. Map DNP3 Fields

```bash
python map_response.py              # no args: uses lab_config defaults
# or override:
python map_response.py \
  --payload payloads/baseline/resp_0001.bin --output reports/field_map_results.md
```

Decodes the link header, header CRC (validated via `dnp3_crc.py`,
CRC-16/DNP), transport byte, application control/function/IIN, and the likely
first object-header offset.

## 13. Analyze TCP ACK Behavior

```bash
python analyze_ack.py               # no args: uses lab_config defaults
# or override:
python analyze_ack.py \
  --pcap trace/before_split/read_exchange.pcap \
  --master-ip <MASTER_IP> --outstation-ip <OUTSTATION_IP> --port 20000 \
  --output-csv reports/tcp_ack_details.csv --summary reports/tcp_ack_summary.csv
```

Reports pure vs piggybacked ACKs, request→ACK and request→response delays, and
TCP/IP fingerprint fields (options, window, TTL, IP ID, PSH).

## 14. What NOT To Do

- **Do not** send control commands (`DirectOperate`, `SelectAndOperate`,
  `Operate`, cold restart) in baseline experiments. Baseline is READ/RESPONSE
  only.
- **Do not** enable unsolicited responses for clean captures.
- **Do not** modify raw DNP3 bytes yet. First prove exact-byte replay and
  split replay work.
- **Do not** append random bytes as "padding". Real padding must be
  protocol-valid (dummy measurement objects, unconfigured indices,
  reserved/proprietary frames) — and only after replay/split is proven.
- **Do not** implement P4 in this phase.

## 15. How To Interpret Results

- **Baseline (small/large/range):** compare response payload length and the
  number of DNP3 application fragments / link frames / TCP segments as the
  database grows. Note whether OpenDNP3 itself splits large responses. Record in
  `reports/baseline_segmentation.md`.
- **Replay:** the master should decode a verbatim response identically to the
  live outstation; `received_request.bin` vs `sent_response.bin` confirm
  byte-for-byte fidelity. Record in `reports/replay_results.md`.
- **Split replay:** if the master decodes the response regardless of TCP write
  boundaries, the stream is robust to fragmentation — a prerequisite (not a
  substitute) for DNP3-aware splitting. Record in `reports/split_results.md`.
- **Field map:** confirms which header fields/offsets later splitting/padding
  logic must preserve and recompute (notably per-block CRCs).
- **TCP ACK analysis:** the pure/piggyback ACK ratio, timing, and TCP/IP
  options form a device response fingerprint. Record in
  `reports/tcp_ack_fingerprinting.md`.

## Live Results (Vision → Hulk)

Run on the real rig — Vision `10.10.54.19` (master) → Hulk `10.10.54.158` (slave),
management network, pydnp3 on Python 3.12 (pybind11 v2.13 swap). Full write-ups in
`reports/`:

- **Baseline segmentation** (`reports/baseline_segmentation.md`): one Class 0 read of a
  200+50+50-point DB → OpenDNP3 splits the response into **9 application fragments / 49 link
  frames (292 B max)**, delivered in **20 TCP segments (≤1448 B)**; DNP3 and TCP boundaries do
  not align. (Research Q2/Q3: yes, it segments at both layers.)
- **Exact replay** (`reports/replay_results.md`, Phase 6): the master **ingests and parses**
  verbatim replayed bytes (full transport reassembly, reads IIN, reacts to a stale restart
  IIN) but delivers **0 values** — DNP3 gates solicited data on a matching **application
  sequence number**. So a replayed/modified response must rewrite the app-control byte and
  recompute CRCs (research Q7).
- **Split replay** (`reports/split_results.md`, Phase 7): the same response sent as **902
  one-byte TCP writes** parses **identically** to the verbatim case — **TCP-boundary
  independence proven**. ✔ Prerequisite for any DNP3-aware work met.
- **Field map** (`reports/field_map_results.md`, Phase 8): real 292 B data frame decoded —
  CRC verified, transport FIR/FIN/seq, app-control (CON=1), RESPONSE, first object header.
- **TCP-ACK fingerprint** (`reports/tcp_ack_fingerprinting.md`, Phase 9): Hulk answers
  piggyback-ACK (9/9), ~0.24 ms ACK / ~1.0 ms response, options `NOP-NOP-Timestamp`.
- **Application-level acceptance** (`reports/request_aware_replay_results.md`): the Phase-6
  "0 values" gating was solved *without modifying any byte*. Replaying the captured responses
  in their captured order (request-aware / ordered) keeps the master on its captured
  trajectory, so its READ lands on the matching **app sequence**. The READ response is split
  into **141 CRC-boundary chunks** (byte-preserving) and the live master **accepts it,
  delivers 800 measurements, and sends a DNP3 CONFIRM**. Clean pcap
  (`trace/split/consolidation_rig_20260625.pcap`, 0 retransmits/resets, with the
  CRC-split visible on the wire as many small outstation->master TCP segments).

## Order Of Operations

Exact replay (Phase 6), split replay (Phase 7), and **byte-preserving
application-level acceptance** (request-aware / ordered replay — master delivers
800 measurements and CONFIRMs) are all now demonstrated on the rig (see Live
Results). The current obfuscation primitive — CRC-boundary splitting — works
**without modifying any DNP3 byte**. Next, still within the no-byte-modification
rule: characterize the obfuscation envelope (split-aggressiveness sweep,
`blocks_per_chunk` / chunk delay), then decide whether to begin the in-network
proxy / true DNP3-aware modification phase (P4) — gated until explicitly started.
