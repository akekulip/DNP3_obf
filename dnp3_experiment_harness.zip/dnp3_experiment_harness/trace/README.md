# trace/ — PCAP traces

PCAP captures of the experiment, split into the traffic **before** the
obfuscation primitive is applied and the traffic produced **by** it.

## `before_split/` — native, un-split DNP3

The ground-truth baseline: a real OpenDNP3 master <-> outstation Class 0 READ,
captured on both ends (byte-identical). This is what an observer sees with no
obfuscation.

| File | What it is |
|------|------------|
| `Hulk_outstation.pcapng` | Outstation-side capture of the baseline READ/RESPONSE exchange. Source of the replayed response bytes in `payloads/`. |
| `Vision_Master.pcapng`   | Master-side capture of the same exchange (byte-identical to the outstation side). |
| `read_exchange.pcap`     | Minimal single READ request + response. Default input for `extract_payloads.py` / `map_response.py` / `analyze_ack.py` (see `lab_config.DEFAULT_CAPTURE`). |

## `split/` — CRC-boundary split

The same response delivered by `split_server.py` after cutting the stream only
on existing DNP3 CRC block boundaries (no byte modified, no CRC recomputed;
`b"".join(chunks) == original`). The split shows up on the wire as many small
outstation->master TCP segments in place of the few native large frames.

| File | What it is |
|------|------------|
| `consolidation_rig_20260625.pcap` | Canonical end-to-end CRC-split run on the rig: master accepts the split response, delivers 800 measurements, sends a DNP3 CONFIRM; 0 retransmits / 0 resets. |
| `sweep_bpc1.pcap` | Split aggressiveness sweep, `--blocks-per-chunk 1` (most aggressive: READ split into 141 chunks). |
| `sweep_bpc2.pcap` | `--blocks-per-chunk 2` (71 chunks). |
| `sweep_bpc4.pcap` | `--blocks-per-chunk 4` (36 chunks). |
| `sweep_bpc8.pcap` | `--blocks-per-chunk 8` (18 chunks). |

All four sweep runs were accepted by the master (800 measurements + CONFIRM
each), pcaps clean. See `reports/split_aggressiveness_sweep.md`.
