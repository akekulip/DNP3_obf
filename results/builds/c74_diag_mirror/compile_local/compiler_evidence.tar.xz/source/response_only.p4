/* Isolated protected same-tuple reconnect candidate. */
#include <core.p4>
#include <tna.p4>
/* Generated isolated N protected reconnect candidate. */
/* Canonical N source in p4/response_only.p4.
   scripts/profile.py copies this source; N does not pad request payloads. */
/* N implements ACK normalization and the request/connection lifecycle.
 * n_ExpectedWorkRecord compares expected generation/phase atomically.
 * first_event and terminal_t select lifecycle and private return operations.
 * Epoch/client/server banks and owner state are defined below.
 * Supported endpoint and encoding data are in p4/profile_template.json.
 */
//
//
//
//
#ifndef CASE4_EXPECTED_WORK_RECORD_P4
#define CASE4_EXPECTED_WORK_RECORD_P4
struct n_expected_work_cell_t { bit<32> generation; bit<32> phase; }
// A genuine producer emits expected phase1/2/3 in its private return packet.
// Full generation and full expected phase are compared in one atomic SALU.
// The caller must quarantine lifecycle ownership separately on raw close;
// operation3 inspects the full qualified pin without accelerating terminal.
// Free4 is published only by an actual expected-phase3 return. Global full32
// generations must not wrap; epoch and final dirty-write lifetime are caller
// authority. No shared bank write may follow a terminal that permits reuse.
control n_ExpectedWorkRecord(in bit<8> operation, in bit<32> generation,
                           in bit<32> expected_phase,
                           inout bit<32> observed_phase) {
    Register<n_expected_work_cell_t, bit<1>>(1, {0, 4}) work;
    RegisterAction<n_expected_work_cell_t, bit<1>, bit<32>>(work) claim = {
        void apply(inout n_expected_work_cell_t value, out bit<32> old_phase) {
            old_phase = value.phase;
            if (value.phase == 4) { value.generation = generation; value.phase = 1; }
        }
    };
    RegisterAction<n_expected_work_cell_t, bit<1>, bit<32>>(work) advance = {
        void apply(inout n_expected_work_cell_t value, out bit<32> old_phase) {
            old_phase = 0;
            if (value.generation == generation && value.phase == expected_phase) {
                old_phase = value.phase; value.phase = value.phase + 1;
            }
        }
    };
    RegisterAction<n_expected_work_cell_t, bit<1>, bit<32>>(work) inspect = {
        void apply(inout n_expected_work_cell_t value, out bit<32> old_phase) {
            old_phase = 0;
            if (value.generation == generation && value.phase == expected_phase) { old_phase = value.phase; }
        }
    };
    RegisterAction<n_expected_work_cell_t, bit<1>, bit<32>>(work) read = {
        void apply(inout n_expected_work_cell_t value, out bit<32> old_phase) { old_phase = value.phase; }
    };
    action claim_work() { observed_phase = claim.execute(0); }
    action return_work() { observed_phase = advance.execute(0); }
    action read_work() { observed_phase = read.execute(0); }
    action inspect_work() { observed_phase = inspect.execute(0); }
    action unavailable_work() { observed_phase = 0; }
    table dispatch {
        key = { operation : exact; expected_phase : ternary; }
        actions = { claim_work; return_work; read_work; inspect_work; unavailable_work; }
        const entries = {
            (1, _) : claim_work();
            (2, 1) : return_work();
            (2, 2) : return_work();
            (2, 3) : return_work();
            (2, _) : unavailable_work();
            (3, 1) : inspect_work();
            (3, 2) : inspect_work();
            (3, 3) : inspect_work();
            (3, _) : unavailable_work();
        }
        const default_action = read_work(); size = 9;
    }
    apply { if (operation == 1 && generation == 0) { unavailable_work(); } else { dispatch.apply(); } }
}
#endif

const PortId_t n_RETURN_PORT=9w68;
const PortId_t n_N_ACK_RETURN=9w48; /* dev48, pipe0 local48: front-panel ACK-normalization return, configured for MAC loopback. */
const bit<32> n_RETRY_BUDGET=32;
const PortId_t n_READ_HANDOFF_PORT=9w180; /* N-to-T handoff at dev180; matches t_T_IN. */
/* DIAG MIRROR (diagnostic mirror build only; scripts/build_diag_mirror.py, never in p4/response_only.p4): every frame
   received on n_DIAG_RELAY_PORT is copied as received (TNA ingress mirror) to session n_DIAG_SESSION_RX. */
const MirrorType_t n_DIAG_MIRROR_TYPE=1;
const PortId_t n_DIAG_RELAY_PORT=9w64;
const MirrorId_t n_DIAG_SESSION_RX=10w101;
const MirrorId_t n_DIAG_NO_SESSION=10w0;
header n_dl_h{bit<16> magic;bit<8> len;bit<8> ctrl;bit<16> dst;bit<16> src;bit<16> crc;}
header n_block_h{bit<32> w0;bit<32> w1;bit<32> w2;bit<32> w3;bit<16> crc;}
header n_tail_h{bit<16> off;bit<8> status;bit<8> index2;bit<8> code2;bit<8> count2;bit<32> on2;bit<32> off2;bit<8> status2;bit<16> crc;}
header n_response_tail_h{bit<32> w0;bit<32> w1;bit<8> w2;bit<16> crc;}
header n_rtail_h{bit<32> off;bit<8> status;bit<8> index2;bit<8> code2;bit<8> count2;bit<32> on2;bit<32> off2;bit<16> crc;}
header n_cstatus_h{bit<8> status;bit<16> crc;}
struct n_object_pair_t{bit<32> first;bit<32> second;}
header n_read_req_h{bit<8> tp;bit<8> app;bit<8> func;bit<8> group;bit<8> variation;bit<8> qualifier;bit<8> first;bit<8> last;bit<16> crc;}
header n_read_req_full_h{bit<8> tp;bit<8> app;bit<8> func;bit<24> o1;bit<24> o2;bit<24> o3;bit<24> o4;bit<16> crc;}
header n_read_req_mx_h{bit<8> tp;bit<8> app;bit<8> func;bit<40> o1;bit<40> o2;bit<16> crc;}
header n_read_tail_h{bit<8> value;bit<16> crc;}
header n_ack_origin_h{bit<32> wire_ack;bit<32> normalized_epoch;}
header n_t0_h{bit<32> t0q;}
header n_replay_h{bit<8> value;}
header n_eth_h{bit<48> dst;bit<48> src;bit<16> type;}
header n_ip_h{bit<4> version;bit<4> ihl;bit<8> tos;bit<16> len;bit<16> id;bit<3> flags;bit<13> frag;bit<8> ttl;bit<8> proto;bit<16> checksum;bit<32> src;bit<32> dst;}
header n_tcp_h{bit<16> sport;bit<16> dport;bit<32> seq;bit<32> ack;bit<4> offset;bit<4> reserved;bit<8> flags;bit<16> window;bit<16> checksum;bit<16> urgent;}
header n_mss_h{bit<8> kind;bit<8> len;bit<16> value;}
header n_opt12_h{bit<32> a;bit<32> b;bit<32> c;}
header n_opt4_h{bit<32> v;}
header n_ts_word_h{bit<16> v;}
header n_ts_body_h{bit<32> value;bit<32> echo;}
header n_envelope_h{bit<32> epoch;}
header n_work_generation_h{bit<32> generation;}
header n_expected_cell_h{bit<32> expected_cell;}
header n_event_h{bit<8> phase;bit<8> code;bit<16> reserved;}
struct n_headers_t{n_envelope_h envelope;n_work_generation_h work_generation;n_expected_cell_h expected_cell;n_event_h event;n_t0_h t0;n_ack_origin_h origin;n_eth_h eth;n_ip_h ip;n_tcp_h tcp;n_mss_h mss;n_opt12_h tso;n_opt4_h hs0;n_opt4_h hs1;n_opt4_h hs2;n_opt4_h oa;n_opt4_h ob;n_ts_word_h rts0;n_ts_word_h rts1;n_ts_body_h rts;n_dl_h dl;n_block_h first;n_block_h second;n_tail_h tail;n_response_tail_h response_tail;n_rtail_h rtail;n_cstatus_h cstatus;n_read_req_h rd_req;n_read_req_full_h rd_req_full;n_read_req_mx_h rd_req_mx;n_read_tail_h rd_tail;n_replay_h rb;}
struct n_meta_t{bit<32> wire_ack;bit<32> normalized_epoch;bit<1> same_syn;bit<1> lap;bit<1> committed;bit<32> next_owner_gen;bit<8> cache_mode;bit<8> association_allowed;bit<1> response;bit<1> matched;bit<8> operate_qualified;bit<32> prefix_difference;bit<32> accepted_diff;bit<16> crc1;bit<1> bad1;bit<32> compare_real_links;bit<8> diff_real_links;bit<32> compare_real_tcp_dst;bit<8> diff_real_tcp_dst;bit<32> compare_real_tcp_ports;bit<32> compare_native_start;bit<32> compare_native_end;bit<8> diff_native_end;bit<32> compare_server_start;bit<32> compare_application;bit<16> diff_application;bit<32> compare_frozen_decoy_object;bit<32> diff_frozen_decoy_object;bit<32> compare_frozen_decoy_on;bit<32> compare_frozen_decoy_off;bit<32> diff_frozen_decoy_off;bit<32> context_generation;bit<32> native_end;bit<1> enabled;bit<8> profile;bit<1> changed;bit<16> tcp_length;bit<16> decoy_index;bit<8> decoy_code;bit<8> decoy_repeat;bit<32> decoy_on;bit<32> decoy_off;bit<16> hcrc;bit<16> bcrc;bit<16> tcrc;bit<1> badh;bit<1> badb;bit<1> badt;bit<1> return_abort;bit<1> data_valid;bit<32> ack_native;bit<32> expected_work_phase;bit<1> go;bit<16> link_dst;bit<16> link_src;bit<32> compare_read_app;bit<1> parsed;bit<1> port_valid;bit<2> direction;bit<1> network_valid;bit<1> shape_valid;bit<8> packet_kind;bit<2> stage;bit<8> kind;bit<8> work_op;bit<1> owner_op;bit<1> epoch_valid;bit<1> emit_loop;PortId_t output_port;bool ip_error;bit<16> tcp_sum;bit<32> counter;bit<32> generation;bit<32> work_phase;bit<32> epoch;bit<32> client;bit<32> server;bit<32> new_seq;bit<32> client_diff;bit<32> server_diff;bit<32> epoch_diff;bit<32> expected;bit<32> desired;bit<32> observed;bit<32> owner_diff;bit<2> retry;MirrorId_t diag_ses;}
parser n_IgParser(packet_in pkt,out n_headers_t hdr,out n_meta_t m,out ingress_intrinsic_metadata_t ig){
 Checksum() ic;Checksum() tc;
 state start{pkt.extract(ig);pkt.advance(PORT_METADATA_SIZE);m.retry=2w0;m.wire_ack=32w0;m.normalized_epoch=32w0;m.same_syn=(bit<1>)(8w0);m.lap=(bit<1>)(8w0);m.committed=(bit<1>)(8w0);m.parsed=(bit<1>)(8w0);m.enabled=(bit<1>)(8w0);m.profile=8w0;m.response=(bit<1>)(8w0);m.matched=(bit<1>)(8w0);m.data_valid=(bit<1>)(8w0);m.cache_mode=8w0;m.badh=(bit<1>)(8w0);m.badb=(bit<1>)(8w0);m.bad1=(bit<1>)(8w0);m.badt=(bit<1>)(8w0);m.stage=(bit<2>)(8w0);m.kind=8w0;m.port_valid=(bit<1>)(8w0);m.direction=(bit<2>)(8w0);m.network_valid=(bit<1>)(8w0);m.shape_valid=(bit<1>)(8w0);m.epoch_valid=(bit<1>)(8w0);m.emit_loop=(bit<1>)(8w0);transition select(ig.ingress_port){n_RETURN_PORT:envelope;n_N_ACK_RETURN:normalized;default:native_prefix;}}
 state normalized{pkt.extract(hdr.envelope);pkt.extract(hdr.work_generation);pkt.extract(hdr.expected_cell);pkt.extract(hdr.event);transition select(hdr.event.phase,hdr.event.reserved){(8w0xe1,16w0):normalized_input;(8w0xe6,16w0):committed_input;default:reject;}}
 state normalized_input{m.wire_ack=hdr.work_generation.generation;m.normalized_epoch=hdr.envelope.epoch;m.same_syn=(bit<1>)((bit<8>)hdr.expected_cell.expected_cell);m.lap=(bit<1>)(8w1);transition eth;}
 state committed_input{m.committed=(bit<1>)(8w1);transition eth;}
 state origin{pkt.extract(hdr.origin);m.wire_ack=hdr.origin.wire_ack;m.normalized_epoch=hdr.origin.normalized_epoch;transition eth;}
 state native_prefix{hdr.envelope.setValid();hdr.envelope.epoch=32w0;hdr.work_generation.setValid();hdr.work_generation.generation=32w0;hdr.expected_cell.setValid();hdr.expected_cell.expected_cell=32w0;hdr.event.setValid();hdr.event.phase=8w226;hdr.event.code=8w0;hdr.event.reserved=16w0;transition eth;}
 state envelope{pkt.extract(hdr.envelope);transition select(hdr.envelope.epoch){32w0:accept;default:envelope_generation;}}
 state envelope_generation{pkt.extract(hdr.work_generation);transition select(hdr.work_generation.generation){32w0:accept;default:envelope_expected;}}
 state envelope_expected{pkt.extract(hdr.expected_cell);pkt.extract(hdr.event);m.stage=(bit<2>)(hdr.event.phase);m.kind=hdr.event.code;transition envelope_reserved;}
 state envelope_reserved{transition select(hdr.event.reserved){16w0&&&16w0xffc0:envelope_event;default:accept;}}
 state envelope_event{transition select((hdr.event.phase++hdr.event.code)){16w0x0101:origin;16w0x0102:origin;16w0x0103:origin;16w0x0104:origin;16w0x0204:origin;16w0x01ff:origin;16w0x0201:origin;16w0x0202:origin;16w0x0203:origin;16w0x02ff:origin;16w0x0301:origin;16w0x0302:origin;16w0x0303:origin;16w0x03ff:origin;16w0x0105:origin;16w0x0106:origin;16w0x0107:read_t0;16w0x0108:origin;16w0x0119:origin;16w0x0219:origin;16w0x0319:origin;16w0x0118:read_t0;16w0x0205:origin;16w0x0206:origin;16w0x0207:read_t0;16w0x0208:origin;16w0x0218:read_t0;16w0x0305:origin;16w0x0306:origin;16w0x0307:read_t0;16w0x0308:origin;16w0x0318:read_t0;16w0x0109:read_t0;16w0x010a:read_t0;16w0x010b:read_t0;16w0x0209:read_t0;16w0x020a:read_t0;16w0x020b:read_t0;16w0x0309:read_t0;16w0x030a:read_t0;16w0x030b:read_t0;16w0x0110:origin;16w0x010c:origin;16w0x0210:origin;16w0x020c:origin;16w0x0310:origin;16w0x0111:origin;16w0x0211:origin;16w0x0311:origin;16w0x030c:origin;16w0x0400:response_retry_reserved;16w0x0800:retry_rst_input;default:accept;}}
 state response_retry_reserved{transition select(hdr.event.reserved){16w0:retry_input;default:reject;}}
 state retry_input{m.retry=2w1;transition eth;}
 state retry_rst_input{m.retry=2w1;transition origin;}
 state eth{pkt.extract(hdr.eth);transition select(hdr.eth.type){16w0x0800:ip;default:accept;}}
 state ip{pkt.extract(hdr.ip);ic.add(hdr.ip);m.ip_error=ic.verify();tc.subtract({hdr.ip.src,hdr.ip.dst,8w0,hdr.ip.proto,hdr.ip.len});transition select(hdr.ip.version,hdr.ip.ihl,hdr.ip.proto,hdr.ip.len){(4w4,4w5,8w6,16w97):native_ip_flags;(4w4,4w5,8w6,16w60):read_ip_flags;(4w4,4w5,8w6,16w77):rx_ip_flags;(4w4,4w5,8w6,16w79):rx_ip_flags;(4w4,4w5,8w6,16w143):rx_response_ip_flags;(4w4,4w5,8w6,16w186):rx_response_ip_flags;(4w4,4w5,8w6,16w41):replay_ip_flags;(4w4,4w5,8w6,16w52):ts_ip_flags;(4w4,4w5,8w6,16w64):ts_synack_ip_flags;(4w4,4w5,8w6,16w101):ts_read_response_ip_flags;default:accept;}}
 state ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):tcp;(13w0,3w2):tcp;default:accept;}}
 state tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.ip.len,hdr.tcp.flags){(4w6,16w44,8w2):mss_syn;(4w6,16w44,8w18):mss_synack;(4w5,16w40,8w16):ack;(4w5,16w40,8w17):close;(4w5,16w40,8w20):close;(4w5,16w40,8w4):close;default:accept;}}
 state mss_syn{pkt.extract(hdr.mss);tc.subtract(hdr.mss);m.packet_kind=8w1;transition mss_check;}
 state mss_synack{pkt.extract(hdr.mss);tc.subtract(hdr.mss);m.packet_kind=8w2;transition mss_check;}
 state ts_syn_profile{pkt.extract(hdr.hs0);tc.subtract(hdr.hs0);transition select(hdr.hs0.v){32w0x0402080a:ts_syn_value;default:accept;}}
 state ts_syn_echo{pkt.extract(hdr.hs2);tc.subtract(hdr.hs2);transition select(hdr.hs2.v){32w0:ts_syn_ws;default:accept;}}
 state ts_syn_ws{pkt.extract(hdr.oa);tc.subtract(hdr.oa);m.tcp_sum=tc.get();transition select(hdr.oa.v){32w0x01030307:finish_handshake;default:accept;}}
 state ts_synack_profile{pkt.extract(hdr.hs0);tc.subtract(hdr.hs0);transition select(hdr.hs0.v){32w0x01030300:ts_synack_sack;default:accept;}}
 state ts_synack_sack{pkt.extract(hdr.hs1);tc.subtract(hdr.hs1);transition select(hdr.hs1.v){32w0x01010402:ts_synack_ts;default:accept;}}
 state ts_synack_ts{pkt.extract(hdr.hs2);tc.subtract(hdr.hs2);transition select(hdr.hs2.v){32w0x0101080a:ts_synack_values;default:accept;}}
 state ts_syn_mss{transition select(hdr.mss.kind,hdr.mss.len,hdr.mss.value){(8w2,8w4,16w1460):ts_syn_profile;default:accept;}}
 state ts_synack_mss{transition select(hdr.mss.kind,hdr.mss.len,hdr.mss.value){(8w2,8w4,16w1460):ts_synack_profile;default:accept;}}
 state mss_check{transition select(hdr.mss.kind,hdr.mss.len,hdr.mss.value){(8w2,8w4,16w1460):finish_handshake;default:accept;}}
 state ack{m.packet_kind=8w3;transition finish;}
 state close{m.packet_kind=8w4;transition finish;}
 state native_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):native_tcp;(13w0,3w2):native_tcp;default:accept;}}
 state native_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w8,4w0,16w0,8w16):native_tcp_ts;(4w8,4w0,16w0,8w24):native_tcp_ts;(4w8,4w0,16w0,8w0x01&&&8w0x01):native_command_reject;(4w8,4w0,16w0,8w0x04&&&8w0x04):native_command_reject;default:accept;}}
 state native_tcp_ts{pkt.extract(hdr.tso);tc.subtract(hdr.tso);transition select(hdr.tso.a){32w0x0101080a:native_dl;default:accept;}}
 state native_command_reject{m.packet_kind=8w13;transition finish;}
 state native_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition native_block;}
 state response_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):response_tcp;(13w0,3w2):response_tcp;default:accept;}}
 state response_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w5,4w0,16w0,8w16):response_dl;(4w5,4w0,16w0,8w24):response_dl;default:accept;}}
 state response_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition response_block;}
 state read_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):read_tcp;(13w0,3w2):read_tcp;default:accept;}}
 state read_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w10,4w0,16w0,8w2):ts_syn;default:accept;}}
 state read_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition read_request;}
 state read_response_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):read_response_tcp;(13w0,3w2):read_response_tcp;default:accept;}}
 state read_response_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w5,4w0,16w0,8w16):read_response_dl;(4w5,4w0,16w0,8w24):read_response_dl;default:accept;}}
 state read_response_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition select(hdr.dl.ctrl,hdr.dl.len){(8w0x44,8w0x26):response_or_read;default:accept;}}
 state response_or_read{pkt.extract(hdr.first);tc.subtract(hdr.first);transition select(hdr.first.w1[23:0]){24w0x0c0117:rtail37;default:accept;}}
 state replay_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):replay_tcp;(13w0,3w2):replay_tcp;default:accept;}}
 state replay_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){default:accept;}}
 state rx_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):rx_tcp;(13w0,3w2):rx_tcp;default:accept;}}
 state rx_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.flags){(4w8,8w16):rx_tcp_ts;(4w8,8w24):rx_tcp_ts;default:accept;}}
 state rx_tcp_ts{pkt.extract(hdr.rts0);tc.subtract(hdr.rts0);transition select(hdr.rts0.v){16w0x0101:rx_tcp_ts_kind;default:accept;}}
 state rx_tcp_ts_kind{pkt.extract(hdr.rts1);tc.subtract(hdr.rts1);transition select(hdr.rts1.v){16w0x080a:rx_tcp_ts_body;default:accept;}}
 state rx_tcp_ts_body{pkt.extract(hdr.rts);tc.subtract(hdr.rts);transition rx_dl;}
 state rx_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition select(hdr.dl.len,hdr.ip.len){(8w0x14,16w79):read_request_full;(8w0x12,16w77):read_request_mx;default:accept;}}
 state read_request_full{pkt.extract(hdr.rd_req_full);tc.subtract(hdr.rd_req_full);m.packet_kind=8w9;transition finish;}
 state read_request_mx{pkt.extract(hdr.rd_req_mx);tc.subtract(hdr.rd_req_mx);m.packet_kind=8w9;transition finish;}
 state rx_response_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):rx_response_tcp;(13w0,3w2):rx_response_tcp;default:accept;}}
 state rx_response_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.flags){(4w8,8w16):rx_response_tcp_ts;(4w8,8w24):rx_response_tcp_ts;default:accept;}}
 state rx_response_tcp_ts{pkt.extract(hdr.rts0);tc.subtract(hdr.rts0);transition select(hdr.rts0.v){16w0x0101:rx_response_tcp_ts_kind;default:accept;}}
 state rx_response_tcp_ts_kind{pkt.extract(hdr.rts1);tc.subtract(hdr.rts1);transition select(hdr.rts1.v){16w0x080a:rx_response_tcp_ts_body;default:accept;}}
 state rx_response_tcp_ts_body{pkt.extract(hdr.rts);tc.subtract(hdr.rts);transition rx_response_dl;}
 state rx_response_dl{pkt.extract(hdr.dl);tc.subtract(hdr.dl);transition select(hdr.dl.len,hdr.ip.len){(8w0x4c,16w143):read_response_fb;(8w0x73,16w186):read_response_fb;default:accept;}}
 state read_response_fb{pkt.extract(hdr.first);tc.subtract(hdr.first);m.packet_kind=8w11;transition finish_shallow;}
 state finish_shallow{m.parsed=(bit<1>)(8w1);m.shape_valid=(bit<1>)(8w1);transition accept;}
 state read_request{pkt.extract(hdr.rd_req);tc.subtract(hdr.rd_req);m.packet_kind=8w9;transition finish;}
 state read_response_block{pkt.extract(hdr.first);tc.subtract(hdr.first);transition read_response_second;}
 state read_response_second{pkt.extract(hdr.second);tc.subtract(hdr.second);transition read_response_tail;}
 state read_response_tail{pkt.extract(hdr.rd_tail);tc.subtract(hdr.rd_tail);m.packet_kind=8w11;transition finish;}
 state read_t0{pkt.extract(hdr.t0);transition origin;}
 state native_block{pkt.extract(hdr.first);tc.subtract(hdr.first);transition native_tail;}
 state native_tail{pkt.extract(hdr.tail);tc.subtract(hdr.tail);transition select(hdr.first.w0[15:8]){8w3:select_finish;8w4:operate_finish;default:accept;}}
 state select_finish{m.packet_kind=8w5;transition finish;}
 state operate_finish{m.packet_kind=8w7;transition finish;}
 state response_block{pkt.extract(hdr.first);tc.subtract(hdr.first);transition rtail37;}
 state rtail37{pkt.extract(hdr.rtail);tc.subtract(hdr.rtail);pkt.extract(hdr.cstatus);tc.subtract(hdr.cstatus);m.response=(bit<1>)(8w1);m.packet_kind=8w6;transition finish;}
 state ts_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):ts_tcp;(13w0,3w2):ts_tcp;default:accept;}}
 state ts_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.flags){(4w8,8w16):ts_ack;(4w8,8w17):ts_close;(4w8,8w25):ts_close;(4w8,8w20):ts_close;(4w8,8w4):ts_close;default:accept;}}
 state ts_ack{pkt.extract(hdr.tso);tc.subtract(hdr.tso);transition select(hdr.tso.a){32w0x0101080a:ack;default:accept;}}
 state ts_close{pkt.extract(hdr.tso);tc.subtract(hdr.tso);transition select(hdr.tso.a){32w0x0101080a:close;default:accept;}}
 state ts_syn{pkt.extract(hdr.mss);tc.subtract(hdr.mss);m.packet_kind=8w1;transition ts_syn_mss;}
 state ts_synack_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):ts_synack_tcp;(13w0,3w2):ts_synack_tcp;default:accept;}}
 state ts_synack_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.flags){(4w11,8w18):ts_synack;default:accept;}}
 state ts_synack{pkt.extract(hdr.mss);tc.subtract(hdr.mss);m.packet_kind=8w2;transition ts_synack_mss;}
 state ts_read_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):ts_read_tcp;(13w0,3w2):ts_read_tcp;default:accept;}}
 state ts_read_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w8,4w0,16w0,8w16):ts_read_opt;(4w8,4w0,16w0,8w24):ts_read_opt;default:accept;}}
 state ts_read_opt{pkt.extract(hdr.tso);tc.subtract(hdr.tso);transition select(hdr.tso.a){32w0x0101080a:read_dl;default:accept;}}
 state ts_read_response_ip_flags{transition select(hdr.ip.frag,hdr.ip.flags){(13w0,3w0):ts_read_response_tcp;(13w0,3w2):ts_read_response_tcp;default:accept;}}
 state ts_read_response_tcp{pkt.extract(hdr.tcp);tc.subtract(hdr.tcp);transition select(hdr.tcp.offset,hdr.tcp.reserved,hdr.tcp.urgent,hdr.tcp.flags){(4w8,4w0,16w0,8w16):ts_read_response_opt;(4w8,4w0,16w0,8w24):ts_read_response_opt;default:accept;}}
 state ts_read_response_opt{pkt.extract(hdr.tso);tc.subtract(hdr.tso);transition select(hdr.tso.a){32w0x0101080a:read_response_dl;default:accept;}}
 state ts_syn_value{pkt.extract(hdr.hs1);tc.subtract(hdr.hs1);transition ts_syn_echo;}
 state ts_synack_values{pkt.extract(hdr.oa);tc.subtract(hdr.oa);pkt.extract(hdr.ob);tc.subtract(hdr.ob);m.tcp_sum=tc.get();transition finish_handshake;}
 state finish_handshake{m.parsed=(bit<1>)(8w1);m.shape_valid=(bit<1>)(8w1);transition accept;}
 state finish{m.tcp_sum=tc.get();m.parsed=(bit<1>)(8w1);m.shape_valid=(bit<1>)(8w1);transition accept;}

}
struct n_application_state_t{bit<16> crob;bit<16> read_identity;}
@pa_mutually_exclusive("ingress", "hdr.rd_req", "hdr.rd_req_full")
@pa_mutually_exclusive("ingress", "hdr.rd_req", "hdr.rd_req_mx")
@pa_mutually_exclusive("ingress", "hdr.rd_req_full", "hdr.rd_req_mx")
@pa_container_size("ingress", "m.expected_work_phase", 32)
@pa_solitary("ingress", "m.expected_work_phase")
@pa_solitary("ingress", "hdr.event.phase")
@pa_solitary("ingress", "hdr.event.code")
@pa_container_size("ingress", "hdr.event.phase", 8)
@pa_container_size("ingress", "hdr.event.code", 8)
@pa_solitary("ingress","m.diff_real_links")
@pa_solitary("ingress", "m.diff_real_tcp_dst")
@pa_solitary("ingress", "m.diff_native_end")
@pa_no_overlay("ingress", "ig_intr_md_for_dprsr.mirror_type")   /* DIAG MIRROR: unwritten value must stay 0 */
@pa_no_overlay("ingress", "m.diag_ses")
control n_Ingress(inout n_headers_t hdr,inout n_meta_t m,in ingress_intrinsic_metadata_t ig,in ingress_intrinsic_metadata_from_parser_t p,inout ingress_intrinsic_metadata_for_deparser_t md,inout ingress_intrinsic_metadata_for_tm_t tm){
 n_ExpectedWorkRecord() work;
 Register<bit<32>,bit<1>>(1,0) counter;
 RegisterAction<bit<32>,bit<1>,bit<32>>(counter) allocate={void apply(inout bit<32> v,out bit<32> r){r=32w0;if(v<32w0x7ffffffe){v=v+32w1;r=v;}}};
 Register<bit<32>,bit<1>>(1,0) owner;
 RegisterAction<bit<32>,bit<1>,bit<32>>(owner) check_owner={void apply(inout bit<32> v,out bit<32> r){r=v-m.expected;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(owner) read_owner={void apply(inout bit<32> v,out bit<32> r){r=v;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(owner) compare_owner={void apply(inout bit<32> v,out bit<32> r){r=v-m.expected;if(v==m.expected){v=m.desired;}}};
  action deny(){md.drop_ctl=3w1;}
 action committed_to_t(bit<16> event){hdr.event.phase=event[15:8];hdr.event.code=event[7:0];tm.ucast_egress_port=n_READ_HANDOFF_PORT;tm.bypass_egress=1w0;}
 table committed_t{key={hdr.event.phase:exact;hdr.event.code:exact;}actions={committed_to_t;deny;}size=3;const entries={(8w230,8w9):committed_to_t(16w0x0900);(8w230,8w12):committed_to_t(16w0x0c00);(8w230,8w15):committed_to_t(16w0x0f00);}const default_action=deny();}
 /* response-only: no bypass_egress here; final departures to 9/64 cross pipe 0 egress (B' mapper) */
action route(PortId_t port){m.port_valid=(bit<1>)(8w1);tm.ucast_egress_port=port;}
 /* every master-side IPv4 TCP packet -> one reverse-map lap through pipe 0 egress; (bit<8>)m.port_valid stays 0 */
action normalize_ack(){hdr.event.phase=8w224;hdr.event.code=8w0;tm.ucast_egress_port=n_N_ACK_RETURN;tm.bypass_egress=1w0;}
table ports{key={ig.ingress_port:exact;hdr.ip.isValid():ternary;hdr.ip.proto:ternary;hdr.ip.src:ternary;}actions={route;normalize_ack;deny;}size=8;default_action=deny();}
 action forward_flow(PortId_t port){m.direction=(bit<2>)(8w1);m.output_port=port;}
 action reverse_flow(PortId_t port){m.direction=(bit<2>)(8w2);m.output_port=port;}
 table connection{key={hdr.ip.src:exact;hdr.ip.dst:exact;hdr.tcp.sport:exact;hdr.tcp.dport:exact;ig.ingress_port:exact;}actions={forward_flow;reverse_flow;NoAction;}size=4;default_action=NoAction();}
 action network_accept(){m.network_valid=(bit<1>)(8w1);}
 table network{key={m.parsed:exact;m.kind:exact;hdr.tcp.flags:ternary;m.ip_error:exact;m.tcp_sum:exact;hdr.ip.ttl:range;hdr.tcp.reserved:exact;hdr.tcp.urgent:exact;}actions={network_accept;NoAction;}size=32;const default_action=NoAction();const entries={(1w1,8w0,_,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w1,8w2,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w2,8w18,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w3,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w4,8w17&&&8w0xf7,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w4,8w20,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w4,8w4,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w255,_,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w5,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w5,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w6,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w6,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w7,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w7,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w24,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w24,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w8,8w2,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w8,8w18,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w8,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w8,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w25,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w25,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w9,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w9,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w10,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w11,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w11,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w16,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w16,8w24,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w17,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();(1w1,8w12,8w16,false,16w0xffeb,8w1..8w255,4w0,16w0):network_accept();}}
 action syn_shape(){m.shape_valid=(bit<1>)(8w1);m.kind=8w1;}
 action synack_shape(){m.shape_valid=(bit<1>)(8w1);m.kind=8w2;}
 table syn_shapes{key={m.direction:exact;hdr.tcp.flags:exact;hdr.mss.kind:exact;hdr.mss.len:exact;hdr.mss.value:range;}
 actions={syn_shape;synack_shape;NoAction;}size=2;const default_action=NoAction();const entries={(2w1,8w2,8w2,8w4,16w1460):syn_shape();(2w2,8w18,8w2,8w4,16w1460):synack_shape();}}
 action ack_shape(){m.shape_valid=(bit<1>)(8w1);m.kind=8w3;}
 action close_shape(){m.shape_valid=(bit<1>)(8w1);m.kind=8w4;}
 table short_shapes{key={m.direction:exact;hdr.tcp.flags:exact;}
 actions={ack_shape;close_shape;NoAction;}size=9;const default_action=NoAction();const entries={(2w1,8w16):ack_shape();(2w1,8w17):close_shape();(2w2,8w17):close_shape();(2w1,8w25):close_shape();(2w2,8w25):close_shape();(2w1,8w20):close_shape();(2w2,8w20):close_shape();(2w1,8w4):close_shape();(2w2,8w4):close_shape();}}
 action configure(bit<16> index,bit<8> code,bit<8> repeat,bit<32> on,bit<32> off){m.enabled=(bit<1>)(8w1);m.decoy_index=index;m.decoy_code=code;m.decoy_repeat=repeat;m.decoy_on=on;m.decoy_off=off;}
 table data_connection{key={hdr.ip.src:exact;hdr.ip.dst:exact;hdr.tcp.sport:exact;hdr.tcp.dport:exact;}actions={configure;NoAction;}size=2;default_action=NoAction();}
 action eligible(){m.profile=8w1;}
 table profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.first.w0:ternary;hdr.first.w1:exact;hdr.first.w2:exact;hdr.first.w3:exact;hdr.tail.off:exact;hdr.tail.status:exact;hdr.tail.index2:exact;hdr.tail.code2:exact;hdr.tail.count2:exact;hdr.tail.on2:exact;hdr.tail.off2:exact;hdr.tail.status2:exact;}actions={eligible;NoAction;}size=2;const default_action=NoAction();const entries={(16w0x0564,8w36,8w0xc4,32w0xc0c0030c&&&32w0xc0f0ffff,32w0x01170201,32w0x0101c800,32w0,16w0,8w0,8w3,8w1,8w1,32w0xc8000000,32w0,8w0):eligible();(16w0x0564,8w36,8w0xc4,32w0xc0c0040c&&&32w0xc0f0ffff,32w0x01170201,32w0x0101c800,32w0,16w0,8w0,8w3,8w1,8w1,32w0xc8000000,32w0,8w0):eligible();}}
 CRCPolynomial<bit<16>>(16w0x3D65,true,false,false,16w0,16w0xFFFF) poly;
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_head;
action input_tail(){m.tcrc=16w0x993a;}
action tail_crc_bad(){m.tcrc=16w0;}
@stage(2) table input_tail_t{key={hdr.tail.crc:exact;}actions={input_tail;tail_crc_bad;}size=1;const default_action=tail_crc_bad();const entries={16w0x15ee:input_tail();}}
table response_profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.first.w0:ternary;hdr.first.w1:ternary;hdr.first.w2:exact;hdr.first.w3:exact;hdr.rtail.off:exact;hdr.rtail.index2:exact;hdr.rtail.code2:exact;hdr.rtail.count2:exact;hdr.rtail.on2:exact;hdr.rtail.off2:exact;}actions={eligible;NoAction;}size=1;const default_action=NoAction();const entries={(16w0x0564,8w38,8w0x44,32w0xc0c08100&&&32w0xc0f0ff00,32w0x000c0117&&&32w0x00ffffff,32w0x02010101,32w0xc8000000,32w0,8w3,8w1,8w1,32w0xc8000000,32w0):eligible();}}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_first;
/* response-only: one table computes the link-header n_CRC (every DNP3 kind) and the first-block n_CRC (every
   kind that carries hdr.first). It replaces input_head_t, rd_head_t, input_body_t, response_crc0_t and
   rd_first_crc_t, which computed the same two CRCs over the same bits (input_body's byte slices
   concatenate to {w0,w1,w2,w3}). Fewer hash tables and crossbar bytes in N's stage 1, which pipe 0's
   egress response path also needs (evidence/route_ab_01/response_only_04). */
action crc_head(){m.hcrc=hash_head.get({hdr.dl.magic,hdr.dl.len,hdr.dl.ctrl,hdr.dl.dst,hdr.dl.src,hdr.dl.crc});}
action crc_head_first(){crc_head();m.bcrc=hash_first.get({hdr.first.w0,hdr.first.w1,hdr.first.w2,hdr.first.w3,hdr.first.crc});}
action crc_head_first_shallow(){crc_head();m.bcrc=hash_first.get({hdr.first.w0,hdr.first.w1,hdr.first.w2,hdr.first.w3,hdr.first.crc});m.tcp_sum=16w0xffeb;}
@stage(1) table crc_t{key={m.packet_kind:exact;}actions={crc_head;crc_head_first;crc_head_first_shallow;NoAction;}size=8;const default_action=NoAction();const entries={8w5:crc_head_first();8w6:crc_head_first();8w7:crc_head_first();8w9:crc_head();8w11:crc_head_first_shallow();}}
action response_status_good(){m.crc1=16w0x993a;}
action response_status_bad(){m.crc1=16w0;}
table response_status_crc_t{key={hdr.cstatus.status:exact;hdr.cstatus.crc:exact;}actions={response_status_good;response_status_bad;}size=256;const default_action=response_status_bad();const entries={(8w0,16w0xffff):response_status_good();(8w1,16w0xa1c9):response_status_good();(8w2,16w0x4393):response_status_good();(8w3,16w0x1da5):response_status_good();(8w4,16w0x8726):response_status_good();(8w5,16w0xd910):response_status_good();(8w6,16w0x3b4a):response_status_good();(8w7,16w0x657c):response_status_good();(8w8,16w0x7600):response_status_good();(8w9,16w0x2836):response_status_good();(8w10,16w0xca6c):response_status_good();(8w11,16w0x945a):response_status_good();(8w12,16w0x0ed9):response_status_good();(8w13,16w0x50ef):response_status_good();(8w14,16w0xb2b5):response_status_good();(8w15,16w0xec83):response_status_good();(8w16,16w0x944d):response_status_good();(8w17,16w0xca7b):response_status_good();(8w18,16w0x2821):response_status_good();(8w19,16w0x7617):response_status_good();(8w20,16w0xec94):response_status_good();(8w21,16w0xb2a2):response_status_good();(8w22,16w0x50f8):response_status_good();(8w23,16w0x0ece):response_status_good();(8w24,16w0x1db2):response_status_good();(8w25,16w0x4384):response_status_good();(8w26,16w0xa1de):response_status_good();(8w27,16w0xffe8):response_status_good();(8w28,16w0x656b):response_status_good();(8w29,16w0x3b5d):response_status_good();(8w30,16w0xd907):response_status_good();(8w31,16w0x8731):response_status_good();(8w32,16w0x50d6):response_status_good();(8w33,16w0x0ee0):response_status_good();(8w34,16w0xecba):response_status_good();(8w35,16w0xb28c):response_status_good();(8w36,16w0x280f):response_status_good();(8w37,16w0x7639):response_status_good();(8w38,16w0x9463):response_status_good();(8w39,16w0xca55):response_status_good();(8w40,16w0xd929):response_status_good();(8w41,16w0x871f):response_status_good();(8w42,16w0x6545):response_status_good();(8w43,16w0x3b73):response_status_good();(8w44,16w0xa1f0):response_status_good();(8w45,16w0xffc6):response_status_good();(8w46,16w0x1d9c):response_status_good();(8w47,16w0x43aa):response_status_good();(8w48,16w0x3b64):response_status_good();(8w49,16w0x6552):response_status_good();(8w50,16w0x8708):response_status_good();(8w51,16w0xd93e):response_status_good();(8w52,16w0x43bd):response_status_good();(8w53,16w0x1d8b):response_status_good();(8w54,16w0xffd1):response_status_good();(8w55,16w0xa1e7):response_status_good();(8w56,16w0xb29b):response_status_good();(8w57,16w0xecad):response_status_good();(8w58,16w0x0ef7):response_status_good();(8w59,16w0x50c1):response_status_good();(8w60,16w0xca42):response_status_good();(8w61,16w0x9474):response_status_good();(8w62,16w0x762e):response_status_good();(8w63,16w0x2818):response_status_good();(8w64,16w0xa1ac):response_status_good();(8w65,16w0xff9a):response_status_good();(8w66,16w0x1dc0):response_status_good();(8w67,16w0x43f6):response_status_good();(8w68,16w0xd975):response_status_good();(8w69,16w0x8743):response_status_good();(8w70,16w0x6519):response_status_good();(8w71,16w0x3b2f):response_status_good();(8w72,16w0x2853):response_status_good();(8w73,16w0x7665):response_status_good();(8w74,16w0x943f):response_status_good();(8w75,16w0xca09):response_status_good();(8w76,16w0x508a):response_status_good();(8w77,16w0x0ebc):response_status_good();(8w78,16w0xece6):response_status_good();(8w79,16w0xb2d0):response_status_good();(8w80,16w0xca1e):response_status_good();(8w81,16w0x9428):response_status_good();(8w82,16w0x7672):response_status_good();(8w83,16w0x2844):response_status_good();(8w84,16w0xb2c7):response_status_good();(8w85,16w0xecf1):response_status_good();(8w86,16w0x0eab):response_status_good();(8w87,16w0x509d):response_status_good();(8w88,16w0x43e1):response_status_good();(8w89,16w0x1dd7):response_status_good();(8w90,16w0xff8d):response_status_good();(8w91,16w0xa1bb):response_status_good();(8w92,16w0x3b38):response_status_good();(8w93,16w0x650e):response_status_good();(8w94,16w0x8754):response_status_good();(8w95,16w0xd962):response_status_good();(8w96,16w0x0e85):response_status_good();(8w97,16w0x50b3):response_status_good();(8w98,16w0xb2e9):response_status_good();(8w99,16w0xecdf):response_status_good();(8w100,16w0x765c):response_status_good();(8w101,16w0x286a):response_status_good();(8w102,16w0xca30):response_status_good();(8w103,16w0x9406):response_status_good();(8w104,16w0x877a):response_status_good();(8w105,16w0xd94c):response_status_good();(8w106,16w0x3b16):response_status_good();(8w107,16w0x6520):response_status_good();(8w108,16w0xffa3):response_status_good();(8w109,16w0xa195):response_status_good();(8w110,16w0x43cf):response_status_good();(8w111,16w0x1df9):response_status_good();(8w112,16w0x6537):response_status_good();(8w113,16w0x3b01):response_status_good();(8w114,16w0xd95b):response_status_good();(8w115,16w0x876d):response_status_good();(8w116,16w0x1dee):response_status_good();(8w117,16w0x43d8):response_status_good();(8w118,16w0xa182):response_status_good();(8w119,16w0xffb4):response_status_good();(8w120,16w0xecc8):response_status_good();(8w121,16w0xb2fe):response_status_good();(8w122,16w0x50a4):response_status_good();(8w123,16w0x0e92):response_status_good();(8w124,16w0x9411):response_status_good();(8w125,16w0xca27):response_status_good();(8w126,16w0x287d):response_status_good();(8w127,16w0x764b):response_status_good();(8w128,16w0x4359):response_status_good();(8w129,16w0x1d6f):response_status_good();(8w130,16w0xff35):response_status_good();(8w131,16w0xa103):response_status_good();(8w132,16w0x3b80):response_status_good();(8w133,16w0x65b6):response_status_good();(8w134,16w0x87ec):response_status_good();(8w135,16w0xd9da):response_status_good();(8w136,16w0xcaa6):response_status_good();(8w137,16w0x9490):response_status_good();(8w138,16w0x76ca):response_status_good();(8w139,16w0x28fc):response_status_good();(8w140,16w0xb27f):response_status_good();(8w141,16w0xec49):response_status_good();(8w142,16w0x0e13):response_status_good();(8w143,16w0x5025):response_status_good();(8w144,16w0x28eb):response_status_good();(8w145,16w0x76dd):response_status_good();(8w146,16w0x9487):response_status_good();(8w147,16w0xcab1):response_status_good();(8w148,16w0x5032):response_status_good();(8w149,16w0x0e04):response_status_good();(8w150,16w0xec5e):response_status_good();(8w151,16w0xb268):response_status_good();(8w152,16w0xa114):response_status_good();(8w153,16w0xff22):response_status_good();(8w154,16w0x1d78):response_status_good();(8w155,16w0x434e):response_status_good();(8w156,16w0xd9cd):response_status_good();(8w157,16w0x87fb):response_status_good();(8w158,16w0x65a1):response_status_good();(8w159,16w0x3b97):response_status_good();(8w160,16w0xec70):response_status_good();(8w161,16w0xb246):response_status_good();(8w162,16w0x501c):response_status_good();(8w163,16w0x0e2a):response_status_good();(8w164,16w0x94a9):response_status_good();(8w165,16w0xca9f):response_status_good();(8w166,16w0x28c5):response_status_good();(8w167,16w0x76f3):response_status_good();(8w168,16w0x658f):response_status_good();(8w169,16w0x3bb9):response_status_good();(8w170,16w0xd9e3):response_status_good();(8w171,16w0x87d5):response_status_good();(8w172,16w0x1d56):response_status_good();(8w173,16w0x4360):response_status_good();(8w174,16w0xa13a):response_status_good();(8w175,16w0xff0c):response_status_good();(8w176,16w0x87c2):response_status_good();(8w177,16w0xd9f4):response_status_good();(8w178,16w0x3bae):response_status_good();(8w179,16w0x6598):response_status_good();(8w180,16w0xff1b):response_status_good();(8w181,16w0xa12d):response_status_good();(8w182,16w0x4377):response_status_good();(8w183,16w0x1d41):response_status_good();(8w184,16w0x0e3d):response_status_good();(8w185,16w0x500b):response_status_good();(8w186,16w0xb251):response_status_good();(8w187,16w0xec67):response_status_good();(8w188,16w0x76e4):response_status_good();(8w189,16w0x28d2):response_status_good();(8w190,16w0xca88):response_status_good();(8w191,16w0x94be):response_status_good();(8w192,16w0x1d0a):response_status_good();(8w193,16w0x433c):response_status_good();(8w194,16w0xa166):response_status_good();(8w195,16w0xff50):response_status_good();(8w196,16w0x65d3):response_status_good();(8w197,16w0x3be5):response_status_good();(8w198,16w0xd9bf):response_status_good();(8w199,16w0x8789):response_status_good();(8w200,16w0x94f5):response_status_good();(8w201,16w0xcac3):response_status_good();(8w202,16w0x2899):response_status_good();(8w203,16w0x76af):response_status_good();(8w204,16w0xec2c):response_status_good();(8w205,16w0xb21a):response_status_good();(8w206,16w0x5040):response_status_good();(8w207,16w0x0e76):response_status_good();(8w208,16w0x76b8):response_status_good();(8w209,16w0x288e):response_status_good();(8w210,16w0xcad4):response_status_good();(8w211,16w0x94e2):response_status_good();(8w212,16w0x0e61):response_status_good();(8w213,16w0x5057):response_status_good();(8w214,16w0xb20d):response_status_good();(8w215,16w0xec3b):response_status_good();(8w216,16w0xff47):response_status_good();(8w217,16w0xa171):response_status_good();(8w218,16w0x432b):response_status_good();(8w219,16w0x1d1d):response_status_good();(8w220,16w0x879e):response_status_good();(8w221,16w0xd9a8):response_status_good();(8w222,16w0x3bf2):response_status_good();(8w223,16w0x65c4):response_status_good();(8w224,16w0xb223):response_status_good();(8w225,16w0xec15):response_status_good();(8w226,16w0x0e4f):response_status_good();(8w227,16w0x5079):response_status_good();(8w228,16w0xcafa):response_status_good();(8w229,16w0x94cc):response_status_good();(8w230,16w0x7696):response_status_good();(8w231,16w0x28a0):response_status_good();(8w232,16w0x3bdc):response_status_good();(8w233,16w0x65ea):response_status_good();(8w234,16w0x87b0):response_status_good();(8w235,16w0xd986):response_status_good();(8w236,16w0x4305):response_status_good();(8w237,16w0x1d33):response_status_good();(8w238,16w0xff69):response_status_good();(8w239,16w0xa15f):response_status_good();(8w240,16w0xd991):response_status_good();(8w241,16w0x87a7):response_status_good();(8w242,16w0x65fd):response_status_good();(8w243,16w0x3bcb):response_status_good();(8w244,16w0xa148):response_status_good();(8w245,16w0xff7e):response_status_good();(8w246,16w0x1d24):response_status_good();(8w247,16w0x4312):response_status_good();(8w248,16w0x506e):response_status_good();(8w249,16w0x0e58):response_status_good();(8w250,16w0xec02):response_status_good();(8w251,16w0xb234):response_status_good();(8w252,16w0x28b7):response_status_good();(8w253,16w0x7681):response_status_good();(8w254,16w0x94db):response_status_good();(8w255,16w0xcaed):response_status_good();}}
action response_crct(){m.tcrc=16w0x993a;}
@stage(1) table response_crct_t{key={hdr.rtail.status:exact;hdr.rtail.crc:exact;}actions={response_crct;tail_crc_bad;}size=256;const default_action=tail_crc_bad();const entries={(8w0,16w0x8bf7):response_crct();(8w1,16w0x6c1b):response_crct();(8w2,16w0x3c63):response_crct();(8w3,16w0xdb8f):response_crct();(8w4,16w0x9c93):response_crct();(8w5,16w0x7b7f):response_crct();(8w6,16w0x2b07):response_crct();(8w7,16w0xcceb):response_crct();(8w8,16w0xa53f):response_crct();(8w9,16w0x42d3):response_crct();(8w10,16w0x12ab):response_crct();(8w11,16w0xf547):response_crct();(8w12,16w0xb25b):response_crct();(8w13,16w0x55b7):response_crct();(8w14,16w0x05cf):response_crct();(8w15,16w0xe223):response_crct();(8w16,16w0xae2a):response_crct();(8w17,16w0x49c6):response_crct();(8w18,16w0x19be):response_crct();(8w19,16w0xfe52):response_crct();(8w20,16w0xb94e):response_crct();(8w21,16w0x5ea2):response_crct();(8w22,16w0x0eda):response_crct();(8w23,16w0xe936):response_crct();(8w24,16w0x80e2):response_crct();(8w25,16w0x670e):response_crct();(8w26,16w0x3776):response_crct();(8w27,16w0xd09a):response_crct();(8w28,16w0x9786):response_crct();(8w29,16w0x706a):response_crct();(8w30,16w0x2012):response_crct();(8w31,16w0xc7fe):response_crct();(8w32,16w0xb800):response_crct();(8w33,16w0x5fec):response_crct();(8w34,16w0x0f94):response_crct();(8w35,16w0xe878):response_crct();(8w36,16w0xaf64):response_crct();(8w37,16w0x4888):response_crct();(8w38,16w0x18f0):response_crct();(8w39,16w0xff1c):response_crct();(8w40,16w0x96c8):response_crct();(8w41,16w0x7124):response_crct();(8w42,16w0x215c):response_crct();(8w43,16w0xc6b0):response_crct();(8w44,16w0x81ac):response_crct();(8w45,16w0x6640):response_crct();(8w46,16w0x3638):response_crct();(8w47,16w0xd1d4):response_crct();(8w48,16w0x9ddd):response_crct();(8w49,16w0x7a31):response_crct();(8w50,16w0x2a49):response_crct();(8w51,16w0xcda5):response_crct();(8w52,16w0x8ab9):response_crct();(8w53,16w0x6d55):response_crct();(8w54,16w0x3d2d):response_crct();(8w55,16w0xdac1):response_crct();(8w56,16w0xb315):response_crct();(8w57,16w0x54f9):response_crct();(8w58,16w0x0481):response_crct();(8w59,16w0xe36d):response_crct();(8w60,16w0xa471):response_crct();(8w61,16w0x439d):response_crct();(8w62,16w0x13e5):response_crct();(8w63,16w0xf409):response_crct();(8w64,16w0x9454):response_crct();(8w65,16w0x73b8):response_crct();(8w66,16w0x23c0):response_crct();(8w67,16w0xc42c):response_crct();(8w68,16w0x8330):response_crct();(8w69,16w0x64dc):response_crct();(8w70,16w0x34a4):response_crct();(8w71,16w0xd348):response_crct();(8w72,16w0xba9c):response_crct();(8w73,16w0x5d70):response_crct();(8w74,16w0x0d08):response_crct();(8w75,16w0xeae4):response_crct();(8w76,16w0xadf8):response_crct();(8w77,16w0x4a14):response_crct();(8w78,16w0x1a6c):response_crct();(8w79,16w0xfd80):response_crct();(8w80,16w0xb189):response_crct();(8w81,16w0x5665):response_crct();(8w82,16w0x061d):response_crct();(8w83,16w0xe1f1):response_crct();(8w84,16w0xa6ed):response_crct();(8w85,16w0x4101):response_crct();(8w86,16w0x1179):response_crct();(8w87,16w0xf695):response_crct();(8w88,16w0x9f41):response_crct();(8w89,16w0x78ad):response_crct();(8w90,16w0x28d5):response_crct();(8w91,16w0xcf39):response_crct();(8w92,16w0x8825):response_crct();(8w93,16w0x6fc9):response_crct();(8w94,16w0x3fb1):response_crct();(8w95,16w0xd85d):response_crct();(8w96,16w0xa7a3):response_crct();(8w97,16w0x404f):response_crct();(8w98,16w0x1037):response_crct();(8w99,16w0xf7db):response_crct();(8w100,16w0xb0c7):response_crct();(8w101,16w0x572b):response_crct();(8w102,16w0x0753):response_crct();(8w103,16w0xe0bf):response_crct();(8w104,16w0x896b):response_crct();(8w105,16w0x6e87):response_crct();(8w106,16w0x3eff):response_crct();(8w107,16w0xd913):response_crct();(8w108,16w0x9e0f):response_crct();(8w109,16w0x79e3):response_crct();(8w110,16w0x299b):response_crct();(8w111,16w0xce77):response_crct();(8w112,16w0x827e):response_crct();(8w113,16w0x6592):response_crct();(8w114,16w0x35ea):response_crct();(8w115,16w0xd206):response_crct();(8w116,16w0x951a):response_crct();(8w117,16w0x72f6):response_crct();(8w118,16w0x228e):response_crct();(8w119,16w0xc562):response_crct();(8w120,16w0xacb6):response_crct();(8w121,16w0x4b5a):response_crct();(8w122,16w0x1b22):response_crct();(8w123,16w0xfcce):response_crct();(8w124,16w0xbbd2):response_crct();(8w125,16w0x5c3e):response_crct();(8w126,16w0x0c46):response_crct();(8w127,16w0xebaa):response_crct();(8w128,16w0xccfc):response_crct();(8w129,16w0x2b10):response_crct();(8w130,16w0x7b68):response_crct();(8w131,16w0x9c84):response_crct();(8w132,16w0xdb98):response_crct();(8w133,16w0x3c74):response_crct();(8w134,16w0x6c0c):response_crct();(8w135,16w0x8be0):response_crct();(8w136,16w0xe234):response_crct();(8w137,16w0x05d8):response_crct();(8w138,16w0x55a0):response_crct();(8w139,16w0xb24c):response_crct();(8w140,16w0xf550):response_crct();(8w141,16w0x12bc):response_crct();(8w142,16w0x42c4):response_crct();(8w143,16w0xa528):response_crct();(8w144,16w0xe921):response_crct();(8w145,16w0x0ecd):response_crct();(8w146,16w0x5eb5):response_crct();(8w147,16w0xb959):response_crct();(8w148,16w0xfe45):response_crct();(8w149,16w0x19a9):response_crct();(8w150,16w0x49d1):response_crct();(8w151,16w0xae3d):response_crct();(8w152,16w0xc7e9):response_crct();(8w153,16w0x2005):response_crct();(8w154,16w0x707d):response_crct();(8w155,16w0x9791):response_crct();(8w156,16w0xd08d):response_crct();(8w157,16w0x3761):response_crct();(8w158,16w0x6719):response_crct();(8w159,16w0x80f5):response_crct();(8w160,16w0xff0b):response_crct();(8w161,16w0x18e7):response_crct();(8w162,16w0x489f):response_crct();(8w163,16w0xaf73):response_crct();(8w164,16w0xe86f):response_crct();(8w165,16w0x0f83):response_crct();(8w166,16w0x5ffb):response_crct();(8w167,16w0xb817):response_crct();(8w168,16w0xd1c3):response_crct();(8w169,16w0x362f):response_crct();(8w170,16w0x6657):response_crct();(8w171,16w0x81bb):response_crct();(8w172,16w0xc6a7):response_crct();(8w173,16w0x214b):response_crct();(8w174,16w0x7133):response_crct();(8w175,16w0x96df):response_crct();(8w176,16w0xdad6):response_crct();(8w177,16w0x3d3a):response_crct();(8w178,16w0x6d42):response_crct();(8w179,16w0x8aae):response_crct();(8w180,16w0xcdb2):response_crct();(8w181,16w0x2a5e):response_crct();(8w182,16w0x7a26):response_crct();(8w183,16w0x9dca):response_crct();(8w184,16w0xf41e):response_crct();(8w185,16w0x13f2):response_crct();(8w186,16w0x438a):response_crct();(8w187,16w0xa466):response_crct();(8w188,16w0xe37a):response_crct();(8w189,16w0x0496):response_crct();(8w190,16w0x54ee):response_crct();(8w191,16w0xb302):response_crct();(8w192,16w0xd35f):response_crct();(8w193,16w0x34b3):response_crct();(8w194,16w0x64cb):response_crct();(8w195,16w0x8327):response_crct();(8w196,16w0xc43b):response_crct();(8w197,16w0x23d7):response_crct();(8w198,16w0x73af):response_crct();(8w199,16w0x9443):response_crct();(8w200,16w0xfd97):response_crct();(8w201,16w0x1a7b):response_crct();(8w202,16w0x4a03):response_crct();(8w203,16w0xadef):response_crct();(8w204,16w0xeaf3):response_crct();(8w205,16w0x0d1f):response_crct();(8w206,16w0x5d67):response_crct();(8w207,16w0xba8b):response_crct();(8w208,16w0xf682):response_crct();(8w209,16w0x116e):response_crct();(8w210,16w0x4116):response_crct();(8w211,16w0xa6fa):response_crct();(8w212,16w0xe1e6):response_crct();(8w213,16w0x060a):response_crct();(8w214,16w0x5672):response_crct();(8w215,16w0xb19e):response_crct();(8w216,16w0xd84a):response_crct();(8w217,16w0x3fa6):response_crct();(8w218,16w0x6fde):response_crct();(8w219,16w0x8832):response_crct();(8w220,16w0xcf2e):response_crct();(8w221,16w0x28c2):response_crct();(8w222,16w0x78ba):response_crct();(8w223,16w0x9f56):response_crct();(8w224,16w0xe0a8):response_crct();(8w225,16w0x0744):response_crct();(8w226,16w0x573c):response_crct();(8w227,16w0xb0d0):response_crct();(8w228,16w0xf7cc):response_crct();(8w229,16w0x1020):response_crct();(8w230,16w0x4058):response_crct();(8w231,16w0xa7b4):response_crct();(8w232,16w0xce60):response_crct();(8w233,16w0x298c):response_crct();(8w234,16w0x79f4):response_crct();(8w235,16w0x9e18):response_crct();(8w236,16w0xd904):response_crct();(8w237,16w0x3ee8):response_crct();(8w238,16w0x6e90):response_crct();(8w239,16w0x897c):response_crct();(8w240,16w0xc575):response_crct();(8w241,16w0x2299):response_crct();(8w242,16w0x72e1):response_crct();(8w243,16w0x950d):response_crct();(8w244,16w0xd211):response_crct();(8w245,16w0x35fd):response_crct();(8w246,16w0x6585):response_crct();(8w247,16w0x8269):response_crct();(8w248,16w0xebbd):response_crct();(8w249,16w0x0c51):response_crct();(8w250,16w0x5c29):response_crct();(8w251,16w0xbbc5):response_crct();(8w252,16w0xfcd9):response_crct();(8w253,16w0x1b35):response_crct();(8w254,16w0x4b4d):response_crct();(8w255,16w0xaca1):response_crct();}}
 action available(){m.work_op=8w1;}
 table available_t{key={m.generation:exact;}actions={available;NoAction;}size=1;const entries={32w0:NoAction();}const default_action=available();}
 Register<bit<32>,bit<1>>(1,0) epoch;
 RegisterAction<bit<32>,bit<1>,bit<32>>(epoch) read_epoch={void apply(inout bit<32> v,out bit<32> r){r=v;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(epoch) read_epoch_diff={void apply(inout bit<32> v,out bit<32> r){r=v-hdr.envelope.epoch;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(epoch) write_epoch={void apply(inout bit<32> v,out bit<32> r){if(v==hdr.origin.normalized_epoch){v=hdr.envelope.epoch;r=32w0;}else{r=32w1;}}};
 action load_epoch(){m.epoch=read_epoch.execute(1w0);}
 action diff_epoch(){m.epoch_diff=read_epoch_diff.execute(1w0);}
 action store_epoch(){m.epoch_diff=write_epoch.execute(1w0);}
 Register<bit<32>,bit<1>>(1,0) retry_epoch;
 RegisterAction<bit<32>,bit<1>,bit<2>>(retry_epoch) check_retry_epoch={void apply(inout bit<32> v,out bit<2> r){if(v==hdr.envelope.epoch){r=2w1;}else{r=2w2;}}};
 RegisterAction<bit<32>,bit<1>,bit<2>>(retry_epoch) note_retry_epoch={void apply(inout bit<32> v,out bit<2> r){v=hdr.envelope.epoch;r=2w0;}};
 RegisterAction<bit<32>,bit<1>,bit<2>>(retry_epoch) clear_retry_epoch={void apply(inout bit<32> v,out bit<2> r){if(v==hdr.envelope.epoch){v=32w0;}r=2w0;}};
 action retry_epoch_check(){m.retry=check_retry_epoch.execute(1w0);}
 action retry_epoch_note(){note_retry_epoch.execute(1w0);}
 action retry_epoch_clear(){clear_retry_epoch.execute(1w0);}
 table retry_epoch_t{key={m.stage:exact;m.kind:exact;m.retry:exact;hdr.origin.normalized_epoch[15:0]:ternary;}actions={retry_epoch_check;retry_epoch_note;retry_epoch_clear;NoAction;}size=5;const default_action=NoAction();const entries={(2w0,8w0,2w1,_):retry_epoch_check();(2w2,8w1,2w0,_):retry_epoch_note();(2w2,8w4,2w0,16w0x200):retry_epoch_clear();(2w2,8w4,2w0,16w0x10f):retry_epoch_clear();(2w2,8w17,2w0,16w0x10f):retry_epoch_clear();}}
 action retry_mark_stale(){m.retry=2w2;}
 table retry_valid_t{key={m.retry:exact;m.direction:ternary;hdr.expected_cell.expected_cell:ternary;}actions={retry_mark_stale;NoAction;}size=7;const default_action=retry_mark_stale();
 const entries={(2w0,_,_):NoAction();(2w2,_,_):NoAction();(2w1,_,32w0):retry_mark_stale();(2w1,2w2,32w0&&&32w0xffffffe0):NoAction();(2w1,2w2,32w32):NoAction();(2w1,2w1,32w0&&&32w0xffffffe0):NoAction();(2w1,2w1,32w32):NoAction();}}
 table epoch_t{key={m.stage:ternary;m.kind:ternary;m.work_phase:ternary;m.work_op:ternary;}actions={load_epoch;diff_epoch;store_epoch;}size=3;
 const entries={(2w1,8w1,32w1,8w2):store_epoch();(2w0,_,_,_):load_epoch();}const default_action=diff_epoch();}
 Register<bit<32>,bit<1>>(1,0) client;
 RegisterAction<bit<32>,bit<1>,bit<32>>(client) read_client={void apply(inout bit<32> v,out bit<32> r){r=v;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(client) write_client={void apply(inout bit<32> v,out bit<32> r){r=v;v=m.new_seq;}};
 action load_client(){m.client=read_client.execute(1w0);}
 action store_client(){m.client=write_client.execute(1w0);}
 table client_t{key={m.stage:exact;m.kind:exact;m.work_phase:exact;m.work_op:exact;m.epoch_diff:exact;}actions={load_client;store_client;}size=4;
 const entries={(2w1,8w1,32w1,8w2,32w0):store_client();(2w1,8w5,32w1,8w2,32w0):store_client();(2w1,8w7,32w1,8w2,32w0):store_client();(2w1,8w9,32w1,8w2,32w0):store_client();}const default_action=load_client();}
 Register<bit<32>,bit<1>>(1,0) server;
 RegisterAction<bit<32>,bit<1>,bit<32>>(server) read_server={void apply(inout bit<32> v,out bit<32> r){r=v;}};
 RegisterAction<bit<32>,bit<1>,bit<32>>(server) write_server={void apply(inout bit<32> v,out bit<32> r){r=v;v=m.new_seq;}};
 action load_server(){m.server=read_server.execute(1w0);}
 action store_server(){m.server=write_server.execute(1w0);}
 table server_t{key={m.stage:exact;m.kind:exact;m.work_phase:exact;m.work_op:exact;m.epoch_diff:exact;}actions={load_server;store_server;}size=4;
 const entries={(2w1,8w2,32w1,8w2,32w0):store_server();(2w1,8w6,32w1,8w2,32w0):store_server();(2w1,8w11,32w1,8w2,32w0):store_server();(2w1,8w16,32w1,8w2,32w0):store_server();}const default_action=load_server();}
 action next_seq(){m.new_seq=hdr.tcp.seq+32w1;m.next_owner_gen=hdr.expected_cell.expected_cell+32w1;}
 action next_control(){m.new_seq=hdr.tcp.seq+32w45;}
 action next_response(){m.new_seq=hdr.tcp.seq+32w49;}
 action next_read_request(){m.new_seq=hdr.tcp.seq+32w20;}
 action next_read_response(){m.new_seq=hdr.tcp.seq+32w49;}
 action next_read_len(bit<32> n){m.new_seq=hdr.tcp.seq+n;}
 table next_seq_t{key={m.packet_kind:exact;hdr.dl.len:ternary;}actions={next_seq;next_control;next_response;next_read_request;next_read_response;next_read_len;}size=10;const entries={(8w5,_):next_control();(8w7,_):next_control();(8w6,_):next_response();(8w9,8w0x14):next_read_len(27);(8w9,8w0x12):next_read_len(25);(8w11,8w0x4c):next_read_len(91);(8w11,8w0x73):next_read_len(134);(8w9,_):next_read_request();(8w11,_):next_read_response();}const default_action=next_seq();}
 action diff_syn(){m.client_diff=hdr.tcp.ack;m.server_diff=m.new_seq-m.client;}
 action diff_synack(){m.client_diff=hdr.tcp.ack-m.client;m.server_diff=m.new_seq-m.server;}
 action diff_forward(){m.client_diff=hdr.tcp.seq-m.client;m.server_diff=hdr.tcp.ack-m.server;}
 action diff_reverse(){m.client_diff=hdr.tcp.seq-m.server;m.server_diff=hdr.tcp.ack-m.client;}
 action diff_reset_forward(){m.client_diff=hdr.tcp.seq-m.client;m.server_diff=32w0;}
 action diff_reset_reverse(){m.client_diff=hdr.tcp.seq-m.server;m.server_diff=32w0;}
 action ack_native(){m.ack_native=hdr.tcp.ack;}
 table ack_native_t{actions={ack_native;}size=1;const default_action=ack_native();}
 action diff_response(){m.client_diff=m.ack_native-m.client;m.server_diff=hdr.tcp.seq-m.server;}
 action diff_read_response(){m.client_diff=hdr.tcp.ack-m.client;m.server_diff=hdr.tcp.seq-m.server;}
 table sequence_diff{key={m.packet_kind:ternary;m.direction:ternary;hdr.tcp.flags:ternary;}
 actions={diff_syn;diff_synack;diff_forward;diff_reverse;diff_reset_forward;diff_reset_reverse;diff_response;diff_read_response;NoAction;}size=20;const default_action=NoAction();
 const entries={(8w5,_,_):diff_forward();(8w6,_,_):diff_response();(8w7,_,_):diff_forward();(8w9,_,_):diff_forward();(8w11,_,_):diff_read_response();(_,2w1,8w2):diff_syn();(_,2w2,8w18):diff_synack();(_,2w1,8w16):diff_forward();(_,2w1,8w17&&&8w0xf7):diff_forward();(_,2w2,8w17&&&8w0xf7):diff_reverse();(_,2w1,8w20):diff_forward();(_,2w2,8w20):diff_reverse();(_,2w1,8w4):diff_reset_forward();(_,2w2,8w4):diff_reset_reverse();(8w3,2w2,8w16):diff_reverse();}}
 
 
 
 
 
 
   /* a FIN's sequence byte, phase 7 only */
 
 action epoch_ok(){m.epoch_valid=(bit<1>)(8w1);}
 table epoch_guard{key={m.epoch_diff:exact;}actions={epoch_ok;NoAction;}size=1;const entries={32w0:epoch_ok();}const default_action=NoAction();}
 action claim_syn(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w1++m.next_owner_gen[15:0];m.owner_op=(bit<1>)(8w1);}
 action claim_synack(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.expected_cell.expected_cell+32w0x10000;m.owner_op=(bit<1>)(8w1);}
 action claim_ack(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.expected_cell.expected_cell+32w0x10000;m.owner_op=(bit<1>)(8w1);}
 action publish_syn(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.expected_cell.expected_cell+32w0x10000;m.owner_op=(bit<1>)(8w1);}
 action publish_synack(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.expected_cell.expected_cell+32w0x10000;m.owner_op=(bit<1>)(8w1);}
 action publish_ack(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.expected_cell.expected_cell;m.owner_op=(bit<1>)(8w1);}
 action close_owner(){m.expected=hdr.expected_cell.expected_cell;m.desired=hdr.origin.normalized_epoch[15:0]++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
 action close_pending(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w6++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
 action close_free(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w7++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action quarantine_abort(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w6++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_select(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w8++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_select(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w9++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_response(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w10++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_response_failure(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w5++hdr.expected_cell.expected_cell[15:0];m.owner_op=1w1;}
action publish_response(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w10++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_operate(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w11++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_operate(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w12++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_read(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w13++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_read(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w14++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_read_rsp(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w15++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_read_rsp(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w5++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action claim_response_op(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w16++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
action publish_response_op(){m.expected=hdr.expected_cell.expected_cell;m.desired=16w5++hdr.expected_cell.expected_cell[15:0];m.owner_op=(bit<1>)(8w1);}
 table owner_command{key={m.stage:exact;m.kind:exact;m.work_phase:ternary;m.epoch_diff:exact;m.return_abort:ternary;hdr.rtail.status:ternary;hdr.cstatus.status:ternary;hdr.first.w1[31:24]:ternary;}
 actions={close_owner;claim_syn;claim_synack;claim_ack;publish_syn;publish_synack;publish_ack;close_pending;close_free;quarantine_abort;claim_select;publish_select;claim_response;publish_response;publish_response_failure;claim_operate;publish_operate;claim_read;publish_read;claim_read_rsp;publish_read_rsp;claim_response_op;publish_response_op;NoAction;}size=23;const default_action=NoAction();
 const entries={(2w1,8w4,32w4,32w0,1w0,_,_,_):close_owner();(2w1,8w17,32w1,32w0,1w0,_,_,_):close_owner();(2w1,8w1,32w1,32w0,_,_,_,_):claim_syn();(2w1,8w2,32w1,32w0,_,_,_,_):claim_synack();(2w1,8w3,32w1,32w0,_,_,_,_):claim_ack();(2w2,8w1,32w2,32w0,_,_,_,_):publish_syn();(2w2,8w2,32w2,32w0,_,_,_,_):publish_synack();(2w2,8w3,32w2,32w0,_,_,_,_):publish_ack();(2w1,8w5,32w1,32w0,_,_,_,_):claim_select();(2w2,8w5,32w2,32w0,_,_,_,_):publish_select();(2w1,8w6,32w1,32w0,_,_,_,_):claim_response();(2w2,8w6,32w2,32w0,_,8w0,8w0,8w0):publish_response();(2w2,8w6,32w2,32w0,_,_,_,_):publish_response_failure();(2w1,8w7,32w1,32w0,_,_,_,_):claim_operate();(2w2,8w7,32w2,32w0,_,_,_,_):publish_operate();(2w1,8w9,32w1,32w0,_,_,_,_):claim_read();(2w2,8w9,32w2,32w0,_,_,_,_):publish_read();(2w1,8w11,32w1,32w0,_,_,_,_):claim_read_rsp();(2w2,8w11,32w2,32w0,_,_,_,_):publish_read_rsp();(2w1,8w16,32w1,32w0,_,_,_,_):claim_response_op();(2w2,8w16,32w2,32w0,_,_,_,_):publish_response_op();(2w2,8w255,32w2,32w0,1w1,_,_,_):quarantine_abort();(2w3,8w255,32w3,32w0,1w1,_,_,_):quarantine_abort();}}
 action owner_read(){m.observed=read_owner.execute(1w0);}
 action owner_cas(){m.owner_diff=compare_owner.execute(1w0);}
 action owner_check(){m.owner_diff=check_owner.execute(1w0);}
 table owner_t{key={m.stage:ternary;m.owner_op:exact;}actions={owner_read;owner_cas;owner_check;}size=2;const entries={(_,1w1):owner_cas();(2w0,1w0):owner_read();}const default_action=owner_check();}
 action snapshot(){hdr.envelope.setValid();hdr.work_generation.setValid();hdr.expected_cell.setValid();hdr.event.setValid();hdr.work_generation.generation=m.generation;hdr.envelope.epoch=m.epoch;hdr.event.phase=8w1;hdr.event.code=8w255;hdr.event.reserved=16w0;hdr.origin.setValid();hdr.origin.wire_ack=m.wire_ack;hdr.origin.normalized_epoch=m.normalized_epoch;m.emit_loop=(bit<1>)(8w1);tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
 action snapshot_retry(){hdr.envelope.setValid();hdr.work_generation.setValid();hdr.expected_cell.setValid();hdr.event.setValid();hdr.work_generation.generation=m.generation;hdr.envelope.epoch=m.epoch;hdr.event.phase=8w1;hdr.event.code=8w255;hdr.origin.setValid();hdr.origin.wire_ack=m.wire_ack;hdr.origin.normalized_epoch=m.normalized_epoch;m.emit_loop=(bit<1>)(8w1);tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
 action snapshot_lap_retry(){snapshot_retry();hdr.envelope.epoch=m.normalized_epoch;}
 action snapshot_lap(){snapshot();hdr.envelope.epoch=m.normalized_epoch;}
 action snapshot_epoch_zero(){hdr.envelope.setValid();hdr.work_generation.setValid();hdr.expected_cell.setValid();hdr.event.setValid();hdr.work_generation.generation=m.generation;hdr.envelope.epoch=32w0xffffffff;hdr.event.phase=8w1;hdr.event.code=8w255;hdr.event.reserved=16w0;hdr.origin.setValid();hdr.origin.wire_ack=m.wire_ack;hdr.origin.normalized_epoch=m.normalized_epoch;m.emit_loop=(bit<1>)(8w1);tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
 table snapshot_t{key={m.lap:ternary;m.epoch:ternary;m.retry:ternary;m.direction:ternary;}actions={snapshot;snapshot_lap;snapshot_epoch_zero;snapshot_retry;snapshot_lap_retry;}size=4;const entries={(1w1,_,_,_):snapshot_lap();(_,32w0,_,_):snapshot_epoch_zero();(_,_,2w1,2w1):snapshot_lap_retry();(_,_,2w1,_):snapshot_retry();}const default_action=snapshot();}
 action first_syn(){hdr.envelope.epoch=m.generation;hdr.event.phase=8w1;hdr.event.code=8w1;}
 action first_synack(){hdr.event.phase=8w1;hdr.event.code=8w2;}
 action first_ack(){hdr.event.phase=8w1;hdr.event.code=8w3;}
 action first_close_ack(){hdr.origin.normalized_epoch=m.desired;hdr.event.phase=8w1;hdr.event.code=8w17;}
 action first_close_ack_qualified(bit<16> phase){hdr.origin.normalized_epoch=(bit<32>)phase;hdr.event.phase=8w1;hdr.event.code=8w17;}


 action first_close(){hdr.origin.normalized_epoch=m.desired;hdr.event.phase=8w1;hdr.event.code=8w4;hdr.work_generation.generation=hdr.envelope.epoch;}
 action first_close_qualified(bit<16> phase){hdr.origin.normalized_epoch=(bit<32>)phase;hdr.event.phase=8w1;hdr.event.code=8w4;hdr.work_generation.generation=hdr.envelope.epoch;}
action first_select(){hdr.event.phase=8w1;hdr.event.code=8w5;}
action first_response(){hdr.event.phase=8w1;hdr.event.code=8w6;}
action first_operate(){hdr.event.phase=8w1;hdr.event.code=8w7;hdr.t0.setValid();hdr.t0.t0q=32w0;}
 action forward_original(){hdr.event.phase=8w1;hdr.event.code=8w8;}
 action forward_retry_duplicate(){hdr.event.phase=8w1;hdr.event.code=8w255;hdr.t0.setInvalid();}
 action first_response_dup(){hdr.event.phase=8w1;hdr.event.code=8w25;}
 action first_operate_dup(){hdr.event.phase=8w1;hdr.event.code=8w24;hdr.t0.setValid();hdr.t0.t0q=32w0;}
action first_request_dup(){hdr.event.phase=8w1;hdr.event.code=8w24;hdr.t0.setValid();hdr.t0.t0q=32w0;}
 action first_response_op(){hdr.event.phase=8w1;hdr.event.code=8w16;}
 action first_replay(){hdr.event.phase=8w1;hdr.event.code=8w12;}
 action count_refused(){}
 action count_resent(){}
 action count_replay_refused(){}
 action first_read_request(){hdr.event.phase=8w1;hdr.event.code=8w9;hdr.t0.setValid();hdr.t0.t0q=32w0;}
 action first_read_ack(){hdr.event.phase=8w1;hdr.event.code=8w10;hdr.t0.setValid();hdr.t0.t0q=32w0;}
 action first_read_response(){hdr.event.phase=8w1;hdr.event.code=8w11;hdr.t0.setValid();hdr.t0.t0q=32w0;}
 action close_forward(){hdr.envelope.setInvalid();hdr.work_generation.setInvalid();hdr.expected_cell.setInvalid();hdr.event.setInvalid();m.emit_loop=(bit<1>)(8w0);tm.ucast_egress_port=m.output_port;tm.bypass_egress=1w0;}
 @stage(9) table first_event{key={m.kind:ternary;m.matched:ternary;m.observed:ternary;m.client_diff:ternary;m.server_diff:ternary;m.direction:ternary;hdr.tcp.flags:ternary;m.new_seq:ternary;m.same_syn:ternary;m.retry:ternary;hdr.dl.len:ternary;m.diff_application:ternary;m.diff_real_links:ternary;m.diff_real_tcp_dst:ternary;m.diff_native_end:ternary;m.response:ternary;}
 actions={first_close_qualified;first_close_ack_qualified;first_close_ack;first_syn;first_synack;first_ack;first_close;first_select;first_response;first_operate;first_read_request;first_read_ack;first_read_response;first_response_op;first_replay;count_refused;count_resent;count_replay_refused;forward_original;forward_retry_duplicate;first_operate_dup;first_request_dup;first_response_dup;close_forward;NoAction;}size=405;const default_action=NoAction();
 const entries={(8w9,1w1,32w0xe0000&&&32w0xffff0000,32w0xffffffe7,32w0x00000000,2w1,8w24,_,_,_,8w0x12,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe7,32w0x00000000,2w1,8w24,_,_,_,8w0x12,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe7,32w0xffffffa5,2w1,8w24,_,_,_,8w0x12,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe7,32w0xffffff7a,2w1,8w24,_,_,_,8w0x12,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0xe0000&&&32w0xffff0000,32w0xffffffe5,32w0x00000000,2w1,8w24,_,_,_,8w0x14,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe5,32w0x00000000,2w1,8w24,_,_,_,8w0x14,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe5,32w0xffffffa5,2w1,8w24,_,_,_,8w0x14,_,_,_,_,_):first_request_dup();(8w9,1w1,32w0x50000&&&32w0xffff0000,32w0xffffffe5,32w0xffffff7a,2w1,8w24,_,_,_,8w0x14,_,_,_,_,_):first_request_dup();(8w5,_,32w0x90000&&&32w0xffff0000,32w0xffffffd3,32w0x00000000,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w5,_,32w0x90000&&&32w0xffff0000,32w0xffffffd3,32w0xffffffcf,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w5,_,32w0xa0000&&&32w0xffff0000,32w0xffffffd3,32w0x00000000,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w5,_,32w0xa0000&&&32w0xffff0000,32w0xffffffd3,32w0xffffffcf,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w5,_,32w0x50000&&&32w0xffff0000,32w0xffffffd3,32w0x00000000,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w5,_,32w0x50000&&&32w0xffff0000,32w0xffffffd3,32w0xffffffcf,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_request_dup();(8w7,_,32w0xc0000&&&32w0xffff0000,32w0xffffffd3,32w0x00000000,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_operate_dup();(8w7,_,32w0xc0000&&&32w0xffff0000,32w0xffffffd3,32w0xffffffcf,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_operate_dup();(8w7,_,32w0x50000&&&32w0xffff0000,32w0xffffffd3,32w0x00000000,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_operate_dup();(8w7,_,32w0x50000&&&32w0xffff0000,32w0xffffffd3,32w0xffffffcf,2w1,8w24,_,_,_,8w0x24,16w0x0&&&16w0xffff,_,_,_,_):first_operate_dup();(8w10,_,32w0x50000&&&32w0xffff0000,32w0xffffffcf&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w2,8w16,_,_,_,_,_,_,_,_,_):first_read_ack();(8w10,_,32w0x50000&&&32w0xffff0000,32w0xffffffa5&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w2,8w16,_,_,_,_,_,_,_,_,_):first_read_ack();(8w10,_,32w0x50000&&&32w0xffff0000,32w0xffffff7a&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w2,8w16,_,_,_,_,_,_,_,_,_):first_read_ack();(8w10,_,32w0xa0000&&&32w0xffff0000,32w0xffffffcf&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w2,8w16,_,_,_,_,_,_,_,_,_):first_read_ack();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,2w1,_,_,_,_,_,_):forward_retry_duplicate();(8w1,_,32w17760256&&&32w0xffff0000,_,_,_,_,_,1w1,_,_,_,_,_,_,_):NoAction();(8w1,_,32w33554432&&&32w0xffff0000,_,_,_,_,_,1w1,_,_,_,_,_,_,_):NoAction();(8w4,1w0,32w0x20000&&&32w0xffff0000,_,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x14&&&8w0xff,32w1,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w1,_,32w0xffff&&&32w0xffff,_,_,_,_,_,_,_,_,_,_,_,_,_):NoAction();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2&&&32w0x80000002,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4&&&32w0x80000006,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8&&&32w0x8000000e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10&&&32w0x8000001e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20&&&32w0x8000003e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40&&&32w0x8000007e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80&&&32w0x800000fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100&&&32w0x800001fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200&&&32w0x800003fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400&&&32w0x800007fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800&&&32w0x80000ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000&&&32w0x80001ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000&&&32w0x80003ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000&&&32w0x80007ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000&&&32w0x8000fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000&&&32w0x8001fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000&&&32w0x8003fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000&&&32w0x8007fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80000&&&32w0x800ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100000&&&32w0x801ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200000&&&32w0x803ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400000&&&32w0x807ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800000&&&32w0x80fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000000&&&32w0x81fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000000&&&32w0x83fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000000&&&32w0x87fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000000&&&32w0x8ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000000&&&32w0x9ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000000&&&32w0xbffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w17760256&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000000&&&32w0xfffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2&&&32w0x80000002,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4&&&32w0x80000006,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8&&&32w0x8000000e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10&&&32w0x8000001e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20&&&32w0x8000003e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40&&&32w0x8000007e,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80&&&32w0x800000fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100&&&32w0x800001fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200&&&32w0x800003fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400&&&32w0x800007fe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800&&&32w0x80000ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000&&&32w0x80001ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000&&&32w0x80003ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000&&&32w0x80007ffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000&&&32w0x8000fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000&&&32w0x8001fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000&&&32w0x8003fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000&&&32w0x8007fffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80000&&&32w0x800ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100000&&&32w0x801ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200000&&&32w0x803ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400000&&&32w0x807ffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800000&&&32w0x80fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000000&&&32w0x81fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000000&&&32w0x83fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000000&&&32w0x87fffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000000&&&32w0x8ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000000&&&32w0x9ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000000&&&32w0xbffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w1,1w0,32w33554432&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000000&&&32w0xfffffffe,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w3,_,32w0x1010000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w257);(8w4,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w257);(8w4,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w257);(8w4,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w259);(8w4,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w265);(8w4,_,32w0x1010000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w3,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w258);(8w4,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w259);(8w4,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w262);(8w4,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w10,_,32w0x1020000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w258);(8w4,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w258);(8w4,_,32w0x1020000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x1030000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w259);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w259);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x1030000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w263);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w10,_,32w0x1030000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w259);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w259);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x1030000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w267);(8w4,_,32w0x1030000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w3,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w260);(8w4,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w261);(8w4,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w260);(8w4,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w262);(8w4,_,32w0x1040000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x1050000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w261);(8w4,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w261);(8w4,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w261);(8w4,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w4,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w269);(8w4,_,32w0x1050000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w3,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w262);(8w4,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w4,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w262);(8w4,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w10,_,32w0x1060000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w262);(8w4,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w262);(8w4,_,32w0x1060000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x1070000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w263);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x1070000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w263);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w10,_,32w0x1070000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w263);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w263);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x1070000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x1070000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w3,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w264);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w265);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w264);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w266);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x1090000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w265);(8w4,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w265);(8w4,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w265);(8w4,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w4,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w265);(8w4,_,32w0x1090000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w3,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w266);(8w4,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w4,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w270);(8w4,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w10,_,32w0x10a0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w266);(8w4,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w266);(8w4,_,32w0x10a0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x10b0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w267);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x10b0000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w10,_,32w0x10b0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w267);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x10b0000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w267);(8w4,_,32w0x10b0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w267);(8w3,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w268);(8w4,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w269);(8w4,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w268);(8w4,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w270);(8w4,_,32w0x10c0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x10d0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w269);(8w4,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w269);(8w4,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w10,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w269);(8w4,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w4,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w269);(8w4,_,32w0x10d0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w3,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w270);(8w4,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w4,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w270);(8w4,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w10,_,32w0x10e0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w270);(8w4,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w270);(8w4,_,32w0x10e0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w3,_,32w0x10f0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w3,_,32w0x10f0000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w10,_,32w0x10f0000&&&32w0xffff0000,32w1,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w10,_,32w0x10f0000&&&32w0xffff0000,32w1,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x10&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_ack_qualified(16w271);(8w4,_,32w0x10f0000&&&32w0xffff0000,32w0,32w0x1&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w271);(8w1,1w0,32w0,32w0,_,_,_,_,_,_,_,_,_,_,_,_):first_syn();(8w2,1w0,32w0x20001,32w0,_,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2&&&32w0x80000002,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4&&&32w0x80000006,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8&&&32w0x8000000e,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10&&&32w0x8000001e,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20&&&32w0x8000003e,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40&&&32w0x8000007e,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80&&&32w0x800000fe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100&&&32w0x800001fe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200&&&32w0x800003fe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400&&&32w0x800007fe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800&&&32w0x80000ffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000&&&32w0x80001ffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000&&&32w0x80003ffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000&&&32w0x80007ffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000&&&32w0x8000fffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000&&&32w0x8001fffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000&&&32w0x8003fffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000&&&32w0x8007fffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x80000&&&32w0x800ffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x100000&&&32w0x801ffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x200000&&&32w0x803ffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x400000&&&32w0x807ffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x800000&&&32w0x80fffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x1000000&&&32w0x81fffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x2000000&&&32w0x83fffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x4000000&&&32w0x87fffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x8000000&&&32w0x8ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x10000000&&&32w0x9ffffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x20000000&&&32w0xbffffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w2,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x40000000&&&32w0xfffffffe,_,_,_,_,_,_,_,_,_,_,_):first_synack();(8w3,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_ack();(8w4,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0xffffffcf&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0xffffff7a&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0xffffffa5&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0xffffffcf&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0xffffffcf&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w5,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_select();(8w5,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_select();(8w6,_,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0x300&&&16w0xffff,8w0,8w0,8w0,1w1):first_response();(8w6,_,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0x400&&&16w0xffff,8w0,8w0,8w0,1w1):first_response();(8w7,_,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0xfeff&&&16w0xffff,8w0,8w0,8w0,1w0):first_operate();(8w7,_,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0xff0f&&&16w0xffff,8w0,8w0,8w0,1w0):first_operate();(8w9,_,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_request();(8w5,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_select();(8w4,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xd0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xd0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xd0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xd0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xd0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w4,1w0,32w0xf0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xf0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,1w0,32w0xf0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x1&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x101);(8w4,1w0,32w0xf0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,2w0x2&&&2w0x3,8w0x11&&&8w0xf7,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x102);(8w4,1w0,32w0xf0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_close();(8w1,1w0,32w0x20000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w1,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w2,1w0,32w0x30000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w2,1w0,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w2,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0x80000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xb0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();/* c74: the late handshake ACK, old pure ACK at the admitted READ start, forwarded unchanged */(8w3,1w0,32w0xd0000&&&32w0xffff0000,32w0xffffffe7,32w0x00000000,2w1,8w0x10,_,1w0,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xe0000&&&32w0xffff0000,32w0xffffffe7,32w0x00000000,2w1,8w0x10,_,1w0,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xd0000&&&32w0xffff0000,32w0xffffffe5,32w0x00000000,2w1,8w0x10,_,1w0,_,_,_,_,_,_,_):forward_original();(8w3,1w0,32w0xe0000&&&32w0xffff0000,32w0xffffffe5,32w0x00000000,2w1,8w0x10,_,1w0,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_request();(8w9,_,32w0x40000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_request();(8w11,1w1,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_response();(8w10,1w0,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_ack();(8w10,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w10,_,32w0x90000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_ack();(8w10,_,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w10,_,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_read_ack();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0x300&&&16w0xffff,8w0,8w0,8w0,1w1):first_response_op();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0x400&&&16w0xffff,8w0,8w0,8w0,1w1):first_response_op();(8w12,1w0,32w0x90000&&&32w0xffff0000,32w0xffffffff&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_replay();(8w12,1w0,32w0xc0000&&&32w0xffff0000,32w0xffffffff&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_replay();(8w12,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_replay_refused();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffec&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffec&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffe5&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffe5&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffe7&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0xe0000&&&32w0xffff0000,32w0xffffffe7&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffec&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffec&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffe5&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffe5&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffe7&&&32w0xffffffff,32w0x0&&&32w0x7fffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w9,_,32w0x50000&&&32w0xffff0000,32w0xffffffe7&&&32w0xffffffff,32w0x80000000&&&32w0x80000000,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0xe0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffff7a&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w11,_,32w0x50000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffa5&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w6,_,32w0xa0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w6,_,32w0xa0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w6,_,32w0xc0000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w6,_,32w0x50000&&&32w0xffff0000,32w0x0&&&32w0x7fffffff,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w6,_,32w0x50000&&&32w0xffff0000,32w0x80000000&&&32w0x80000000,32w0xffffffcf&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):first_response_dup();(8w5,_,32w0x90000&&&32w0xffff0000,32w0xffffffd3&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):forward_original();(8w7,_,32w0xc0000&&&32w0xffff0000,32w0xffffffd3&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,16w0x0&&&16w0xffff,_,_,_,_):first_operate_dup();(8w5,_,_,32w0xffffffd3&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):count_resent();(8w7,_,_,32w0xffffffd3&&&32w0xffffffff,32w0x0&&&32w0xffffffff,_,_,_,_,_,_,_,_,_,_,_):count_resent();(8w5,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_refused();(8w6,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_refused();(8w7,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_refused();(8w9,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_refused();(8w11,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_):count_refused();(8w4,_,32w0x1010000&&&32w0xfff10000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1010000&&&32w0xfff10000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1010000&&&32w0xfff10000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1010000&&&32w0xfff10000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1020000&&&32w0xfff30000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1020000&&&32w0xfff30000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1020000&&&32w0xfff30000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1020000&&&32w0xfff30000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1040000&&&32w0xfff70000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1040000&&&32w0xfff70000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1040000&&&32w0xfff70000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1040000&&&32w0xfff70000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x1&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x4&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);(8w4,_,32w0x1080000&&&32w0xffff0000,32w0x0&&&32w0xfffffffe,32w0x0&&&32w0xfffffffe,2w0x2&&&2w0x3,8w0x14&&&8w0xff,_,_,_,_,_,_,_,_,_):first_close_qualified(16w0x200);}}
 action next_stage(){hdr.event.phase=hdr.event.phase+8w1;m.emit_loop=(bit<1>)(8w1);tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
 
 action carry_current(){next_stage();hdr.expected_cell.expected_cell=m.desired;}
 
 action abort_work(){next_stage();hdr.event.code=8w255;hdr.t0.setInvalid();}
 
 
Register<n_object_pair_t,bit<1>>(1,{0,0}) pair_real_links_native_start;
RegisterAction<n_object_pair_t,bit<1>,bit<32>>(pair_real_links_native_start) write_real_links={void apply(inout n_object_pair_t v,out bit<32> r){v.first=m.compare_real_links;v.second=m.compare_native_start;r=32w0;}};
RegisterAction<n_object_pair_t,bit<1>,bit<8>>(pair_real_links_native_start) read_real_links={void apply(inout n_object_pair_t v,out bit<8> r){if(v.first!=m.compare_real_links||v.second!=m.compare_native_start){r=8w1;}else{r=8w0;}}};
action store_real_links(){write_real_links.execute(1w0);}
RegisterAction<n_object_pair_t,bit<1>,bit<32>>(pair_real_links_native_start) write_native_start={void apply(inout n_object_pair_t v,out bit<32> r){v.second=m.compare_native_start;r=32w0;}};
action store_native_start(){write_native_start.execute(1w0);}
action compare_real_links(){m.diff_real_links=read_real_links.execute(1w0);}
table real_links_t{key={m.stage:ternary;m.kind:ternary;m.work_phase:ternary;m.epoch_diff:ternary;}actions={store_native_start;store_real_links;compare_real_links;NoAction;}size=4;const entries={(2w1,8w7,32w1,32w0):store_native_start();(2w1,8w5,32w1,32w0):store_real_links();(2w0,8w7,32w4,_):compare_real_links();(2w0,8w6,32w4,_):compare_real_links();}const default_action=NoAction();}
Register<n_object_pair_t,bit<1>>(1,{0,0}) pair_real_tcp_dst_real_tcp_ports;
RegisterAction<n_object_pair_t,bit<1>,bit<32>>(pair_real_tcp_dst_real_tcp_ports) write_real_tcp_dst={void apply(inout n_object_pair_t v,out bit<32> r){v.first=m.compare_real_tcp_dst;v.second=m.compare_real_tcp_ports;r=32w0;}};
RegisterAction<n_object_pair_t,bit<1>,bit<8>>(pair_real_tcp_dst_real_tcp_ports) read_real_tcp_dst={void apply(inout n_object_pair_t v,out bit<8> r){if(v.first!=m.compare_real_tcp_dst||v.second!=m.compare_real_tcp_ports){r=8w1;}else{r=8w0;}}};
action store_real_tcp_dst(){write_real_tcp_dst.execute(1w0);}
action compare_real_tcp_dst(){m.diff_real_tcp_dst=read_real_tcp_dst.execute(1w0);}
table real_tcp_dst_t{key={m.stage:ternary;m.kind:ternary;m.work_phase:ternary;m.epoch_diff:ternary;}actions={store_real_tcp_dst;compare_real_tcp_dst;NoAction;}size=3;const entries={(2w1,8w5,32w1,32w0):store_real_tcp_dst();(2w0,8w7,32w4,_):compare_real_tcp_dst();(2w0,8w6,32w4,_):compare_real_tcp_dst();}const default_action=NoAction();}

Register<n_object_pair_t,bit<1>>(1,{0,0}) pair_native_end_server_start;
RegisterAction<n_object_pair_t,bit<1>,bit<32>>(pair_native_end_server_start) write_native_end={void apply(inout n_object_pair_t v,out bit<32> r){v.first=m.compare_native_end;v.second=m.compare_server_start;r=32w0;}};
RegisterAction<n_object_pair_t,bit<1>,bit<8>>(pair_native_end_server_start) read_native_end={void apply(inout n_object_pair_t v,out bit<8> r){if(v.first!=m.compare_native_end||v.second!=m.compare_server_start){r=8w1;}else{r=8w0;}}};
action store_native_end(){write_native_end.execute(1w0);}
action compare_native_end(){m.diff_native_end=read_native_end.execute(1w0);}
table native_end_t{key={m.stage:ternary;m.kind:ternary;m.work_phase:ternary;m.epoch_diff:ternary;}actions={store_native_end;compare_native_end;NoAction;}size=4;const entries={(2w1,8w5,32w1,32w0):store_native_end();(2w1,8w7,32w1,32w0):store_native_end();(2w0,8w7,32w4,_):compare_native_end();(2w0,8w6,32w4,_):compare_native_end();}const default_action=NoAction();}
action compare_response_inputs(){m.compare_real_links=(bit<32>)(hdr.dl.src++hdr.dl.dst);m.compare_real_tcp_dst=(bit<32>)(hdr.ip.src);m.compare_real_tcp_ports=(bit<32>)(hdr.tcp.dport++hdr.tcp.sport);m.compare_native_start=(bit<32>)(hdr.tcp.ack-32w45);m.compare_native_end=(bit<32>)(hdr.tcp.ack);m.compare_server_start=(bit<32>)(hdr.tcp.seq);m.compare_application=(bit<32>)(hdr.first.w0[23:16]);}
table compare_response_inputs_t{actions={compare_response_inputs;}size=1;const default_action=compare_response_inputs();}
action compare_operate_inputs(){m.compare_real_links=(bit<32>)(hdr.dl.dst++hdr.dl.src);m.compare_real_tcp_dst=(bit<32>)(hdr.ip.dst);m.compare_real_tcp_ports=(bit<32>)(hdr.tcp.sport++hdr.tcp.dport);m.compare_native_start=(bit<32>)(hdr.tcp.seq-32w45);m.compare_native_end=(bit<32>)(hdr.tcp.seq);m.compare_server_start=(bit<32>)(hdr.tcp.ack-32w49);m.compare_application=(bit<32>)(hdr.first.w0[15:8]++hdr.first.w0[23:16]);}
action compare_operate_store_inputs(){m.compare_real_links=(bit<32>)(hdr.dl.dst++hdr.dl.src);m.compare_real_tcp_dst=(bit<32>)(hdr.ip.dst);m.compare_real_tcp_ports=(bit<32>)(hdr.tcp.sport++hdr.tcp.dport);m.compare_native_start=(bit<32>)(hdr.tcp.seq);m.compare_native_end=(bit<32>)(hdr.tcp.seq+32w45);m.compare_server_start=(bit<32>)(hdr.tcp.ack);m.compare_application=(bit<32>)(hdr.first.w0[15:8]++hdr.first.w0[23:16]);}
table compare_operate_inputs_t{key={m.stage:exact;}actions={compare_operate_inputs;compare_operate_store_inputs;}size=2;const entries={2w1:compare_operate_store_inputs();}const default_action=compare_operate_inputs();}
action compare_select_inputs(){m.compare_real_links=(bit<32>)(hdr.dl.dst++hdr.dl.src);m.compare_real_tcp_dst=(bit<32>)(hdr.ip.dst);m.compare_real_tcp_ports=(bit<32>)(hdr.tcp.sport++hdr.tcp.dport);m.compare_native_start=(bit<32>)(hdr.tcp.seq);m.compare_native_end=hdr.tcp.seq+32w45;m.compare_server_start=(bit<32>)(hdr.tcp.ack);m.compare_application=(bit<32>)(hdr.first.w0[15:8]++hdr.first.w0[23:16]);}
table compare_select_inputs_t{actions={compare_select_inputs;}size=1;const default_action=compare_select_inputs();}


action read_configure(bit<16> dst,bit<16> src){m.enabled=(bit<1>)(8w1);m.link_dst=dst;m.link_src=src;}
table read_connection{key={hdr.ip.src:exact;hdr.ip.dst:exact;hdr.tcp.sport:exact;hdr.tcp.dport:exact;}actions={read_configure;NoAction;}size=2;default_action=NoAction();}
table read_request_profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.rd_req.tp:ternary;hdr.rd_req.app:ternary;hdr.rd_req.func:exact;hdr.rd_req.group:exact;hdr.rd_req.variation:exact;hdr.rd_req.qualifier:exact;hdr.rd_req.first:exact;hdr.rd_req.last:exact;}
 actions={eligible;NoAction;}size=1;const default_action=NoAction();const entries={}}
table read_request_full_profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.rd_req_full.tp[7:6]:exact;hdr.rd_req_full.app[7:4]:exact;hdr.rd_req_full.func:exact;hdr.rd_req_full.o1:exact;hdr.rd_req_full.o2:exact;hdr.rd_req_full.o3:exact;hdr.rd_req_full.o4:exact;}
 actions={eligible;NoAction;}size=1;const default_action=NoAction();const entries={(16w0x0564,8w0x14,8w0xc4,2w3,4w0xc,8w1,24w0x3c0206,24w0x3c0306,24w0x3c0406,24w0x3c0106):eligible();}}
table read_request_mx_profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.rd_req_mx.tp[7:6]:exact;hdr.rd_req_mx.app[7:4]:exact;hdr.rd_req_mx.func:exact;hdr.rd_req_mx.o1:exact;hdr.rd_req_mx.o2:exact;}
 actions={eligible;NoAction;}size=1;const default_action=NoAction();const entries={(16w0x0564,8w0x12,8w0xc4,2w3,4w0xc,8w1,40w0x010200000f,40w0x1e01000007):eligible();}}
table read_response_profile{key={hdr.dl.magic:exact;hdr.dl.len:exact;hdr.dl.ctrl:exact;hdr.first.w0[31:24]:ternary;hdr.first.w0[23:16]:ternary;hdr.first.w0[15:8]:exact;hdr.first.w1[23:16]:exact;hdr.first.w1[15:8]:exact;hdr.first.w1[7:0]:exact;hdr.first.w2[31:24]:exact;hdr.first.w2[23:16]:exact;}
 actions={eligible;NoAction;}size=3;const default_action=NoAction();const entries={(16w0x0564,8w0x4c,8w0x44,8w0xc0&&&8w0xc0,8w0xc0&&&8w0xf0,8w0x81,8w1,8w2,8w0,8w0,8w0x0f):eligible();(16w0x0564,8w0x73,8w0x44,8w0xc0&&&8w0xc0,8w0xc0&&&8w0xf0,8w0x81,8w1,8w2,8w0,8w0,8w0x0f):eligible();}}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_rd_second;
action rd_second_crc(){m.crc1=hash_rd_second.get({hdr.second.w0,hdr.second.w1,hdr.second.w2,hdr.second.w3,hdr.second.crc});}
@stage(2) table rd_second_crc_t{actions={rd_second_crc;}size=1;const default_action=rd_second_crc();}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_rd_request;
action rd_request_crc(){m.bcrc=hash_rd_request.get({hdr.rd_req.tp,hdr.rd_req.app,hdr.rd_req.func,hdr.rd_req.group,hdr.rd_req.variation,hdr.rd_req.qualifier,hdr.rd_req.first,hdr.rd_req.last,hdr.rd_req.crc});}
@stage(2) table rd_request_crc_t{actions={rd_request_crc;}size=1;const default_action=rd_request_crc();}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_rd_request_full;
action rd_request_full_crc(){m.bcrc=hash_rd_request_full.get({hdr.rd_req_full.tp,hdr.rd_req_full.app,hdr.rd_req_full.func,hdr.rd_req_full.o1,hdr.rd_req_full.o2,hdr.rd_req_full.o3,hdr.rd_req_full.o4,hdr.rd_req_full.crc});}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_rd_request_mx;
action rd_request_mx_crc(){m.bcrc=hash_rd_request_mx.get({hdr.rd_req_mx.tp,hdr.rd_req_mx.app,hdr.rd_req_mx.func,hdr.rd_req_mx.o1,hdr.rd_req_mx.o2,hdr.rd_req_mx.crc});}
@stage(2) table rd_request_two_crc_t{key={hdr.rd_req_full.isValid():exact;}actions={rd_request_full_crc;rd_request_mx_crc;NoAction;}size=2;const entries={true:rd_request_full_crc();false:rd_request_mx_crc();}const default_action=NoAction();}
Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_rd_tail;
action rd_tail_crc(){m.tcrc=hash_rd_tail.get({hdr.rd_tail.value,hdr.rd_tail.crc});}
action read_shallow_admit(){m.crc1=m.bcrc;m.tcrc=m.bcrc;}
table read_shallow_admit_t{actions={read_shallow_admit;}size=1;const default_action=read_shallow_admit();}
@stage(2) table rd_tail_crc_t{actions={rd_tail_crc;}size=1;const default_action=rd_tail_crc();}
action read_request_input(){m.compare_read_app=(bit<32>)(hdr.rd_req.app[3:0]);}
action read_response_input(bit<32> shape){m.compare_read_app=shape | (bit<32>)(hdr.first.w0[19:16]);}
action read_request_full_input(){m.compare_read_app=32w0x100 | (bit<32>)(hdr.rd_req_full.app[3:0]);}
action read_request_mx_input(){m.compare_read_app=32w0x200 | (bit<32>)(hdr.rd_req_mx.app[3:0]);}
table read_input_t{key={m.packet_kind:exact;hdr.rd_req_full.isValid():exact;hdr.rd_req_mx.isValid():exact;hdr.dl.len:ternary;}actions={read_request_input;read_request_full_input;read_request_mx_input;read_response_input;NoAction;}size=5;const entries={(8w9,false,false,_):read_request_input();(8w9,true,false,_):read_request_full_input();(8w9,false,true,_):read_request_mx_input();(8w11,false,false,8w0x4c):read_response_input(32w0x200);(8w11,false,false,8w0x73):read_response_input(32w0x100);}const default_action=NoAction();}
Register<n_application_state_t,bit<1>>(1,{0,0}) application_state;
RegisterAction<n_application_state_t,bit<1>,bit<16>>(application_state) write_control_state={void apply(inout n_application_state_t v){v.crob=m.compare_application[15:0];v.read_identity=16w0xffff;}};
RegisterAction<n_application_state_t,bit<1>,bit<16>>(application_state) write_read_state={void apply(inout n_application_state_t v){v.read_identity=m.compare_read_app[15:0];}};
RegisterAction<n_application_state_t,bit<1>,bit<16>>(application_state) check_control_state={void apply(inout n_application_state_t v,out bit<16> r){r=v.crob;}};
RegisterAction<n_application_state_t,bit<1>,bit<8>>(application_state) check_read_state={void apply(inout n_application_state_t v,out bit<8> r){r=8w0;if(v.read_identity==m.compare_read_app[15:0]){r=8w1;}}};
action store_control_state(){write_control_state.execute(1w0);}
action store_read_state(){write_read_state.execute(1w0);}
action compare_control_state(){m.diff_application=check_control_state.execute(1w0);}
action compare_read_state(){m.matched=(bit<1>)(check_read_state.execute(1w0));}
action control_state_delta(){m.diff_application=m.diff_application-m.compare_application[15:0];}
table control_state_delta_t{actions={control_state_delta;}size=1;const default_action=control_state_delta();}
table application_state_t{key={m.stage:ternary;m.kind:ternary;m.work_phase:ternary;m.epoch_diff:ternary;}actions={store_control_state;store_read_state;compare_control_state;compare_read_state;NoAction;}size=8;const entries={
(2w1,8w5,32w1,32w0):store_control_state();
(2w1,8w7,32w1,32w0):store_control_state();
(2w0,8w5,32w4,_):compare_control_state();
(2w0,8w7,32w4,_):compare_control_state();
(2w0,8w6,32w4,_):compare_control_state();
(2w1,8w9,32w1,32w0):store_read_state();
(2w0,8w9,32w4,_):compare_read_state();
(2w0,8w11,32w4,_):compare_read_state();
}const default_action=NoAction();}

action emit_tev(bit<16> event){hdr.expected_cell.expected_cell=hdr.t0.t0q;hdr.event.phase=event[15:8];hdr.event.code=event[7:0];hdr.work_generation.generation=hdr.origin.wire_ack;hdr.origin.setInvalid();hdr.t0.setInvalid();tm.ucast_egress_port=n_READ_HANDOFF_PORT;m.emit_loop=(bit<1>)(8w0);}
action commit_before_t(bit<8> kind){hdr.expected_cell.expected_cell=hdr.t0.t0q;hdr.event.phase=8w0xe5;hdr.event.code=kind;hdr.work_generation.generation=hdr.origin.wire_ack;hdr.origin.setInvalid();hdr.t0.setInvalid();tm.ucast_egress_port=n_N_ACK_RETURN;m.emit_loop=(bit<1>)(8w0);}
action terminal_strip(){tm.ucast_egress_port=m.output_port;hdr.work_generation.generation=hdr.origin.wire_ack;hdr.expected_cell.expected_cell=32w0;hdr.event.phase=8w227;hdr.event.code=8w0;hdr.origin.setInvalid();}
action terminal_ack(){terminal_strip();hdr.event.phase=8w228;hdr.event.code=8w0;}
action terminal_synack(){terminal_strip();hdr.event.phase=8w231;hdr.event.code=8w0;}
action terminal_open(){hdr.work_generation.generation=32w0;hdr.expected_cell.expected_cell=32w0;hdr.event.phase=8w14;hdr.event.code=8w0;hdr.origin.setInvalid();tm.ucast_egress_port=n_READ_HANDOFF_PORT;m.emit_loop=(bit<1>)(8w0);}
action terminal_abort(){hdr.envelope.setInvalid();hdr.work_generation.setInvalid();hdr.expected_cell.setInvalid();hdr.event.setInvalid();md.drop_ctl=3w1;}
action emit_reset(){hdr.work_generation.generation=hdr.origin.wire_ack;hdr.origin.setInvalid();hdr.event.phase=8w13;hdr.event.code=(bit<8>)m.direction;hdr.expected_cell.expected_cell=32w0;tm.ucast_egress_port=n_READ_HANDOFF_PORT;m.emit_loop=(bit<1>)(8w0);}
action reset_continue(){hdr.expected_cell.expected_cell=m.desired;hdr.event.phase=hdr.event.phase+8w1;hdr.event.reserved=16w0;m.emit_loop=(bit<1>)(8w1);tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action reset_wait(){hdr.event.reserved=hdr.event.reserved+16w1;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action reset_restart_master(){hdr.work_generation.generation=32w1;hdr.event.phase=8w8;hdr.event.code=8w0;hdr.event.reserved=hdr.event.reserved+16w1;hdr.origin.normalized_epoch=hdr.envelope.epoch;hdr.expected_cell.expected_cell=n_RETRY_BUDGET;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action reset_restart_out(){hdr.work_generation.generation=32w1;hdr.event.phase=8w8;hdr.event.code=8w0;hdr.event.reserved=hdr.event.reserved+16w1;hdr.origin.normalized_epoch=32w0;hdr.expected_cell.expected_cell=n_RETRY_BUDGET;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
table reset_boundary{key={m.stage:exact;m.owner_op:ternary;m.owner_diff:ternary;m.epoch_diff:exact;hdr.event.reserved:ternary;m.direction:ternary;hdr.tcp.flags:ternary;}actions={reset_continue;emit_reset;reset_wait;reset_restart_master;reset_restart_out;terminal_abort;}size=10;const entries={(2w1,1w1,32w0,32w0,_,_,_):reset_continue();(2w2,1w0,32w0,32w0,_,_,_):emit_reset();(2w1,1w0,32w0,32w0,16w32,_,_):terminal_abort();(2w1,1w0,32w0,32w0,_,_,_):reset_wait();(2w1,_,32w0&&&32w0xffff,32w0,16w32,_,8w17&&&8w0xf7):terminal_abort();(2w1,_,32w0&&&32w0xffff,32w0,_,2w1,8w17&&&8w0xf7):reset_restart_master();(2w1,_,32w0&&&32w0xffff,32w0,_,2w2,8w17&&&8w0xf7):reset_restart_out();(2w1,_,32w0&&&32w0xffff,32w0,16w32,_,8w0x04&&&8w0x04):terminal_abort();(2w1,_,32w0&&&32w0xffff,32w0,_,2w1,8w0x04&&&8w0x04):reset_restart_master();(2w1,_,32w0&&&32w0xffff,32w0,_,2w2,8w0x04&&&8w0x04):reset_restart_out();}const default_action=terminal_abort();}
@stage(9) table continuation_t{key={m.work_phase:ternary;m.epoch_diff:ternary;m.kind:ternary;m.stage:ternary;m.owner_op:ternary;m.owner_diff:ternary;m.direction:ternary;m.packet_kind:ternary;}actions={next_stage;carry_current;abort_work;emit_tev;terminal_open;terminal_synack;commit_before_t;terminal_abort;terminal_ack;terminal_strip;deny;}size=33;const entries={(32w1,32w0,8w8,_,_,32w0,_,_):next_stage();(32w1,32w0,8w25,_,_,32w0,_,_):next_stage();(32w1,32w0,8w24,_,_,32w0,_,_):next_stage();(32w1,32w0,8w10,_,_,32w0,_,_):next_stage();(32w1,32w0,8w12,_,_,32w0,_,_):next_stage();(32w1,32w0,8w17,2w2,_,32w0,_,_):next_stage();(32w1,32w0,_,_,1w1,32w0,_,_):carry_current();(32w1,_,_,_,_,_,_,_):abort_work();(32w2,32w0,8w8,_,_,32w0,_,_):next_stage();(32w2,32w0,8w25,_,_,32w0,_,_):next_stage();(32w2,32w0,8w24,_,_,32w0,_,_):next_stage();(32w2,32w0,8w10,_,_,32w0,_,_):next_stage();(32w2,32w0,8w12,_,_,32w0,_,_):next_stage();(32w2,32w0,8w17,2w2,_,32w0,_,_):next_stage();(32w2,32w0,_,_,1w1,32w0,_,_):carry_current();(32w2,_,_,_,_,_,_,_):abort_work();(32w3,32w0,8w24,_,_,32w0,2w1,8w5):emit_tev(16w0x1000);(32w3,32w0,8w24,_,_,32w0,2w1,8w9):emit_tev(16w0x1000);(32w3,32w0,8w1,_,_,32w0,_,_):terminal_open();(32w3,32w0,8w2,_,_,32w0,_,_):terminal_synack();(32w3,32w0,8w7,_,_,32w0,_,_):commit_before_t(8w12);(32w3,32w0,8w24,_,_,32w0,_,_):commit_before_t(8w15);(32w3,32w0,8w9,_,_,32w0,_,_):commit_before_t(8w9);(32w3,32w0,8w10,_,_,32w0,_,_):emit_tev(16w0x0a00);(32w3,32w0,8w11,_,_,32w0,_,_):emit_tev(16w0x0b00);(32w3,32w0,8w5,_,_,32w0,_,_):commit_before_t(8w9);(32w3,32w0,8w6,_,_,32w0,_,_):emit_tev(16w0x0b00);(32w3,32w0,8w16,_,_,32w0,_,_):emit_tev(16w0x0b00);(32w3,32w0,8w25,_,_,32w0,_,_):emit_tev(16w0x0b00);(32w3,32w0,8w255,_,_,32w0,_,_):terminal_abort();(32w3,32w0,_,_,_,32w0,2w1,_):terminal_ack();(32w3,32w0,_,_,_,32w0,_,_):terminal_strip();(32w3,_,_,_,_,_,_,_):terminal_abort();}const default_action=deny();}
action busy_drop(){md.drop_ctl=3w1;}
action busy_pass(){}
action busy_retry(){hdr.envelope.epoch=m.epoch;hdr.work_generation.generation=m.generation;hdr.event.phase=8w4;hdr.event.code=8w0;hdr.event.reserved=16w0;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;hdr.expected_cell.expected_cell=n_RETRY_BUDGET;}
action busy_retry_next(){hdr.expected_cell.expected_cell=hdr.expected_cell.expected_cell-32w1;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action busy_retry_rst(){hdr.envelope.epoch=m.epoch;hdr.work_generation.generation=32w1;hdr.event.phase=8w8;hdr.event.code=8w0;hdr.event.reserved=16w0;hdr.origin.setValid();hdr.origin.wire_ack=m.wire_ack;hdr.origin.normalized_epoch=m.normalized_epoch;hdr.expected_cell.expected_cell=n_RETRY_BUDGET;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action busy_retry_rst_next(){hdr.expected_cell.expected_cell=hdr.expected_cell.expected_cell-32w1;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action busy_retry_ack(){hdr.envelope.epoch=m.epoch;hdr.work_generation.generation=m.generation;hdr.event.phase=8w8;hdr.event.code=8w0;hdr.event.reserved=16w0;hdr.origin.setValid();hdr.origin.wire_ack=m.wire_ack;hdr.origin.normalized_epoch=m.normalized_epoch;hdr.expected_cell.expected_cell=n_RETRY_BUDGET;tm.ucast_egress_port=n_RETURN_PORT;tm.bypass_egress=1w1;}
action busy_exhausted(){md.drop_ctl=3w1;}
action retry_stale(){md.drop_ctl=3w1;}
table busy_t{key={m.kind:ternary;m.retry:ternary;hdr.expected_cell.expected_cell[5:0]:ternary;}actions={busy_drop;busy_pass;busy_retry;busy_retry_next;busy_retry_rst;busy_retry_rst_next;busy_retry_ack;busy_exhausted;retry_stale;}size=28;const entries={(_,2w2,_):retry_stale();(8w3,2w0,_):busy_retry_ack();(8w3,2w1,6w1):busy_exhausted();(8w3,2w1,_):busy_retry_rst_next();(8w10,2w0,_):busy_retry_ack();(8w10,2w1,6w1):busy_exhausted();(8w10,2w1,_):busy_retry_rst_next();(8w6,2w0,_):busy_retry();(8w11,2w0,_):busy_retry();(8w6,2w1,6w1):busy_exhausted();(8w11,2w1,6w1):busy_exhausted();(8w6,2w1,_):busy_retry_next();(8w11,2w1,_):busy_retry_next();(8w4,2w0,_):busy_retry_rst();(8w4,2w1,6w1):busy_exhausted();(8w4,2w1,_):busy_retry_rst_next();(8w1,_,_):busy_drop();(8w2,_,_):busy_drop();(8w5,2w0,_):busy_retry_ack();(8w5,2w1,6w1):busy_exhausted();(8w5,2w1,_):busy_retry_rst_next();(8w7,2w0,_):busy_retry_ack();(8w7,2w1,6w1):busy_exhausted();(8w7,2w1,_):busy_retry_rst_next();(8w9,2w0,_):busy_retry_ack();(8w9,2w1,6w1):busy_exhausted();(8w9,2w1,_):busy_retry_rst_next();(8w12,_,_):busy_drop();}const default_action=busy_pass();} /* c74: READ/SELECT/OPERATE retry through n_RETRY_BUDGET like kind 3; SYN, SYN-ACK, replay drop */
action go_new(bit<8> k){m.go=(bit<1>)(8w1);m.kind=k;m.generation=allocate.execute(1w0);m.work_op=8w1;}
action go_keep(bit<8> k){m.go=(bit<1>)(8w1);m.kind=k;}
action go_ret_work(){m.go=(bit<1>)(8w1);m.generation=hdr.work_generation.generation;m.work_op=8w2;}
action go_ret_nowork(){m.go=(bit<1>)(8w1);m.generation=hdr.work_generation.generation;}
action go_ret_abort(){m.go=(bit<1>)(8w1);m.kind=8w255;m.return_abort=(bit<1>)(8w1);m.generation=hdr.work_generation.generation;m.work_op=8w2;hdr.event.code=8w255;hdr.t0.setInvalid();}
action go_retry(bit<8> k){m.go=(bit<1>)(8w1);m.kind=k;m.generation=hdr.work_generation.generation;m.work_op=8w1;}
action go_stale(){m.go=(bit<1>)(8w1);m.kind=8w0;m.work_op=8w0;m.retry=2w2;}
action refuse_n_ack_return(){md.drop_ctl=3w1;}
table guard{key={m.stage:ternary;m.packet_kind:ternary;m.kind:ternary;m.direction:ternary;m.shape_valid:ternary;m.enabled:ternary;m.profile:ternary;m.badh:ternary;m.hcrc:ternary;m.bcrc:ternary;m.crc1:ternary;m.tcrc:ternary;m.output_port:ternary;m.retry:ternary;}
actions={go_new;go_keep;go_ret_work;go_ret_nowork;go_ret_abort;go_retry;go_stale;refuse_n_ack_return;NoAction;}size=57;const default_action=NoAction();const entries={(_,8w5,8w24,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w9,8w24,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,_,_,_):go_ret_work();(2w0,8w6,8w0,2w2,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,2w1):go_retry(8w6);(2w0,8w11,8w0,2w2,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,2w1):go_retry(8w11);(2w0,8w9,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,_,_,2w1):go_retry(8w9);(2w0,8w5,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,2w1):go_retry(8w5);(2w0,8w7,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,2w1):go_retry(8w7);(2w0,8w4,8w0,2w1,1w1,_,_,_,_,_,_,_,_,2w1):go_keep(8w4);(2w0,8w4,8w0,2w2,1w1,_,_,_,_,_,_,_,_,2w1):go_keep(8w4);(2w0,8w3,8w0,2w1,1w1,_,_,_,_,_,_,_,_,2w1):go_retry(8w3);(2w0,8w3,8w0,2w2,1w1,_,_,_,_,_,_,_,_,2w1):go_retry(8w10);(_,_,_,_,_,_,_,_,_,_,_,_,_,2w1):go_stale();(_,_,_,_,_,_,_,_,_,_,_,_,_,2w2):go_stale();(_,_,_,_,_,_,_,_,_,_,_,_,n_N_ACK_RETURN,_):refuse_n_ack_return();(_,8w5,8w8,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w6,8w8,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w6,8w25,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w7,8w8,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w7,8w24,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w9,8w8,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,_,_,_):go_ret_work();(_,8w11,8w8,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w11,8w25,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(2w1,_,_,2w0,_,_,_,_,_,_,_,_,_,_):go_ret_abort();(2w2,_,_,2w0,_,_,_,_,_,_,_,_,_,_):go_ret_abort();(2w3,_,_,2w0,_,_,_,_,_,_,_,_,_,_):go_ret_abort();(2w0,8w1,8w0,2w1,1w1,_,_,_,_,_,_,_,_,_):go_new(8w1);(2w0,8w2,8w0,2w2,1w1,_,_,_,_,_,_,_,_,_):go_new(8w2);(2w0,8w3,8w0,2w1,1w1,_,_,_,_,_,_,_,_,_):go_new(8w3);(2w0,8w4,8w0,2w1,1w1,_,_,_,_,_,_,_,_,_):go_keep(8w4);(2w0,8w4,8w0,2w2,1w1,_,_,_,_,_,_,_,_,_):go_keep(8w4);(2w0,8w5,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_new(8w5);(2w0,8w6,8w0,2w2,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_new(8w6);(2w0,8w7,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_new(8w7);(2w0,8w9,8w0,2w1,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,_,_,_,_):go_new(8w9);(2w0,8w11,8w0,2w2,1w1,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_new(8w11);(2w0,8w3,8w0,2w2,1w1,_,_,_,_,_,_,_,_,_):go_new(8w10);(2w0,8w12,8w0,2w1,1w1,_,_,_,_,_,_,_,_,_):go_new(8w12);(_,8w1,8w1,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w2,8w2,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w3,8w3,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w4,8w4,_,_,_,_,_,_,_,_,_,_,_):go_ret_nowork();(_,8w5,8w5,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w6,8w6,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w7,8w7,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,16w0x993a,_,_):go_ret_work();(_,8w1,8w8,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w2,8w8,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w3,8w8,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w3,8w17,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w9,8w9,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,_,_,_,_):go_ret_work();(_,8w3,8w10,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,8w11,8w11,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w6,8w16,_,_,1w1,8w1,1w0,16w0x993a,16w0x993a,16w0x993a,16w0x993a,_,_):go_ret_work();(_,8w12,8w12,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(_,_,8w255,_,_,_,_,_,_,_,_,_,_,_):go_ret_work();(2w1,_,_,_,_,_,_,_,_,_,_,_,_,_):go_ret_abort();(2w2,_,_,_,_,_,_,_,_,_,_,_,_,_):go_ret_abort();(2w3,_,_,_,_,_,_,_,_,_,_,_,_,_):go_ret_abort();}}
 apply{
  /* DIAG MIRROR: always select mirror entry 1, never bf-p4c's type-0 entry (see t_NO_MIRROR_SESSION); session 0 = no copy. */
  md.mirror_type=n_DIAG_MIRROR_TYPE;m.diag_ses=n_DIAG_NO_SESSION;
  if(ig.ingress_port==n_DIAG_RELAY_PORT){m.diag_ses=n_DIAG_SESSION_RX;}
  m.return_abort=(bit<1>)(8w0);m.work_op=8w0;m.owner_op=(bit<1>)(8w0);m.generation=32w0;m.expected=hdr.expected_cell.expected_cell;m.desired=32w0;m.go=(bit<1>)(8w0);m.owner_diff=32w1;m.expected_work_phase=(bit<32>)(bit<8>)m.stage;
  connection.apply();retry_epoch_t.apply();crc_t.apply();
   if(m.packet_kind==8w5||m.packet_kind==8w6||m.packet_kind==8w7){
    data_connection.apply();if((bit<8>)m.response==8w1){response_profile.apply();}else{profile.apply();}
    if((bit<8>)m.response==8w1){response_crct_t.apply();response_status_crc_t.apply();}else{input_tail_t.apply();}
   }else if(m.packet_kind==8w9||m.packet_kind==8w11){
    read_connection.apply();
    if(m.packet_kind==8w9){if(hdr.rd_req_full.isValid()){read_request_full_profile.apply();}else{read_request_mx_profile.apply();}rd_request_two_crc_t.apply();}else{read_response_profile.apply();read_shallow_admit_t.apply();}
    if(hdr.dl.dst!=m.link_dst||hdr.dl.src!=m.link_src){m.badh=(bit<1>)(8w1);}
   }
  ports.apply();network.apply();retry_valid_t.apply();
  if((bit<8>)m.committed==8w1){committed_t.apply();}
  else if(m.packet_kind==8w13){deny();}   /* command-bearing FIN/RST: rejected, never bypasses the mechanism */
  else if((ig.ingress_port==n_RETURN_PORT&&(bit<8>)m.stage==8w0&&m.retry==2w0)||((ig.ingress_port==n_N_ACK_RETURN||ig.ingress_port==n_RETURN_PORT)&&tm.ucast_egress_port==n_N_ACK_RETURN)){deny();}
  else if((bit<8>)m.port_valid==8w1&&(bit<8>)m.network_valid==8w1&&((bit<8>)m.stage==8w0||hdr.event.reserved[15:6]==10w0)){
   guard.apply();
   if((bit<8>)m.go==8w1){
    if(m.packet_kind==8w5||m.packet_kind==8w6||m.packet_kind==8w7){
     if((bit<8>)m.response==8w1){compare_response_inputs_t.apply();}else{if(m.packet_kind==8w5){compare_select_inputs_t.apply();}else{compare_operate_inputs_t.apply();}}
    }
    ack_native_t.apply();read_input_t.apply();
    work.apply(m.work_op,m.generation,m.expected_work_phase,m.work_phase);
    next_seq_t.apply();epoch_t.apply();client_t.apply();server_t.apply();
    sequence_diff.apply();
    owner_command.apply();
    if((bit<8>)m.stage==8w0&&m.work_phase==32w4&&(m.work_op==8w1||(m.kind==8w4&&(bit<8>)m.shape_valid==8w1))){snapshot_t.apply();}
    owner_t.apply();
    if(m.packet_kind==8w5||m.packet_kind==8w6||m.packet_kind==8w7){
     real_links_t.apply();real_tcp_dst_t.apply();native_end_t.apply();
    }
    application_state_t.apply();
    if(m.stage==2w0&&m.work_phase==32w4&&(m.kind==8w5||m.kind==8w6||m.kind==8w7)){control_state_delta_t.apply();}
    if((bit<8>)m.stage==8w0){
     
     if(m.work_phase==32w4&&(m.work_op==8w1||(m.kind==8w4&&(bit<8>)m.shape_valid==8w1))){
      hdr.expected_cell.expected_cell=m.observed;first_event.apply();
      
     }else if(m.work_op==8w1||m.retry==2w2||(m.kind==8w4&&(bit<8>)m.shape_valid==8w1)){busy_t.apply();}else if(m.kind==8w4){deny();}
    }else if(m.kind==8w4){reset_boundary.apply();}
    else {continuation_t.apply();}
   }else if((bit<8>)m.stage!=8w0){deny();}
  }else if((bit<8>)m.stage!=8w0||m.retry!=2w0){deny();}
 }
}
control n_IgDeparser(packet_out pkt,inout n_headers_t hdr,in n_meta_t m,in ingress_intrinsic_metadata_for_deparser_t md){Mirror() n_diag_mirror;apply{if(md.mirror_type==n_DIAG_MIRROR_TYPE){n_diag_mirror.emit(m.diag_ses);}pkt.emit(hdr);}}
parser n_EgParser(packet_in pkt,out n_headers_t hdr,out n_meta_t m,out egress_intrinsic_metadata_t eg){state start{pkt.extract(eg);transition accept;}}
control n_Egress(inout n_headers_t hdr,inout n_meta_t m,in egress_intrinsic_metadata_t eg,in egress_intrinsic_metadata_from_parser_t p,inout egress_intrinsic_metadata_for_deparser_t md,inout egress_intrinsic_metadata_for_output_port_t port){apply{}}
control n_EgDeparser(packet_out pkt,inout n_headers_t hdr,in n_meta_t m,in egress_intrinsic_metadata_for_deparser_t md){apply{}}

/* Generated isolated E protected reconnect candidate. */
/* Canonical E source in p4/response_only.p4.
   scripts/profile.py copies this source. */
/* E combines response eligibility, sequence/ACK mapping and control-image construction.
   Native shape/link-CRC checks and mapping decisions are in r_EgParser/r_Egress.
   Padding follows commit/replay eligibility; len_delta accounts for changed image lengths.
   READ prefix construction is in x_Egress below.

   Incremental TCP checksums combine the parser residual with current header words.
   Explicit 8w0 terms preserve odd-byte alignment; len_delta accounts for TCP length change.
   Padding headers enter checksum branches under their validity conditions, avoiding stale
   PHV contents from absent headers. Keep those guards when changing header allocation.

   The active shape/connection tables and register-access actions are defined here.
 */
//
//
//
//
//
//
//
//
//
//
//
//
//

const bit<8> r_SH_NONE = 0; const bit<8> r_SH_SYNACK_OK = 1; const bit<8> r_SH_SYN = 2; const bit<8> r_SH_ODD = 3;
const bit<8> r_SH_ACK = 4;  const bit<8> r_SH_NOACK = 5;     // 4 and 5 differ only in bit 0

const bit<8> r_OUT_COMMIT = 1;  const bit<8> r_OUT_TRANSLATE = 2; const bit<8> r_OUT_ZERO = 3;
const bit<8> r_OUT_REPLAY = 4;  const bit<8> r_OUT_STALE = 5;     const bit<8> r_OUT_DROP_OVERLAP = 6;
const bit<8> r_OUT_DROP_AHEAD = 7; const bit<8> r_OUT_DROP_ODD = 8;
const bit<8> r_OUT_REV_TRANSLATE = 9; const bit<8> r_OUT_REV_WITHHOLD = 10; const bit<8> r_OUT_REV_DROP_STALE = 11;
const bit<8> r_OUT_NATIVE = 12; const bit<8> r_OUT_ARM_MAP = 13; const bit<8> r_OUT_ARM_NAT = 14;
const bit<8> r_OUT_DROP_MERGED = 15; const bit<8> r_OUT_RESET_FRONT = 16;   // replay with a native suffix: not checksummable in one pass (spec 10)

const bit<32> r_IMAGE_LEN = 61;
/* DIAG MIRROR (diagnostic mirror build only): every frame that leaves on r_DIAG_RELAY_PORT and is not dropped is
   copied as emitted (TNA egress mirror) to session r_DIAG_SESSION_TX. Both diagnostic sessions send their
   copies to r_DIAG_COPY_PORT, which r_EgParser does not parse (default: accept): no header, register or mirror
   there. */
const MirrorType_t r_DIAG_MIRROR_TYPE = 1;
const PortId_t r_DIAG_RELAY_PORT = 9w64;
const PortId_t r_DIAG_COPY_PORT = 9w10;
const MirrorId_t r_DIAG_SESSION_TX = 10w102;
const MirrorId_t r_DIAG_NO_SESSION = 10w0;

typedef bit<4> r_slot_t;
struct r_pair32 { bit<32> lo; bit<32> hi; }

header r_provenance_h { bit<32> epoch; bit<32> wgen; bit<32> aux; bit<8> kind; bit<8> stage; bit<16> reserved; }
header r_eth_h { bit<48> dst; bit<48> src; bit<16> type; }
header r_ip_h { bit<4> version; bit<4> ihl; bit<8> tos; bit<16> len; bit<16> id; bit<3> flags;
              bit<13> frag; bit<8> ttl; bit<8> proto; bit<16> checksum; bit<32> src; bit<32> dst; }
header r_tcp_h { bit<16> sport; bit<16> dport; bit<32> seq; bit<32> ack; bit<4> offset; bit<4> reserved;
               bit<8> flags; bit<16> window; bit<16> checksum; bit<16> urgent; }
header r_mss_h { bit<8> kind; bit<8> len; bit<16> mss; }
/* DNP3 frame layout, verbatim from case4_pad58b_wire.p4 */
header r_dl_h{bit<16> start;bit<8> len;bit<8> ctrl;bit<16> dst;bit<16> src;bit<16> crc;}
/* READ response split at every boundary of the native and re-encoded layouts (read_reencode_01). */
header r_read_h_h{bit<8> tpctrl;bit<8> appctrl;bit<8> func;bit<16> iin;}
header r_read_obj_h{bit<8> g_group;bit<8> g_var;bit<8> g_qual;bit<8> g_start;bit<8> g_stop;}
header r_read_crc_h{bit<16> crc;}
header r_read_d8_h{bit<8> d;}
header r_read_d16_h{bit<16> d;}
header r_read_d24_h{bit<24> d;}
header r_read_d32_h{bit<32> d;}
header r_read_d56_h{bit<56> d;}
header r_read_d72_h{bit<72> d;}
header r_read_hdr40_h{bit<40> v;}
header r_read_hdr_h{bit<56> v;}
header r_ctl_dl_h{bit<16> start;bit<8> len;bit<8> ctrl;bit<16> dst;bit<16> src;bit<16> crc;}
header r_ctl_seg2_h{bit<8> tpctrl;bit<32> off;bit<8> status;bit<8> index2;bit<8> code2;bit<8> count2;bit<32> on2;bit<24> off_hi;bit<16> crc;}
header r_ctl_seg3_h{bit<8> off_lo;bit<8> status;bit<16> crc;}
header r_ctl_b0_h{bit<8> tpctrl;bit<8> appctrl;bit<8> func;bit<16> iin;bit<8> g_group;bit<8> g_var;bit<8> g_qual;bit<8> g_count;bit<8> index;bit<8> crob_code;bit<8> crob_count;bit<32> on_hi;bit<16> crc0;}
header r_ctl_tail_n_h{bit<32> off;bit<8> status;bit<8> index2;bit<8> code2;bit<8> count2;bit<32> on2;bit<32> off2;bit<16> crc1;}
header r_ctl_status_h{bit<8> status;bit<16> crc;}
header r_ctl_tail_p1_h{bit<16> on_lo;bit<32> off;bit<8> status;bit<72> filler_a;bit<16> crc1;}
header r_ctl_tail_p2_h{bit<80> filler_b;bit<16> crc2;}

header r_ts12_h{bit<32> a;bit<32> b;bit<32> c;}
header r_opt4_h{bit<32> v;}
struct r_headers_t { r_provenance_h prov; r_eth_h eth; r_ip_h ip; r_tcp_h tcp; r_mss_h mss; r_ts12_h tso; r_opt4_h oa; r_opt4_h ob; r_dl_h dl; r_read_h_h rh; r_read_obj_h robj; r_read_hdr40_h ra; r_read_d32_h p03; r_read_crc_h ca;
                   r_read_hdr40_h rbh; r_read_d16_h p45; r_read_crc_h c0; r_read_d32_h p69; r_read_d24_h p1012; r_read_crc_h cb;
                   r_read_hdr_h rc; r_read_d72_h p1321; r_read_crc_h c1; r_read_d8_h p22; r_read_crc_h c2; r_ctl_b0_h cb0; r_ctl_tail_n_h ctn; r_ctl_status_h cstatus; r_ctl_dl_h cd2; r_ctl_seg2_h cs2; r_ctl_dl_h cd3; r_ctl_seg3_h cs3; }

struct r_meta_t { bit<32> life_bad; bit<32> open_bound; bit<1> normalize; bit<1> first_synack;
    bit<16> r_residual;
    /* No parser r_copies of header r_fields: on the model both m.x32 = (bit<32>)hdr.ip.len and the same-width
       m.x16 = hdr.ip.len loaded the FIRST IPv4 halfword (0x4500) without any compiler message. Widening goes
       through identity hashes instead. len_delta r_is the r_TCP-length growth (9/21) the padder adds. */
    bit<16> len_delta;
    bit<1> ip_odd; bit<1> tcp_odd; bit<1> has_mss;
    bit<2> dir; r_slot_t idx; bit<1> enable; bit<3> shape; bit<2> mode;
    bit<32> leff; bit<32> s_end; bit<32> ina;
    bit<32> front_ret; bit<1> grant;
    /* forward / reverse share these (see case4_transport_mapper.p4 for the table) */
    bit<32> q; bit<32> p; bit<32> y; bit<32> z; bit<32> pm; bit<32> t; bit<32> qx; bit<32> r;
    bit<8>  result; bit<1> changed; bit<1> pad; bit<1> wide; bit<32> wnd;
    /* padder verdict and CRC scratch (case4_pad58b_wire.p4) */
    bit<16> rtcrc; bit<16> rtcrc_b; bit<16> ctcrc2; bit<16> ctcrc3;
    bit<1> read_shape; bit<1> ctl_shape;
    bit<16> in_dl; bit<16> in_rb0; bit<16> in_rb1; bit<16> in_rt; bit<16> in_cb0; bit<16> in_ct;
    bit<1> badh; bit<1> rbad0; bit<1> rbad1; bit<1> rbadt; bit<1> cbad0; bit<1> cbadt;
    MirrorId_t diag_ses;   /* DIAG MIRROR */
}
/* Same reason as in case4_pad58b_wire.p4: independent single-bit writers must not share a container. */
@pa_solitary("egress","m.read_shape") @pa_solitary("egress","m.ctl_shape")
@pa_solitary("egress","m.badh") @pa_solitary("egress","m.rbad0") @pa_solitary("egress","m.rbad1")
@pa_solitary("egress","m.rbadt") @pa_solitary("egress","m.cbad0") @pa_solitary("egress","m.cbadt")

/* The Tofino-1 deparser checksum adds every listed container whether or not its header r_is valid
   (measured: an absent header r_overlaid with m.ina put the arriving ACK's low half into every r_TCP checksum).
   Fields of the payload headers in the incremental update therefore must not share r_containers. */
@pa_no_overlay("egress", "m.len_delta")
@pa_no_overlay("egress", "hdr.dl.start")
@pa_no_overlay("egress", "hdr.dl.len")
@pa_no_overlay("egress", "hdr.dl.ctrl")
@pa_no_overlay("egress", "hdr.dl.dst")
@pa_no_overlay("egress", "hdr.dl.src")
@pa_no_overlay("egress", "hdr.dl.crc")
@pa_no_overlay("egress", "hdr.rh.tpctrl")
@pa_no_overlay("egress", "hdr.rh.appctrl")
@pa_no_overlay("egress", "hdr.rh.func")
@pa_no_overlay("egress", "hdr.rh.iin")
@pa_no_overlay("egress", "hdr.robj.g_group")
@pa_no_overlay("egress", "hdr.robj.g_var")
@pa_no_overlay("egress", "hdr.robj.g_qual")
@pa_no_overlay("egress", "hdr.robj.g_start")
@pa_no_overlay("egress", "hdr.robj.g_stop")
@pa_no_overlay("egress", "hdr.p03.d")
@pa_no_overlay("egress", "hdr.p45.d")
@pa_no_overlay("egress", "hdr.c0.crc")
@pa_no_overlay("egress", "hdr.p69.d")
@pa_no_overlay("egress", "hdr.p1012.d")
@pa_no_overlay("egress", "hdr.p1321.d")
@pa_no_overlay("egress", "hdr.c1.crc")
@pa_no_overlay("egress", "hdr.p22.d")
@pa_no_overlay("egress", "hdr.c2.crc")
@pa_no_overlay("egress", "hdr.cb0.tpctrl")
@pa_no_overlay("egress", "hdr.cb0.appctrl")
@pa_no_overlay("egress", "hdr.cb0.func")
@pa_no_overlay("egress", "hdr.cb0.iin")
@pa_no_overlay("egress", "hdr.cb0.g_group")
@pa_no_overlay("egress", "hdr.cb0.g_var")
@pa_no_overlay("egress", "hdr.cb0.g_qual")
@pa_no_overlay("egress", "hdr.cb0.g_count")
@pa_no_overlay("egress", "hdr.cb0.index")
@pa_no_overlay("egress", "hdr.cb0.crob_code")
@pa_no_overlay("egress", "hdr.cb0.crob_count")
@pa_no_overlay("egress", "hdr.cb0.on_hi")
@pa_no_overlay("egress", "hdr.cb0.crc0")
@pa_no_overlay("egress", "hdr.ctn.off2")
@pa_no_overlay("egress", "hdr.ctn.off")
@pa_no_overlay("egress", "hdr.ctn.status")
@pa_no_overlay("egress", "hdr.ctn.crc1")

/* ------------------------------------------------------------------ ingress: port forwarding only */
parser r_IgParser(packet_in pkt, out r_headers_t hdr, out r_meta_t m, out ingress_intrinsic_metadata_t ig) {
    state start { pkt.extract(ig); pkt.advance(PORT_METADATA_SIZE); transition accept; }
}
control r_Ingress(inout r_headers_t hdr, inout r_meta_t m, in ingress_intrinsic_metadata_t ig,
                in ingress_intrinsic_metadata_from_parser_t p, inout ingress_intrinsic_metadata_for_deparser_t md,
                inout ingress_intrinsic_metadata_for_tm_t tm) {
    action deny() { md.drop_ctl = 3w1; }
    action route(PortId_t port) { tm.ucast_egress_port = port; }
    table forwarding { key = { ig.ingress_port : exact; } actions = { route; deny; } size = 8; default_action = deny(); }
    apply { forwarding.apply(); }
}
control r_IgDeparser(packet_out pkt, inout r_headers_t hdr, in r_meta_t m, in ingress_intrinsic_metadata_for_deparser_t md) {
    apply { }
}

/* ------------------------------------------------------------------ egress parser */
parser r_EgParser(packet_in pkt, out r_headers_t hdr, out r_meta_t m, out egress_intrinsic_metadata_t eg) {
    Checksum() tcp_old;
    state start {
        pkt.extract(eg);
        m.ip_odd = (bit<1>)(0); m.tcp_odd = (bit<1>)(0); m.has_mss = (bit<1>)(0); m.normalize = 0; m.first_synack = 0; m.dir = (bit<2>)(0); m.mode = (bit<2>)(0); m.grant = (bit<1>)(0);
        m.result = 0; m.changed = 0; m.pad = 0; m.wide = (bit<1>)(0); m.len_delta = 0;
        m.read_shape = 0; m.ctl_shape = 0;
        m.badh = 0; m.rbad0 = 0; m.rbad1 = 0; m.rbadt = 0; m.cbad0 = 0; m.cbadt = 0;
        /* response-only target: mapper headers only on final master departure and N's normalization pass */
        transition select(eg.egress_port) { 9w9: provenance; 9w64: provenance; 9w48: provenance;  default: accept; }
    }
    state provenance { pkt.extract(hdr.prov); transition select(hdr.prov.reserved) { 16w0: eth; default: reject; } }
    state eth { pkt.extract(hdr.eth); transition select(hdr.eth.type) { 16w0x0800: ip; default: accept; } }
    state ip {
        pkt.extract(hdr.ip);
        transition select(hdr.ip.version, hdr.ip.ihl, hdr.ip.proto) { (4w4, 4w5, 8w6): ip_frag; (4w4, _, 8w6): ip_odd; default: accept; }
    }
    state ip_frag { transition select(hdr.ip.frag, hdr.ip.flags) { (13w0, 3w0): tcp; (13w0, 3w2): tcp; default: ip_odd; } }
    state ip_odd { m.ip_odd = (bit<1>)(1); transition accept; }
    state tcp {
        pkt.extract(hdr.tcp);
        /* Every header r_extracted after this deposit r_is r_subtracted too; the deparser adds them back, plus
           len_delta for the pseudo-header r_TCP length when the padder grew the segment. */
        tcp_old.subtract({hdr.tcp.seq, hdr.tcp.ack, hdr.tcp.window, hdr.tcp.checksum});
        tcp_old.subtract_all_and_deposit(m.r_residual);
        transition select(hdr.tcp.offset) { 4w8: dl_len; 4w10: syn_ts; 4w11: synack_ts; default: tcp_odd; }
    }
    state ts12 { pkt.extract(hdr.tso); transition select(hdr.tso.a) { 32w0x0101080a: dl; default: tcp_odd; } }
    state ts12_mid { pkt.extract(hdr.tso); transition select(hdr.tso.a) { 32w0x0101080a: dl_mid; default: tcp_odd; } }
    state ts12_short { pkt.extract(hdr.tso); transition select(hdr.tso.a) { 32w0x0101080a: accept; default: tcp_odd; } }
    state syn_ts { pkt.extract(hdr.mss); pkt.extract(hdr.tso); pkt.extract(hdr.oa); m.has_mss=1w1; transition syn_profile; }
    state syn_profile { transition select(hdr.mss.kind,hdr.mss.len,hdr.mss.mss) { (8w2,8w4,16w1460): syn_word; default: tcp_odd; } }
    state syn_word { transition select(hdr.tso.a) { 32w0x0402080a: syn_echo; default: tcp_odd; } }
    state syn_echo { transition select(hdr.tso.c) { 32w0: syn_ws; default: tcp_odd; } }
    state syn_ws { transition select(hdr.oa.v) { 32w0x01030307: accept; default: tcp_odd; } }
    state synack_ts { pkt.extract(hdr.mss); pkt.extract(hdr.tso); pkt.extract(hdr.oa); pkt.extract(hdr.ob); m.has_mss=1w1; transition synack_profile; }
    state synack_profile { transition select(hdr.mss.kind,hdr.mss.len,hdr.mss.mss) { (8w2,8w4,16w1460): synack_word0; default: tcp_odd; } }
    state synack_word0 { transition select(hdr.tso.a) { 32w0x01030300: synack_word1; default: tcp_odd; } }
    state synack_word1 { transition select(hdr.tso.b) { 32w0x01010402: synack_word2; default: tcp_odd; } }
    state synack_word2 { transition select(hdr.tso.c) { 32w0x0101080a: accept; default: tcp_odd; } }
    state tcp_odd { m.tcp_odd = (bit<1>)(1); transition accept; }
    state mss { pkt.extract(hdr.mss); m.has_mss = (bit<1>)(1); transition accept; }
    /* Parse the leading DNP3 frame whenever the segment r_is long enough for the shorter profile
       (ip.len >= 77): a merged retransmission carries the frame first and native bytes after it, which
       stay unparsed and are re-emitted after the (possibly padded) frame headers. */
    state dl_len { transition select(hdr.ip.len) { 16w77 &&& 16w0xffff: ctl_len; 16w78 &&& 16w0xfffe: ctl_len; 16w80 &&& 16w0xfff0: ctl_len; 16w96 &&& 16w0xffe0: ctl_len; 16w128 &&& 16w0xff80: ctl_len; 16w256 &&& 16w0xff00: ctl_len; 16w512 &&& 16w0xfe00: ctl_len; 16w1024 &&& 16w0xfc00: ctl_len; 16w2048 &&& 16w0xf800: ctl_len; 16w4096 &&& 16w0xf000: ctl_len; 16w8192 &&& 16w0xe000: ctl_len; 16w16384 &&& 16w0xc000: ctl_len; 16w32768 &&& 16w0x8000: ctl_len; default: ts12_short; } }
    state ctl_len { transition select(hdr.ip.len) { 16w77 &&& 16w0xffff:ts12_mid;16w78 &&& 16w0xfffe:ts12_mid;16w80 &&& 16w0xfff8:ts12_mid;16w88 &&& 16w0xffff:ts12_mid;default:ts12; } }
    state dl { pkt.extract(hdr.dl); transition select(hdr.dl.len) { 8w0x27:read_pp;8w0x11:read_pp;8w0x26:ctl_b0;default:accept; } }
    state dl_mid { pkt.extract(hdr.dl); transition select(hdr.dl.len) { 8w0x27:read_pp;8w0x11:read_pp;8w0x26:accept;default:accept; } }
    state read_b0 { pkt.extract(hdr.rh); pkt.extract(hdr.robj); pkt.extract(hdr.p03); pkt.extract(hdr.p45); pkt.extract(hdr.c0);
        pkt.extract(hdr.p69); pkt.extract(hdr.p1012); pkt.extract(hdr.p1321); pkt.extract(hdr.c1); pkt.extract(hdr.p22); pkt.extract(hdr.c2); transition accept; }
    state ctl_b0 { pkt.extract(hdr.cb0); pkt.extract(hdr.ctn); pkt.extract(hdr.cstatus); transition accept; }
    state read_pp { pkt.extract(hdr.rh); pkt.extract(hdr.robj); transition accept; }
}

/* ------------------------------------------------------------------ egress */
/* attached to the instantiated egress control: pragmas on r_IgParser (never instantiated) are silently dropped */
@pa_solitary("egress","m.ctcrc2") @pa_solitary("egress","m.ctcrc3")
@pa_solitary("egress","m.badh") @pa_solitary("egress","m.cbad0") @pa_solitary("egress","m.cbadt")
@pa_solitary("egress","m.read_shape") @pa_solitary("egress","m.ctl_shape")
@pa_no_overlay("egress","hdr.ctn.index2")
@pa_no_overlay("egress","hdr.ctn.code2")
@pa_no_overlay("egress","hdr.ctn.count2")
@pa_no_overlay("egress","hdr.ctn.on2")
@pa_no_overlay("egress","hdr.cstatus.status")
@pa_no_overlay("egress","hdr.cstatus.crc")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_original_csum","hdr.tcp.checksum.$deparse_original_csum")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_original_csum","hdr.tcp.checksum.$deparse_updated_csum_0")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_original_csum","hdr.tcp.checksum.$deparse_updated_csum_1")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_updated_csum_0","hdr.tcp.checksum.$deparse_original_csum")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_updated_csum_0","hdr.tcp.checksum.$deparse_updated_csum_0")
@pa_no_pack("egress","hdr.ip.checksum.$deparse_updated_csum_0","hdr.tcp.checksum.$deparse_updated_csum_1")
@pa_no_overlay("egress", "eg_intr_md_for_dprsr.mirror_type")   /* DIAG MIRROR: unwritten value must stay 0 */
@pa_no_overlay("egress", "m.diag_ses")
control r_Egress(inout r_headers_t hdr, inout r_meta_t m, in egress_intrinsic_metadata_t eg,
               in egress_intrinsic_metadata_from_parser_t prs, inout egress_intrinsic_metadata_for_deparser_t md,
               inout egress_intrinsic_metadata_for_output_port_t port) {

    /* ============ stage-0 lookups ============ */
    action fwd_conn(r_slot_t idx, bit<8> enable) { m.dir = (bit<2>)(1); m.idx = idx; m.enable = (bit<1>)(enable); }
    action rev_conn(r_slot_t idx) { m.dir = (bit<2>)(2); m.idx = idx; m.enable = (bit<1>)(0); }
    table conn {
        key = { hdr.ip.src : exact; hdr.ip.dst : exact; hdr.tcp.sport : exact; hdr.tcp.dport : exact; eg.egress_port : exact; }
        actions = { fwd_conn; rev_conn; NoAction; } size = 32; default_action = NoAction();
    }
    action odd_conn(r_slot_t idx) { m.dir = (bit<2>)(3); m.idx = idx; }
    table odd_ip_t {
        key = { hdr.ip.src : exact; hdr.ip.dst : exact; }
        actions = { odd_conn; NoAction; } size = 32; default_action = NoAction();
    }
    action set_shape(bit<8> shape) { m.shape = (bit<3>)(shape); }
    table shape_t {
        key = { m.ip_odd : ternary; hdr.tcp.flags : ternary; m.has_mss : ternary; hdr.mss.kind : ternary;
                hdr.mss.len : ternary; m.tcp_odd : ternary; }
        actions = { set_shape; } size = 8; const default_action = set_shape(r_SH_NOACK);
        const entries = {(1, _, _, _, _, _): set_shape(r_SH_ODD);(0, 8w0x12 &&& 8w0x12, 1, 8w2, 8w4, 0): set_shape(r_SH_SYNACK_OK);(0, 8w0x02 &&& 8w0x02, _, _, _, _): set_shape(r_SH_SYN);(0, _, _, _, _, 1): set_shape(r_SH_ODD);(0, _, 1, _, _, _): set_shape(r_SH_ODD);(0, 8w0x10 &&& 8w0x10, _, _, _, _): set_shape(r_SH_ACK);}
    }
    Hash<bit<32>>(HashAlgorithm_t.IDENTITY) widen_len;
    action leff_off(bit<32> off) { m.leff = widen_len.get({hdr.ip.len}) + off; }   // ip.len - 40 [- prefix] [+ FIN]
    table leff_t {   
        key = { hdr.tcp.flags : ternary; hdr.dl.isValid() : ternary; hdr.dl.len : ternary; hdr.robj.isValid() : ternary;
                hdr.robj.g_group : ternary; hdr.robj.g_var : ternary; hdr.robj.g_qual : ternary; hdr.tcp.offset : exact; }
        actions = { leff_off; NoAction; } size = 8; const default_action = NoAction();
        const entries = { (_,_,_,_,_,_,_,4w10):leff_off(32w0xffffffc4);(_,_,_,_,_,_,_,4w11):leff_off(32w0xffffffc0); (8w0x01 &&& 8w0x01, true, 8w0x27, true, 8w0x01, 8w0x02, 8w0x01, 4w8) : leff_off(32w0xffffff9b);
                          (8w0x00 &&& 8w0x01, true, 8w0x27, true, 8w0x01, 8w0x02, 8w0x01, 4w8) : leff_off(32w0xffffff9a);
                          (8w0x01 &&& 8w0x01, true, 8w0x11, true, 8w0x01, 8w0x02, 8w0x01, 4w8) : leff_off(32w0xffffffb5);
                          (8w0x00 &&& 8w0x01, true, 8w0x11, true, 8w0x01, 8w0x02, 8w0x01, 4w8) : leff_off(32w0xffffffb4);
                          (8w0x01 &&& 8w0x01, _, _, _, _, _, _, 4w8) : leff_off(32w0xffffffcd); (8w0x00 &&& 8w0x01, _, _, _, _, _, _, 4w8) : leff_off(32w0xffffffcc); }
    }
    /* SALU operand staging by header r_bits only: acct reads {ina, leff}; img_wend reads {qx, t}. */
    Hash<bit<32>>(HashAlgorithm_t.IDENTITY) wire_ack_input;
    action qualified_wire_ack() { m.ina = wire_ack_input.get({hdr.prov.wgen}); m.qx = hdr.tcp.ack; }
    action prep_syn() { m.ina = hdr.tcp.seq + 1; m.qx = hdr.tcp.seq + 1; }
    action prep_ack() { m.ina = hdr.tcp.ack; m.qx = hdr.tcp.ack; }
    @placement_priority(90) table prep_t {
        key = { hdr.prov.kind : ternary; hdr.tcp.flags : ternary; }
        actions = { qualified_wire_ack; prep_syn; prep_ack; } size = 5; const default_action = prep_ack();
        const entries = { (8w0xe4, _) : qualified_wire_ack();(8w0xe5, _) : qualified_wire_ack();(8w13, _) : qualified_wire_ack();(_, 8w0x02 &&& 8w0x02) : prep_syn(); }
    }

    /* ============ padder verdict (case4_pad58b_wire.p4, unchanged logic) ============ */
    action read_shape(){m.read_shape=1w1;}
    table read_profile{key={hdr.dl.start:exact;hdr.dl.len:exact;hdr.rh.tpctrl:ternary;hdr.rh.appctrl:ternary;hdr.rh.func:exact;hdr.robj.g_group:exact;hdr.robj.g_var:exact;hdr.robj.g_qual:exact;hdr.robj.g_start:exact;hdr.robj.g_stop:exact;}
     actions={read_shape;NoAction;}size=2;const default_action=NoAction();
     const entries={(16w0x0564,8w0x27,8w0x40&&&8w0xC0,8w0xC0&&&8w0xF0,8w0x81,8w0x01,8w0x02,8w0x01,8w0x00,8w0x04):read_shape();(16w0x0564,8w0x11,8w0x40&&&8w0xC0,8w0xC0&&&8w0xF0,8w0x81,8w0x01,8w0x02,8w0x01,8w0x00,8w0x04):read_shape();}}
    action ctl_shape(){m.ctl_shape=1w1;}
    table ctl_profile{key={hdr.dl.start:exact;hdr.dl.len:exact;hdr.cb0.tpctrl:ternary;hdr.cb0.appctrl:ternary;hdr.cb0.func:exact;hdr.cb0.g_group:exact;hdr.cb0.g_var:exact;hdr.cb0.g_qual:exact;hdr.cb0.g_count:exact;hdr.cb0.index:exact;hdr.cb0.crob_code:exact;hdr.cb0.crob_count:exact;hdr.cb0.on_hi:exact;hdr.ctn.off:exact;hdr.ctn.index2:exact;hdr.ctn.code2:exact;hdr.ctn.count2:exact;hdr.ctn.on2:exact;hdr.ctn.off2:exact;}actions={ctl_shape;NoAction;}size=1;const default_action=NoAction();const entries={(16w0x0564,8w38,8w0xc0&&&8w0xc0,8w0xc0&&&8w0xf0,8w0x81,8w12,8w1,8w0x17,8w2,8w1,8w1,8w1,32w0xc8000000,32w0,8w3,8w1,8w1,32w0xc8000000,32w0):ctl_shape();}}
    CRCPolynomial<bit<16>>(16w0x3D65,true,false,false,16w0,16w0xFFFF) poly;
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_in_dl;
    action in_dl(){m.in_dl=hash_in_dl.get({hdr.dl.start,hdr.dl.len,hdr.dl.ctrl,hdr.dl.dst,hdr.dl.src});}
    table in_dl_t{actions={in_dl;}size=1;const default_action=in_dl();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_in_rb0;
    action in_rb0(){m.in_rb0=hash_in_rb0.get({hdr.rh.tpctrl,hdr.rh.appctrl,hdr.rh.func,hdr.rh.iin,hdr.robj.g_group,hdr.robj.g_var,hdr.robj.g_qual,hdr.robj.g_start,hdr.robj.g_stop,hdr.p03.d,hdr.p45.d});}
    table in_rb0_t{actions={in_rb0;}size=1;const default_action=in_rb0();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_in_rb1;
    action in_rb1(){m.in_rb1=hash_in_rb1.get({hdr.p69.d,hdr.p1012.d,hdr.p1321.d});}
    table in_rb1_t{actions={in_rb1;}size=1;const default_action=in_rb1();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_in_rt;
    action in_rt(){m.in_rt=hash_in_rt.get({hdr.p22.d});}
    table in_rt_t{actions={in_rt;}size=1;const default_action=in_rt();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_in_cb0;
    action in_cb0(){m.in_cb0=hash_in_cb0.get({hdr.cb0.tpctrl,hdr.cb0.appctrl,hdr.cb0.func,hdr.cb0.iin,hdr.cb0.g_group,hdr.cb0.g_var,hdr.cb0.g_qual,hdr.cb0.g_count,hdr.cb0.index,hdr.cb0.crob_code,hdr.cb0.crob_count,hdr.cb0.on_hi});}
    table in_cb0_t{actions={in_cb0;}size=1;const default_action=in_cb0();}
action status_crc(bit<16> expected,bit<16> encoded){m.in_rt=expected;m.ctcrc3=encoded;}
table status_crc_t{key={hdr.cstatus.status:exact;}actions={status_crc;NoAction;}size=256;const default_action=NoAction();const entries={8w0:status_crc(16w65535,16w65535);8w1:status_crc(16w51617,16w51617);8w2:status_crc(16w37699,16w37699);8w3:status_crc(16w42269,16w42269);8w4:status_crc(16w9863,16w9863);8w5:status_crc(16w4313,16w4313);8w6:status_crc(16w19003,16w19003);8w7:status_crc(16w31845,16w31845);8w8:status_crc(16w118,16w118);8w9:status_crc(16w13864,16w13864);8w10:status_crc(16w27850,16w27850);8w11:status_crc(16w23188,16w23188);8w12:status_crc(16w55566,16w55566);8w13:status_crc(16w61264,16w61264);8w14:status_crc(16w46514,16w46514);8w15:status_crc(16w33772,16w33772);8w16:status_crc(16w19860,16w19860);8w17:status_crc(16w31690,16w31690);8w18:status_crc(16w8488,16w8488);8w19:status_crc(16w6006,16w6006);8w20:status_crc(16w38124,16w38124);8w21:status_crc(16w41650,16w41650);8w22:status_crc(16w63568,16w63568);8w23:status_crc(16w52750,16w52750);8w24:status_crc(16w45597,16w45597);8w25:status_crc(16w33859,16w33859);8w26:status_crc(16w56993,16w56993);8w27:status_crc(16w59647,16w59647);8w28:status_crc(16w27493,16w27493);8w29:status_crc(16w23867,16w23867);8w30:status_crc(16w2009,16w2009);8w31:status_crc(16w12679,16w12679);8w32:status_crc(16w54864,16w54864);8w33:status_crc(16w57358,16w57358);8w34:status_crc(16w47852,16w47852);8w35:status_crc(16w36018,16w36018);8w36:status_crc(16w3880,16w3880);8w37:status_crc(16w14710,16w14710);8w38:status_crc(16w25492,16w25492);8w39:status_crc(16w21962,16w21962);8w40:status_crc(16w10713,16w10713);8w41:status_crc(16w8071,16w8071);8w42:status_crc(16w17765,16w17765);8w43:status_crc(16w29499,16w29499);8w44:status_crc(16w61601,16w61601);8w45:status_crc(16w50943,16w50943);8w46:status_crc(16w39965,16w39965);8w47:status_crc(16w43587,16w43587);8w48:status_crc(16w25659,16w25659);8w49:status_crc(16w21093,16w21093);8w50:status_crc(16w2183,16w2183);8w51:status_crc(16w16089,16w16089);8w52:status_crc(16w48451,16w48451);8w53:status_crc(16w35613,16w35613);8w54:status_crc(16w53759,16w53759);8w55:status_crc(16w59297,16w59297);8w56:status_crc(16w39858,16w39858);8w57:status_crc(16w44524,16w44524);8w58:status_crc(16w63246,16w63246);8w59:status_crc(16w49488,16w49488);8w60:status_crc(16w17098,16w17098);8w61:status_crc(16w29844,16w29844);8w62:status_crc(16w11894,16w11894);8w63:status_crc(16w6184,16w6184);8w64:status_crc(16w44193,16w44193);8w65:status_crc(16w39679,16w39679);8w66:status_crc(16w49181,16w49181);8w67:status_crc(16w63043,16w63043);8w68:status_crc(16w30169,16w30169);8w69:status_crc(16w17287,16w17287);8w70:status_crc(16w6501,16w6501);8w71:status_crc(16w12091,16w12091);8w72:status_crc(16w21288,16w21288);8w73:status_crc(16w25974,16w25974);8w74:status_crc(16w16276,16w16276);8w75:status_crc(16w2506,16w2506);8w76:status_crc(16w35408,16w35408);8w77:status_crc(16w48142,16w48142);8w78:status_crc(16w59116,16w59116);8w79:status_crc(16w53426,16w53426);8w80:status_crc(16w7882,16w7882);8w81:status_crc(16w10388,16w10388);8w82:status_crc(16w29302,16w29302);8w83:status_crc(16w17448,16w17448);8w84:status_crc(16w51122,16w51122);8w85:status_crc(16w61932,16w61932);8w86:status_crc(16w43790,16w43790);8w87:status_crc(16w40272,16w40272);8w88:status_crc(16w57667,16w57667);8w89:status_crc(16w55069,16w55069);8w90:status_crc(16w36351,16w36351);8w91:status_crc(16w48033,16w48033);8w92:status_crc(16w14395,16w14395);8w93:status_crc(16w3685,16w3685);8w94:status_crc(16w21639,16w21639);8w95:status_crc(16w25305,16w25305);8w96:status_crc(16w34062,16w34062);8w97:status_crc(16w45904,16w45904);8w98:status_crc(16w59826,16w59826);8w99:status_crc(16w57324,16w57324);8w100:status_crc(16w23670,16w23670);8w101:status_crc(16w27176,16w27176);8w102:status_crc(16w12490,16w12490);8w103:status_crc(16w1684,16w1684);8w104:status_crc(16w31367,16w31367);8w105:status_crc(16w19673,16w19673);8w106:status_crc(16w5691,16w5691);8w107:status_crc(16w8293,16w8293);8w108:status_crc(16w41983,16w41983);8w109:status_crc(16w38305,16w38305);8w110:status_crc(16w53059,16w53059);8w111:status_crc(16w63773,16w63773);8w112:status_crc(16w14181,16w14181);8w113:status_crc(16w315,16w315);8w114:status_crc(16w23513,16w23513);8w115:status_crc(16w28039,16w28039);8w116:status_crc(16w60957,16w60957);8w117:status_crc(16w55363,16w55363);8w118:status_crc(16w33441,16w33441);8w119:status_crc(16w46335,16w46335);8w120:status_crc(16w51436,16w51436);8w121:status_crc(16w65202,16w65202);8w122:status_crc(16w42064,16w42064);8w123:status_crc(16w37390,16w37390);8w124:status_crc(16w4500,16w4500);8w125:status_crc(16w10186,16w10186);8w126:status_crc(16w32040,16w32040);8w127:status_crc(16w19318,16w19318);8w128:status_crc(16w22851,16w22851);8w129:status_crc(16w28445,16w28445);8w130:status_crc(16w13823,16w13823);8w131:status_crc(16w929,16w929);8w132:status_crc(16w32827,16w32827);8w133:status_crc(16w46693,16w46693);8w134:status_crc(16w60551,16w60551);8w135:status_crc(16w56025,16w56025);8w136:status_crc(16w42698,16w42698);8w137:status_crc(16w37012,16w37012);8w138:status_crc(16w51830,16w51830);8w139:status_crc(16w64552,16w64552);8w140:status_crc(16w32690,16w32690);8w141:status_crc(16w18924,16w18924);8w142:status_crc(16w4878,16w4878);8w143:status_crc(16w9552,16w9552);8w144:status_crc(16w60200,16w60200);8w145:status_crc(16w56694,16w56694);8w146:status_crc(16w34708,16w34708);8w147:status_crc(16w45514,16w45514);8w148:status_crc(16w12880,16w12880);8w149:status_crc(16w1038,16w1038);8w150:status_crc(16w24300,16w24300);8w151:status_crc(16w26802,16w26802);8w152:status_crc(16w5281,16w5281);8w153:status_crc(16w8959,16w8959);8w154:status_crc(16w30749,16w30749);8w155:status_crc(16w20035,16w20035);8w156:status_crc(16w52697,16w52697);8w157:status_crc(16w64391,16w64391);8w158:status_crc(16w41317,16w41317);8w159:status_crc(16w38715,16w38715);8w160:status_crc(16w28908,16w28908);8w161:status_crc(16w18098,16w18098);8w162:status_crc(16w7248,16w7248);8w163:status_crc(16w10766,16w10766);8w164:status_crc(16w43412,16w43412);8w165:status_crc(16w40906,16w40906);8w166:status_crc(16w50472,16w50472);8w167:status_crc(16w62326,16w62326);8w168:status_crc(16w36709,16w36709);8w169:status_crc(16w47419,16w47419);8w170:status_crc(16w58329,16w58329);8w171:status_crc(16w54663,16w54663);8w172:status_crc(16w22045,16w22045);8w173:status_crc(16w24643,16w24643);8w174:status_crc(16w15009,16w15009);8w175:status_crc(16w3327,16w3327);8w176:status_crc(16w49799,16w49799);8w177:status_crc(16w62681,16w62681);8w178:status_crc(16w44603,16w44603);8w179:status_crc(16w39013,16w39013);8w180:status_crc(16w7167,16w7167);8w181:status_crc(16w11681,16w11681);8w182:status_crc(16w30531,16w30531);8w183:status_crc(16w16669,16w16669);8w184:status_crc(16w15630,16w15630);8w185:status_crc(16w2896,16w2896);8w186:status_crc(16w20914,16w20914);8w187:status_crc(16w26604,16w26604);8w188:status_crc(16w58486,16w58486);8w189:status_crc(16w53800,16w53800);8w190:status_crc(16w35018,16w35018);8w191:status_crc(16w48788,16w48788);8w192:status_crc(16w2589,16w2589);8w193:status_crc(16w15427,16w15427);8w194:status_crc(16w26273,16w26273);8w195:status_crc(16w20735,16w20735);8w196:status_crc(16w54117,16w54117);8w197:status_crc(16w58683,16w58683);8w198:status_crc(16w49113,16w49113);8w199:status_crc(16w35207,16w35207);8w200:status_crc(16w62868,16w62868);8w201:status_crc(16w50122,16w50122);8w202:status_crc(16w39208,16w39208);8w203:status_crc(16w44918,16w44918);8w204:status_crc(16w11500,16w11500);8w205:status_crc(16w6834,16w6834);8w206:status_crc(16w16464,16w16464);8w207:status_crc(16w30222,16w30222);8w208:status_crc(16w47222,16w47222);8w209:status_crc(16w36392,16w36392);8w210:status_crc(16w54474,16w54474);8w211:status_crc(16w58004,16w58004);8w212:status_crc(16w24846,16w24846);8w213:status_crc(16w22352,16w22352);8w214:status_crc(16w3506,16w3506);8w215:status_crc(16w15340,16w15340);8w216:status_crc(16w18431,16w18431);8w217:status_crc(16w29089,16w29089);8w218:status_crc(16w11075,16w11075);8w219:status_crc(16w7453,16w7453);8w220:status_crc(16w40583,16w40583);8w221:status_crc(16w43225,16w43225);8w222:status_crc(16w62011,16w62011);8w223:status_crc(16w50277,16w50277);8w224:status_crc(16w9138,16w9138);8w225:status_crc(16w5612,16w5612);8w226:status_crc(16w20238,16w20238);8w227:status_crc(16w31056,16w31056);8w228:status_crc(16w64202,16w64202);8w229:status_crc(16w52372,16w52372);8w230:status_crc(16w38518,16w38518);8w231:status_crc(16w41000,16w41000);8w232:status_crc(16w56379,16w56379);8w233:status_crc(16w60005,16w60005);8w234:status_crc(16w45191,16w45191);8w235:status_crc(16w34521,16w34521);8w236:status_crc(16w1347,16w1347);8w237:status_crc(16w13085,16w13085);8w238:status_crc(16w27135,16w27135);8w239:status_crc(16w24481,16w24481);8w240:status_crc(16w37337,16w37337);8w241:status_crc(16w42887,16w42887);8w242:status_crc(16w64869,16w64869);8w243:status_crc(16w52027,16w52027);8w244:status_crc(16w18593,16w18593);8w245:status_crc(16w32511,16w32511);8w246:status_crc(16w9245,16w9245);8w247:status_crc(16w4675,16w4675);8w248:status_crc(16w28240,16w28240);8w249:status_crc(16w22542,16w22542);8w250:status_crc(16w748,16w748);8w251:status_crc(16w13490,16w13490);8w252:status_crc(16w46888,16w46888);8w253:status_crc(16w33142,16w33142);8w254:status_crc(16w56212,16w56212);8w255:status_crc(16w60874,16w60874);}}
    action tail_status_crc(bit<16> native,bit<16> contribution){m.in_ct=native;m.ctcrc2=contribution;}
    table in_ct_t{key={hdr.ctn.status:exact;}actions={tail_status_crc;NoAction;}size=256;const default_action=NoAction();const entries={8w0:tail_status_crc(16w63371,16w0);8w1:tail_status_crc(16w7020,16w5774);8w2:tail_status_crc(16w25404,16w11548);8w3:tail_status_crc(16w36827,16w15250);8w4:tail_status_crc(16w37788,16w23096);8w5:tail_status_crc(16w32635,16w19638);8w6:tail_status_crc(16w1835,16w30500);8w7:tail_status_crc(16w60364,16w25002);8w8:tail_status_crc(16w16293,16w46192);8w9:tail_status_crc(16w54082,16w41726);8w10:tail_status_crc(16w43794,16w39276);8w11:tail_status_crc(16w18421,16w36834);8w12:tail_status_crc(16w23474,16w61000);8w13:tail_status_crc(16w46933,16w63686);8w14:tail_status_crc(16w52997,16w50004);8w15:tail_status_crc(16w9186,16w54746);8w16:tail_status_crc(16w10926,16w9625);8w17:tail_status_crc(16w50761,16w13079);8w18:tail_status_crc(16w48665,16w2181);8w19:tail_status_crc(16w21246,16w7691);8w20:tail_status_crc(16w20153,16w32673);8w21:tail_status_crc(16w41566,16w26927);8w22:tail_status_crc(16w55822,16w21181);8w23:tail_status_crc(16w14057,16w17459);8w24:tail_status_crc(16w57984,16w37353);8w25:tail_status_crc(16w3687,16w34663);8w26:tail_status_crc(16w30263,16w48373);8w27:tail_status_crc(16w39632,16w43643);8w28:tail_status_crc(16w34455,16w52177);8w29:tail_status_crc(16w27248,16w56671);8w30:tail_status_crc(16w4640,16w59085);8w31:tail_status_crc(16w65223,16w61507);8w32:tail_status_crc(16w184,16w19250);8w33:tail_status_crc(16w60511,16w23996);8w34:tail_status_crc(16w37903,16w26158);8w35:tail_status_crc(16w30952,16w28832);8w36:tail_status_crc(16w25775,16w4362);8w37:tail_status_crc(16w34888,16w1924);8w38:tail_status_crc(16w61464,16w15382);8w39:tail_status_crc(16w7423,16w10904);8w40:tail_status_crc(16w51350,16w65346);8w41:tail_status_crc(16w9329,16w59852);8w42:tail_status_crc(16w23585,16w53854);8w43:tail_status_crc(16w45254,16w50384);8w44:tail_status_crc(16w44161,16w42362);8w45:tail_status_crc(16w16486,16w46068);8w46:tail_status_crc(16w14390,16w34918);8w47:tail_status_crc(16w54481,16w40680);8w48:tail_status_crc(16w56733,16w28331);8w49:tail_status_crc(16w12666,16w30757);8w50:tail_status_crc(16w18730,16w17335);8w51:tail_status_crc(16w42445,16w21817);8w52:tail_status_crc(16w47498,16w13459);8w53:tail_status_crc(16w21869,16w8733);8w54:tail_status_crc(16w11581,16w6543);8w55:tail_status_crc(16w49626,16w3841);8w56:tail_status_crc(16w5555,16w56027);8w57:tail_status_crc(16w63828,16w52309);8w58:tail_status_crc(16w33028,16w63431);8w59:tail_status_crc(16w28131,16w57673);8w60:tail_status_crc(16w29092,16w32995);8w61:tail_status_crc(16w40259,16w38509);8w62:tail_status_crc(16w58643,16w44543);8w63:tail_status_crc(16w2548,16w47985);8w64:tail_status_crc(16w21652,16w38500);8w65:tail_status_crc(16w47219,16w33002);8w66:tail_status_crc(16w49187,16w47992);8w67:tail_status_crc(16w11460,16w44534);8w68:tail_status_crc(16w12419,16w52316);8w69:tail_status_crc(16w56420,16w56018);8w70:tail_status_crc(16w42036,16w57664);8w71:tail_status_crc(16w18643,16w63438);8w72:tail_status_crc(16w40122,16w8724);8w73:tail_status_crc(16w28765,16w13466);8w74:tail_status_crc(16w2061,16w3848);8w75:tail_status_crc(16w58602,16w6534);8w76:tail_status_crc(16w63661,16w30764);8w77:tail_status_crc(16w5194,16w28322);8w78:tail_status_crc(16w27674,16w21808);8w79:tail_status_crc(16w33021,16w17342);8w80:tail_status_crc(16w35249,16w46077);8w81:tail_status_crc(16w25942,16w42355);8w82:tail_status_crc(16w7430,16w40673);8w83:tail_status_crc(16w61921,16w34927);8w84:tail_status_crc(16w60838,16w59845);8w85:tail_status_crc(16w321,16w65355);8w86:tail_status_crc(16w30993,16w50393);8w87:tail_status_crc(16w38390,16w53847);8w88:tail_status_crc(16w16799,16w1933);8w89:tail_status_crc(16w44408,16w4355);8w90:tail_status_crc(16w54568,16w10897);8w91:tail_status_crc(16w14799,16w15391);8w92:tail_status_crc(16w9608,16w23989);8w93:tail_status_crc(16w51567,16w19259);8w94:tail_status_crc(16w45375,16w28841);8w95:tail_status_crc(16w24024,16w26151);8w96:tail_status_crc(16w41895,16w56662);8w97:tail_status_crc(16w20288,16w52184);8w98:tail_status_crc(16w14096,16w61514);8w99:tail_status_crc(16w56311,16w59076);8w100:tail_status_crc(16w51120,16w34670);8w101:tail_status_crc(16w11095,16w37344);8w102:tail_status_crc(16w21255,16w43634);8w103:tail_status_crc(16w49120,16w48380);8w104:tail_status_crc(16w27529,16w26918);8w105:tail_status_crc(16w34670,16w32680);8w106:tail_status_crc(16w65342,16w17466);8w107:tail_status_crc(16w5081,16w21172);8w108:tail_status_crc(16w3998,16w13086);8w109:tail_status_crc(16w58233,16w9616);8w110:tail_status_crc(16w39721,16w7682);8w111:tail_status_crc(16w30670,16w2188);8w112:tail_status_crc(16w32386,16w63695);8w113:tail_status_crc(16w37477,16w60993);8w114:tail_status_crc(16w59957,16w54739);8w115:tail_status_crc(16w1746,16w50013);8w116:tail_status_crc(16w6805,16w41719);8w117:tail_status_crc(16w63090,16w46201);8w118:tail_status_crc(16w36386,16w36843);8w119:tail_status_crc(16w25285,16w39269);8w120:tail_status_crc(16w46764,16w19647);8w121:tail_status_crc(16w23115,16w23089);8w122:tail_status_crc(16w8731,16w24995);8w123:tail_status_crc(16w52988,16w30509);8w124:tail_status_crc(16w53947,16w5767);8w125:tail_status_crc(16w15964,16w9);8w126:tail_status_crc(16w17932,16w15259);8w127:tail_status_crc(16w43755,16w11541);8w128:tail_status_crc(16w64716,16w25009);8w129:tail_status_crc(16w4139,16w30527);8w130:tail_status_crc(16w26747,16w19629);8w131:tail_status_crc(16w33948,16w23075);8w132:tail_status_crc(16w39131,16w15241);8w133:tail_status_crc(16w29756,16w11527);8w134:tail_status_crc(16w3180,16w5781);8w135:tail_status_crc(16w57483,16w27);8w136:tail_status_crc(16w13538,16w54721);8w137:tail_status_crc(16w55301,16w49999);8w138:tail_status_crc(16w41045,16w63709);8w139:tail_status_crc(16w19634,16w61011);8w140:tail_status_crc(16w20725,16w36857);8w141:tail_status_crc(16w48146,16w39287);8w142:tail_status_crc(16w50242,16w41701);8w143:tail_status_crc(16w10405,16w46187);8w144:tail_status_crc(16w8681,16w17448);8w145:tail_status_crc(16w52494,16w21158);8w146:tail_status_crc(16w46430,16w26932);8w147:tail_status_crc(16w22969,16w32698);8w148:tail_status_crc(16w17918,16w7696);8w149:tail_status_crc(16w43289,16w2206);8w150:tail_status_crc(16w53577,16w13068);8w151:tail_status_crc(16w15790,16w9602);8w152:tail_status_crc(16w59847,16w61528);8w153:tail_status_crc(16w1312,16w59094);8w154:tail_status_crc(16w32112,16w56644);8w155:tail_status_crc(16w37271,16w52170);8w156:tail_status_crc(16w36304,16w43616);8w157:tail_status_crc(16w24887,16w48366);8w158:tail_status_crc(16w6503,16w34684);8w159:tail_status_crc(16w62848,16w37362);8w160:tail_status_crc(16w3071,16w10883);8w161:tail_status_crc(16w59160,16w15373);8w162:tail_status_crc(16w40776,16w1951);8w163:tail_status_crc(16w29615,16w4369);8w164:tail_status_crc(16w28648,16w28859);8w165:tail_status_crc(16w33551,16w26165);8w166:tail_status_crc(16w64351,16w23975);8w167:tail_status_crc(16w6072,16w19241);8w168:tail_status_crc(16w50129,16w40691);8w169:tail_status_crc(16w12086,16w34941);8w170:tail_status_crc(16w22374,16w46063);8w171:tail_status_crc(16w48001,16w42337);8w172:tail_status_crc(16w42950,16w50379);8w173:tail_status_crc(16w19233,16w53829);8w174:tail_status_crc(16w13169,16w59863);8w175:tail_status_crc(16w57238,16w65369);8w176:tail_status_crc(16w55002,16w3866);8w177:tail_status_crc(16w14909,16w6548);8w178:tail_status_crc(16w17005,16w8710);8w179:tail_status_crc(16w44682,16w13448);8w180:tail_status_crc(16w45773,16w21794);8w181:tail_status_crc(16w24106,16w17324);8w182:tail_status_crc(16w9850,16w30782);8w183:tail_status_crc(16w51869,16w28336);8w184:tail_status_crc(16w7924,16w47978);8w185:tail_status_crc(16w61971,16w44516);8w186:tail_status_crc(16w35395,16w38518);8w187:tail_status_crc(16w26276,16w33016);8w188:tail_status_crc(16w31459,16w57682);8w189:tail_status_crc(16w38404,16w63452);8w190:tail_status_crc(16w61012,16w52302);8w191:tail_status_crc(16w691,16w56000);8w192:tail_status_crc(16w24531,16w63445);8w193:tail_status_crc(16w45876,16w57691);8w194:tail_status_crc(16w52068,16w56009);8w195:tail_status_crc(16w10115,16w52295);8w196:tail_status_crc(16w15300,16w44525);8w197:tail_status_crc(16w55075,16w47971);8w198:tail_status_crc(16w44915,16w33009);8w199:tail_status_crc(16w17300,16w38527);8w200:tail_status_crc(16w38909,16w17317);8w201:tail_status_crc(16w31514,16w21803);8w202:tail_status_crc(16w842,16w28345);8w203:tail_status_crc(16w61357,16w30775);8w204:tail_status_crc(16w62442,16w6557);8w205:tail_status_crc(16w7949,16w3859);8w206:tail_status_crc(16w26461,16w13441);8w207:tail_status_crc(16w35770,16w8719);8w208:tail_status_crc(16w33526,16w53836);8w209:tail_status_crc(16w28177,16w50370);8w210:tail_status_crc(16w5697,16w65360);8w211:tail_status_crc(16w64166,16w59870);8w212:tail_status_crc(16w59105,16w34932);8w213:tail_status_crc(16w2566,16w40698);8w214:tail_status_crc(16w29270,16w42344);8w215:tail_status_crc(16w40625,16w46054);8w216:tail_status_crc(16w19160,16w26172);8w217:tail_status_crc(16w42559,16w28850);8w218:tail_status_crc(16w56943,16w19232);8w219:tail_status_crc(16w12936,16w23982);8w220:tail_status_crc(16w11983,16w15364);8w221:tail_status_crc(16w49704,16w10890);8w222:tail_status_crc(16w47736,16w4376);8w223:tail_status_crc(16w22175,16w1942);8w224:tail_status_crc(16w43232,16w48359);8w225:tail_status_crc(16w17415,16w43625);8w226:tail_status_crc(16w15447,16w37371);8w227:tail_status_crc(16w53424,16w34677);8w228:tail_status_crc(16w52471,16w59103);8w229:tail_status_crc(16w8208,16w61521);8w230:tail_status_crc(16w22592,16w52163);8w231:tail_status_crc(16w46247,16w56653);8w232:tail_status_crc(16w24782,16w2199);8w233:tail_status_crc(16w35881,16w7705);8w234:tail_status_crc(16w62585,16w9611);8w235:tail_status_crc(16w6302,16w13061);8w236:tail_status_crc(16w1241,16w21167);8w237:tail_status_crc(16w59454,16w17441);8w238:tail_status_crc(16w36974,16w32691);8w239:tail_status_crc(16w31881,16w26941);8w240:tail_status_crc(16w30149,16w39294);8w241:tail_status_crc(16w39202,16w36848);8w242:tail_status_crc(16w57714,16w46178);8w243:tail_status_crc(16w3477,16w41708);8w244:tail_status_crc(16w4562,16w49990);8w245:tail_status_crc(16w64821,16w54728);8w246:tail_status_crc(16w34149,16w61018);8w247:tail_status_crc(16w27010,16w63700);8w248:tail_status_crc(16w48619,16w11534);8w249:tail_status_crc(16w20748,16w15232);8w250:tail_status_crc(16w10588,16w18);8w251:tail_status_crc(16w50619,16w5788);8w252:tail_status_crc(16w55804,16w30518);8w253:tail_status_crc(16w13595,16w25016);8w254:tail_status_crc(16w19787,16w23082);8w255:tail_status_crc(16w41388,16w19620);}}

    Register<bit<32>, r_slot_t>(16, 0) epoch;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(epoch) epoch_normalize = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v & 32w0x7fffffff; }
    };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(epoch) epoch_check = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v ^ hdr.prov.epoch; }
    };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(epoch) epoch_open = {
        void apply(inout bit<32> v, out bit<32> rv) {
            // Bounded incoming epochs have MSB zero. The unsigned comparison
            // handles unlatched v; the signed, MSB-set input handles latched v.
            // The irrelevant comparison r_is false in each case, using two CUs.
            if (hdr.prov.epoch > v || (int<32>)m.open_bound > (int<32>)v) { v = hdr.prov.epoch; rv = 0; }
            else { rv = 1; }
        }
    };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(epoch) epoch_first = {
        void apply(inout bit<32> v, out bit<32> rv) {
            rv = v ^ hdr.prov.epoch;
            if (v == hdr.prov.epoch && v != 0) { v = v | 32w0x80000000; }
        }
    };
    action normalize_epoch() { hdr.prov.epoch = epoch_normalize.execute(m.idx); m.life_bad = 0; m.normalize = 1; }
    action capture_normalization_ack() { hdr.prov.wgen = hdr.tcp.ack; }
    table normalization_ack_t {
        key = { hdr.prov.kind : exact; }
        actions = { capture_normalization_ack; NoAction; }
        const entries = { 8w0xe0 : capture_normalization_ack(); }
        default_action = NoAction(); size = 1;
    }
    action check_epoch() { m.life_bad = epoch_check.execute(m.idx); }
    action open_epoch() { m.life_bad = epoch_open.execute(m.idx); }
    action first_epoch() { m.life_bad = epoch_first.execute(m.idx); m.first_synack = 1; }
    action reject_lifetime() { m.life_bad = 1; }
    action prepare_open() { m.open_bound = hdr.prov.epoch | 32w0x80000000; }
    table prepare_open_t {
        key = { hdr.prov.kind : exact; }
        actions = { prepare_open; NoAction; }
        const entries = { 8w14 : prepare_open(); }
        default_action = NoAction(); size = 1;
    }
    @placement_priority(100) table lifecycle_access {
        key = { hdr.tcp.isValid() : exact; m.dir : ternary; hdr.prov.kind : ternary; hdr.prov.epoch : ternary; }
        actions = { normalize_epoch; check_epoch; open_epoch; first_epoch; reject_lifetime; NoAction; }
        const entries = {(false, _, _, _): NoAction();(true, 0, _, _): NoAction();(true, _, _, 32w0x80000000 &&& 32w0x80000000): reject_lifetime();(true, _, _, 32w0x7fffffff): reject_lifetime();(true, _, 8w0xe7, 0): reject_lifetime();(true, _, 8w0xe0, _): normalize_epoch();(true, _, 8w14, _): open_epoch();(true, _, 8w0xe3, _): check_epoch();(true, _, 8w0xe4, _): check_epoch();(true, _, 8w0xe5, _): check_epoch();(true, _, 8w0xe7, _): first_epoch();(true, _, 8w9, _): check_epoch();(true, _, 8w10, _): check_epoch();(true, _, 8w11, _): check_epoch();(true, _, 8w12, _): check_epoch();(true, _, 8w13, _): check_epoch();(true, _, _, _): reject_lifetime();}
        default_action = NoAction(); size = 17;
    }
    Register<bit<32>, r_slot_t>(16, 0) master_isn;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(master_isn) isn_open = {
        void apply(inout bit<32> v, out bit<32> rv) { v = hdr.tcp.seq; rv = v; }
    };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(master_isn) isn_read = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v ^ hdr.tcp.seq; }
    };
    action open_isn() { isn_open.execute(m.idx); }
    action check_isn() { m.life_bad = isn_read.execute(m.idx); }
    table isn_access {
        key = { hdr.prov.kind : exact; m.life_bad : exact; }
        actions = { open_isn; check_isn; NoAction; }
        const entries = { (14, 0) : open_isn(); (8w0xe0, 0) : check_isn(); }
        default_action = NoAction(); size = 2;
    }
    action normalization_stamp(bit<32> same) {
        hdr.prov.aux = same;
    }
    table normalization_result {
        key = { m.life_bad : exact; }
        actions = { normalization_stamp; }
        const entries = { 32w0 : normalization_stamp(32w1); }
        default_action = normalization_stamp(32w0); size = 1;
    }
    action commit_return() { hdr.prov.kind = 8w0xe6; }
    action unbound_normalization() { hdr.prov.epoch = 0; hdr.prov.aux = 0; hdr.prov.kind = 8w0xe1; }
    action normalization_return() { hdr.prov.kind = 8w0xe1; }
    action strip_provenance() { hdr.prov.setInvalid(); }
    action drop_lifetime() { md.drop_ctl = 3w1; }
    table envelope_result {
        key = { hdr.prov.kind : exact; }
        actions = { commit_return; strip_provenance; normalization_return; NoAction; }
        const entries = { 8w0xe0 : normalization_return(); 8w0xe1 : NoAction(); 8w0xe5 : commit_return(); }
        default_action = strip_provenance(); size = 3;
    }

    /* ============ mapper registers ============ */
    Register<bit<8>, r_slot_t>(16, 0) mode;
    RegisterAction<bit<8>, r_slot_t, bit<8>>(mode) mode_arm_map = { void apply(inout bit<8> v, out bit<8> rv) { rv = v; if (v == 2) { v = 1; } } };
    RegisterAction<bit<8>, r_slot_t, bit<8>>(mode) mode_arm_nat = { void apply(inout bit<8> v) { v = 2; } };
    RegisterAction<bit<8>, r_slot_t, bit<8>>(mode) mode_read = { void apply(inout bit<8> v, out bit<8> rv) { rv = v; } };
    action do_mode_arm_map() { m.mode = (bit<2>)(mode_arm_map.execute(m.idx)); }
    action do_mode_arm_nat() { mode_arm_nat.execute(m.idx); }
    action do_mode_read() { m.mode = (bit<2>)(mode_read.execute(m.idx)); }
    table mode_t {
        key = { hdr.prov.kind : ternary; }
        actions = { do_mode_arm_map; do_mode_arm_nat; do_mode_read; NoAction; }
        const entries = { 8w14 : do_mode_arm_nat(); 8w0xe7 : do_mode_arm_map(); _ : do_mode_read(); }
        default_action = NoAction(); size = 3;
    }


    Register<bit<32>, r_slot_t>(16, 0) front;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(front) front_arm = {
        void apply(inout bit<32> v) { v = hdr.tcp.seq + 1; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(front) front_step = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = hdr.tcp.seq - v; if (v == hdr.tcp.seq) { v = v + m.leff; } } };
    action do_front_arm() { front_arm.execute(m.idx); }
    action do_front_step() { m.front_ret = front_step.execute(m.idx); }
    table front_t {
        key = { hdr.prov.kind : ternary; m.dir : exact; m.shape : ternary; }
        actions = { do_front_arm; do_front_step; NoAction; } size = 4; const default_action = NoAction();
        const entries = {(8w0xe7, 1, (bit<3>)r_SH_SYNACK_OK): do_front_arm();(_, 1, 3w4 &&& 3w7): do_front_step();}
    }

    /* acct = {lo: W, hi: U = W - A}; a commit adds the whole 58-byte image (L + d = 58 for both
       profiles), any other frontier segment adds Leff. */
    action set_ina(bit<32> v) { m.ina = v; }
    table ina_img_t { key = { m.read_shape : exact; m.ctl_shape : exact; hdr.dl.len : ternary; }
        actions = { set_ina; NoAction; } size = 4; const default_action = NoAction();
        const entries = { (1, 0, 8w0x27) : set_ina(141); (1, 0, 8w0x11) : set_ina(158); (0, 1, _) : set_ina(60); } }
    Register<r_pair32, r_slot_t>(16, {0, 0}) acct;
    RegisterAction<r_pair32, r_slot_t, bit<8>>(acct) acct_arm = {
        void apply(inout r_pair32 v) { v.lo = m.ina; v.hi = 0; } };
    RegisterAction<r_pair32, r_slot_t, bit<8>>(acct) acct_try = {
        void apply(inout r_pair32 v, out bit<8> rv) {
            rv = 0;
            if (v.hi == 0) { v.lo = v.lo + m.ina; v.hi = v.hi + m.ina; rv = 1; }
            else { v.lo = v.lo + m.leff; v.hi = v.hi + m.leff; }
        } };
    RegisterAction<r_pair32, r_slot_t, bit<8>>(acct) acct_grow = {
        void apply(inout r_pair32 v) { v.lo = v.lo + m.leff; v.hi = v.hi + m.leff; } };
    RegisterAction<r_pair32, r_slot_t, bit<8>>(acct) acct_rev = {
        void apply(inout r_pair32 v) { v.hi = v.lo - m.ina; } };
    action do_acct_arm() { acct_arm.execute(m.idx); }
    action do_acct_try() { m.grant = (bit<1>)(acct_try.execute(m.idx)); }
    action do_acct_grow() { acct_grow.execute(m.idx); }
    action do_acct_rev() { acct_rev.execute(m.idx); }
    table acct_t {   
        key = { hdr.prov.kind : ternary; m.dir : exact; m.shape : ternary; m.front_ret : ternary; m.enable : ternary; hdr.tcp.flags : ternary;
                m.leff : ternary; m.read_shape : ternary; m.ctl_shape : ternary; m.badh : ternary;
                m.rbad0 : ternary; m.rbad1 : ternary; m.rbadt : ternary; m.cbad0 : ternary; m.cbadt : ternary; }
        actions = { do_acct_arm; do_acct_try; do_acct_grow; do_acct_rev; NoAction; } size = 10;
        const default_action = NoAction();
        const entries = {(8w0xe7, 1, (bit<3>)r_SH_SYNACK_OK, _, _, _, _, _, _, _, _, _, _, _, _): do_acct_arm();(_, 1, 3w4 &&& 3w7, 0, 1, 8w0 &&& 8w0x07, 91, 1, _, 0, 0, 0, 0, _, _): do_acct_try();(_, 1, 3w4 &&& 3w7, 0, 1, 8w0 &&& 8w0x07, 134, 1, _, 0, 0, 0, 0, _, _): do_acct_try();(_, 1, 3w4 &&& 3w7, 0, 1, 8w0 &&& 8w0x07, 49, _, 1, 0, _, _, _, 0, 0): do_acct_try();(_, 1, 3w4 &&& 3w7, 0, _, _, _, _, _, _, _, _, _, _, _): do_acct_grow();(8w0xe4, 2, (bit<3>)r_SH_ACK, _, _, _, _, _, _, _, _, _, _, _, _): do_acct_rev();(8w0xe5, 2, (bit<3>)r_SH_ACK, _, _, _, _, _, _, _, _, _, _, _, _): do_acct_rev();(8w13, 2, (bit<3>)r_SH_ACK, _, _, _, _, _, _, _, _, _, _, _, _): do_acct_rev();}
    }

    Register<bit<32>, r_slot_t>(16, 0) img_end;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_end) end_arm = {
        void apply(inout bit<32> v) { v = hdr.tcp.seq + 1; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_end) end_commit = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = hdr.tcp.seq - v; v = m.s_end; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_end) end_fwd = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = hdr.tcp.seq - v; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_end) end_rev = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v; } };
    action do_end_arm() { end_arm.execute(m.idx); }
    action do_end_commit() { m.q = end_commit.execute(m.idx); }
    action do_end_fwd() { m.q = end_fwd.execute(m.idx); }
    action do_end_rev() { m.q = end_rev.execute(m.idx); }
    table img_end_t {
        key = { m.first_synack : ternary; m.dir : exact; m.shape : ternary; m.grant : ternary; }
        actions = { do_end_arm; do_end_commit; do_end_fwd; do_end_rev; NoAction; } size = 8;
        const default_action = NoAction();
        
        const entries = {(1w1, 1, (bit<3>)r_SH_SYNACK_OK, _): do_end_arm();(_, 1, 3w4 &&& 3w7, 0): do_end_fwd();(_, 1, 3w4 &&& 3w7, _): do_end_commit();(_, 2, (bit<3>)r_SH_ACK, _): do_end_rev();}
    }

    Register<bit<32>, r_slot_t>(16, 0) img_start;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_start) start_arm = {     // virtual image: ISN+1-61
        void apply(inout bit<32> v) { v = hdr.tcp.seq + 32w0xFFFFFFC4; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_start) start_commit = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = hdr.tcp.seq - v; v = hdr.tcp.seq; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_start) start_fwd = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = hdr.tcp.seq - v; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_start) start_rev = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v; } };
    action do_start_arm() { start_arm.execute(m.idx); }
    action do_start_commit() { m.p = start_commit.execute(m.idx); }
    action do_start_fwd() { m.p = start_fwd.execute(m.idx); }
    action do_start_rev() { m.p = start_rev.execute(m.idx); }
    table img_start_t {
        key = { m.first_synack : ternary; m.dir : exact; m.shape : ternary; m.grant : ternary; }
        actions = { do_start_arm; do_start_commit; do_start_fwd; do_start_rev; NoAction; } size = 8;
        const default_action = NoAction();
        const entries = {(1w1, 1, (bit<3>)r_SH_SYNACK_OK, _): do_start_arm();(_, 1, 3w4 &&& 3w7, 0): do_start_fwd();(_, 1, 3w4 &&& 3w7, _): do_start_commit();(_, 2, (bit<3>)r_SH_ACK, _): do_start_rev();}
    }

    action derive_end() { m.s_end = hdr.tcp.seq + m.leff; }
    table derive_t { actions = { derive_end; } size = 1; const default_action = derive_end(); }

    /* ============ forward classification (spec section 5) ============ */
    action fwd_prep_read(bit<32> negimg, bit<32> img) { m.y = m.q + m.leff; m.z = m.p + m.leff; m.pm = m.p + negimg; m.t = m.q + img; }
    action fwd_prep_ctl() { m.y = m.q + m.leff; m.z = m.p + m.leff; m.pm = m.p + 32w0xffffffc4; m.t = m.q + 32w60; }
    action fwd_prep_native() { m.y = m.q + m.leff; m.z = m.p + m.leff; m.pm = m.p - m.leff; m.t = m.q + m.leff; }
    table fwd_prep_t { key = { m.read_shape : ternary; m.ctl_shape : ternary; hdr.dl.len : ternary; }
        actions = { fwd_prep_read;fwd_prep_ctl; fwd_prep_native; } size = 4; const default_action = fwd_prep_native();
        const entries = { (1, _, 8w0x27): fwd_prep_read(32w0xffffff73, 32w141);(1, _, 8w0x11): fwd_prep_read(32w0xffffff62, 32w158);(_, 1, _): fwd_prep_ctl(); } }

    action out_commit()    { m.qx = m.q;  m.result = r_OUT_COMMIT;    m.pad = 1; }
    action out_translate() { m.qx = m.q;  m.result = r_OUT_TRANSLATE; m.changed = 1; }
    action out_zero()      { m.qx = m.pm; m.result = r_OUT_ZERO;      m.changed = 1; }
    action out_replay()    { m.qx = m.pm; m.result = r_OUT_REPLAY;    m.pad = 1; }
    action out_stale()     { m.qx = m.pm; m.result = r_OUT_STALE;     m.changed = 1; }
    action out_drop(bit<8> why) { m.result = why; md.drop_ctl = 3w1; }
    action out_reset_front_rd(bit<32> negn) { m.qx = m.q + negn; m.result = r_OUT_RESET_FRONT; m.changed = 1; }
    action out_zero_img_60() { m.qx = 32w0xffffffc4; m.result = r_OUT_ZERO; m.changed = 1; }
    action out_zero_img_61() { m.qx = 32w0xffffffc3; m.result = r_OUT_ZERO; m.changed = 1; }
    action out_zero_img_141() { m.qx = 32w0xffffff73; m.result = r_OUT_ZERO; m.changed = 1; }
    action out_zero_img_158() { m.qx = 32w0xffffff62; m.result = r_OUT_ZERO; m.changed = 1; }
    @stage(7)
    table classify_fwd {
        key = { m.front_ret : ternary; m.grant : ternary; m.q : ternary; m.leff : ternary;
                m.p : ternary; m.y : ternary; m.z : ternary;
                m.read_shape : ternary; m.ctl_shape : ternary; m.badh : ternary;
                m.rbad0 : ternary; m.rbad1 : ternary; m.rbadt : ternary; m.cbad0 : ternary; m.cbadt : ternary;
                hdr.tcp.flags : ternary; }
        actions = { out_commit; out_translate; out_zero; out_replay; out_stale; out_drop; out_reset_front_rd; out_zero_img_60;out_zero_img_61;out_zero_img_141;out_zero_img_158; } size = 28;
        const default_action = out_drop(r_OUT_DROP_OVERLAP);
        const entries = {(0, 0, _, _, _, _, _, _, _, _, _, _, _, _, _, _): out_translate();(0, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _): out_commit();(32w49, _, _, _, _, _, _, _, _, _, _, _, _, _, _, 8w0x04 &&& 8w0x04): out_reset_front_rd(32w0xffffffcf);(32w91, _, _, _, _, _, _, _, _, _, _, _, _, _, _, 8w0x04 &&& 8w0x04): out_reset_front_rd(32w0xffffffa5);(32w134, _, _, _, _, _, _, _, _, _, _, _, _, _, _, 8w0x04 &&& 8w0x04): out_reset_front_rd(32w0xffffff7a);(32w0 &&& 32w0x80000000, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _): out_drop(r_OUT_DROP_AHEAD);(_, _, 32w0 &&& 32w0x80000000, _, _, _, _, _, _, _, _, _, _, _, _, _): out_translate();(_, _, 32w0xffffffcf, 0, 32w0, _, _, _, _, _, _, _, _, _, _, _): out_zero_img_60();(_, _, 32w0xffffffc3, 0, 32w0, _, _, _, _, _, _, _, _, _, _, _): out_zero_img_61();(_, _, 32w0xffffffa5, 0, 32w0, _, _, _, _, _, _, _, _, _, _, _): out_zero_img_141();(_, _, 32w0xffffff7a, 0, 32w0, _, _, _, _, _, _, _, _, _, _, _): out_zero_img_158();(_, _, _, 0, _, _, _, _, _, _, _, _, _, _, _, _): out_zero();(_, _, _, _, 0, 0, _, 1, _, 0, 0, 0, 0, _, _, 8w0 &&& 8w0x01): out_replay();(_, _, _, _, 0, 1, _, 1, _, 0, 0, 0, 0, _, _, 8w1 &&& 8w0x01): out_replay();(_, _, _, _, 0, 0, _, _, 1, 0, _, _, _, 0, 0, 8w0 &&& 8w0x01): out_replay();(_, _, _, _, 0, 1, _, _, 1, 0, _, _, _, 0, 0, 8w1 &&& 8w0x01): out_replay();(_, _, _, _, 0, 32w0 &&& 32w0x80000000, _, 1, _, 0, 0, 0, 0, _, _, _): out_drop(r_OUT_DROP_MERGED);(_, _, _, _, 0, 32w0 &&& 32w0x80000000, _, _, 1, 0, _, _, _, 0, 0, _): out_drop(r_OUT_DROP_MERGED);(_, _, _, _, _, _, 0, _, _, _, _, _, _, _, _, _): out_stale();(_, _, _, _, _, _, 32w0x80000000 &&& 32w0x80000000, _, _, _, _, _, _, _, _, _): out_stale();}
    }

    Register<bit<32>, r_slot_t>(16, 0) img_wend;
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_wend) wend_arm = {
        void apply(inout bit<32> v) { v = m.qx; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_wend) wend_commit = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v; v = v + m.t; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_wend) wend_fwd = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = v; } };
    RegisterAction<bit<32>, r_slot_t, bit<32>>(img_wend) wend_rev = {
        void apply(inout bit<32> v, out bit<32> rv) { rv = m.qx - v; } };
    action do_wend_arm() { wend_arm.execute(m.idx); }
    action do_wend_commit() { m.r = wend_commit.execute(m.idx); }
    action do_wend_fwd() { m.r = wend_fwd.execute(m.idx); }
    action do_wend_rev() { m.r = wend_rev.execute(m.idx); }
    @stage(7)
    table img_wend_t {
        key = { m.first_synack : ternary; m.dir : exact; m.shape : ternary;
                m.grant : ternary; }
        actions = { do_wend_arm; do_wend_commit; do_wend_fwd; do_wend_rev; NoAction; } size = 8;
        const default_action = NoAction();
        const entries = {
            (1w1, 1, (bit<3>)r_SH_SYNACK_OK, _) : do_wend_arm();
            (_, 1, 3w4 &&& 3w7, 1) : do_wend_commit();
            (_, 1, 3w4 &&& 3w7, _) : do_wend_fwd();
            (_, 2, (bit<3>)r_SH_ACK, _) : do_wend_rev();
        }
    }
    action finish_forward_sequence() { hdr.tcp.seq = m.r + m.qx; }
    table finish_forward_sequence_t {
        actions = { finish_forward_sequence; } size = 1;
        const default_action = finish_forward_sequence();
    }

    /* ============ padder transform, gated by the mapper's pad decision ============ */
    /* The native tail r_is zeroed as it r_is invalidated: the r_TCP checksum list names it, and the result must
       not depend on whether the target skips invalid headers. (bf-p4c also inserts hidden
       egress_reset_invalidated_checksum_fields tables r_that do the same; this does not rely on them.) */
    action read_eligible(){m.changed=1;}
    table read_pad_t{actions={read_eligible;}size=1;const default_action=read_eligible();}
    action ctl_eligible(){hdr.cb0.tpctrl=hdr.cb0.tpctrl&8w0x7f;hdr.cb0.crc0=hdr.cb0.crc0^16w0x0c37;hdr.cd2.setValid();hdr.cd2.start=hdr.dl.start;hdr.cd2.len=8w23;hdr.cd2.ctrl=hdr.dl.ctrl;hdr.cd2.dst=hdr.dl.dst;hdr.cd2.src=hdr.dl.src;hdr.cd2.crc=hdr.dl.crc^16w0xa43c;hdr.cs2.setValid();hdr.cs2.off=hdr.ctn.off;hdr.cs2.status=hdr.ctn.status;hdr.cs2.index2=hdr.ctn.index2;hdr.cs2.code2=hdr.ctn.code2;hdr.cs2.count2=hdr.ctn.count2;hdr.cs2.on2=hdr.ctn.on2;hdr.cs2.off_hi=hdr.ctn.off2[31:8];hdr.cs2.crc=m.ctcrc2[7:0]++m.ctcrc2[15:8];hdr.cs3.setValid();hdr.cs3.off_lo=hdr.ctn.off2[7:0];hdr.cs3.status=hdr.cstatus.status;hdr.cs3.crc=m.ctcrc3[7:0]++m.ctcrc3[15:8];hdr.ctn.off=0;hdr.ctn.status=0;hdr.ctn.index2=0;hdr.ctn.code2=0;hdr.ctn.count2=0;hdr.ctn.on2=0;hdr.ctn.off2=0;hdr.ctn.crc1=0;hdr.cstatus.status=0;hdr.cstatus.crc=0;hdr.ctn.setInvalid();hdr.cstatus.setInvalid();hdr.dl.len=8w21;hdr.dl.crc=hdr.dl.crc^16w0x131a;hdr.ip.len=hdr.ip.len+16w11;m.len_delta=16w11;}
    table ctl_pad_t{actions={ctl_eligible;}size=1;const default_action=ctl_eligible();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_read_tail;
    action crc_read_tail(){m.rtcrc=hash_read_tail.get({hdr.p1012.d,hdr.p1321.d,hdr.p22.d});}
    table crc_read_tail_t{actions={crc_read_tail;}size=1;const default_action=crc_read_tail();}
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM,poly) hash_read_b;
    action crc_read_b(){m.rtcrc_b=hash_read_b.get({40w0x0a02000609,hdr.p69.d,56w0x0a02010a001600});}
    table crc_read_b_t{actions={crc_read_b;}size=1;const default_action=crc_read_b();}
    
    
    action tail_sequence_crc(bit<8> transport,bit<16> baseline){hdr.cs2.tpctrl=transport;m.ctcrc2=m.ctcrc2^baseline;}
    table crc_ctl_tail2_t{key={hdr.cb0.tpctrl:exact;}actions={tail_sequence_crc;NoAction;}size=64;const default_action=NoAction();const entries={8w192:tail_sequence_crc(8w129,16w69);8w193:tail_sequence_crc(8w130,16w54993);8w194:tail_sequence_crc(8w131,16w39773);8w195:tail_sequence_crc(8w132,16w13952);8w196:tail_sequence_crc(8w133,16w31500);8w197:tail_sequence_crc(8w134,16w44440);8w198:tail_sequence_crc(8w135,16w57364);8w199:tail_sequence_crc(8w136,16w47963);8w200:tail_sequence_crc(8w137,16w63191);8w201:tail_sequence_crc(8w138,16w8259);8w202:tail_sequence_crc(8w139,16w28111);8w203:tail_sequence_crc(8w140,16w49170);8w204:tail_sequence_crc(8w141,16w36254);8w205:tail_sequence_crc(8w142,16w23306);8w206:tail_sequence_crc(8w143,16w5766);8w207:tail_sequence_crc(8w144,16w60820);8w208:tail_sequence_crc(8w145,16w40984);8w209:tail_sequence_crc(8w146,16w30348);8w210:tail_sequence_crc(8w147,16w15104);8w211:tail_sequence_crc(8w148,16w38621);8w212:tail_sequence_crc(8w149,16w56145);8w213:tail_sequence_crc(8w150,16w3525);8w214:tail_sequence_crc(8w151,16w16457);8w215:tail_sequence_crc(8w152,16w6918);8w216:tail_sequence_crc(8w153,16w22154);8w217:tail_sequence_crc(8w154,16w32798);8w218:tail_sequence_crc(8w155,16w52626);8w219:tail_sequence_crc(8w156,16w24655);8w220:tail_sequence_crc(8w157,16w11715);8w221:tail_sequence_crc(8w158,16w64343);8w222:tail_sequence_crc(8w159,16w46811);8w223:tail_sequence_crc(8w160,16w16394);8w224:tail_sequence_crc(8w161,16w3462);8w225:tail_sequence_crc(8w162,16w56082);8w226:tail_sequence_crc(8w163,16w38558);8w227:tail_sequence_crc(8w164,16w15171);8w228:tail_sequence_crc(8w165,16w30415);8w229:tail_sequence_crc(8w166,16w41051);8w230:tail_sequence_crc(8w167,16w60887);8w231:tail_sequence_crc(8w168,16w46744);8w232:tail_sequence_crc(8w169,16w64276);8w233:tail_sequence_crc(8w170,16w11648);8w234:tail_sequence_crc(8w171,16w24588);8w235:tail_sequence_crc(8w172,16w52689);8w236:tail_sequence_crc(8w173,16w32861);8w237:tail_sequence_crc(8w174,16w22217);8w238:tail_sequence_crc(8w175,16w6981);8w239:tail_sequence_crc(8w176,16w57431);8w240:tail_sequence_crc(8w177,16w44507);8w241:tail_sequence_crc(8w178,16w31567);8w242:tail_sequence_crc(8w179,16w14019);8w243:tail_sequence_crc(8w180,16w39710);8w244:tail_sequence_crc(8w181,16w54930);8w245:tail_sequence_crc(8w182,16w6);8w246:tail_sequence_crc(8w183,16w19850);8w247:tail_sequence_crc(8w184,16w5829);8w248:tail_sequence_crc(8w185,16w23369);8w249:tail_sequence_crc(8w186,16w36317);8w250:tail_sequence_crc(8w187,16w49233);8w251:tail_sequence_crc(8w188,16w28044);8w252:tail_sequence_crc(8w189,16w8192);8w253:tail_sequence_crc(8w190,16w63124);8w254:tail_sequence_crc(8w191,16w47896);8w255:tail_sequence_crc(8w128,16w19913);}}
    
    


    /* ============ reverse: monotone inverse on both window edges (spec section 6) ============ */
    /* r + window: the window r_is widened through an identity hash (a 16-bit metadata operand in a 32-bit
       add drew "invalid container action within a Tofino ALU"). Keyed so the hash runs on a hit. */
    Hash<bit<32>>(HashAlgorithm_t.IDENTITY) widen_win;
    Hash<bit<32>>(HashAlgorithm_t.IDENTITY) widen_win_d;
    action reverse_gap() { m.s_end = m.q - m.p; }
    table reverse_gap_t { actions = { reverse_gap; } size = 1; const default_action = reverse_gap(); }
    action reverse_window_base() { m.wnd = m.s_end + widen_win.get({hdr.tcp.window,7w0}); }
    table reverse_window_base_t { actions = { reverse_window_base; } size = 1; const default_action = reverse_window_base(); }
    action rev_translate() { hdr.tcp.ack = m.q + m.r; m.result = r_OUT_REV_TRANSLATE; m.changed = 1; }
    action rev_withhold_zero() { hdr.tcp.ack = m.p; hdr.tcp.window = 0; m.result = r_OUT_REV_WITHHOLD; m.changed = 1; }
    action rev_withhold_open() { hdr.tcp.ack = m.p; m.wnd = m.wnd + m.r;
                                 m.r = m.r + widen_win_d.get({hdr.tcp.window,7w0}); m.wide = (bit<1>)(1);
                                 m.result = r_OUT_REV_WITHHOLD; m.changed = 1; }
    action rev_drop() { m.result = r_OUT_REV_DROP_STALE; md.drop_ctl = 3w1; }
    @stage(8)
    table classify_rev {
        key = { m.r : ternary; m.s_end[7:0] : ternary; }
        actions = { rev_translate; rev_withhold_zero; rev_withhold_open; rev_drop; }
        size = 19; const default_action = rev_drop();
        const entries = {

            (32w0 &&& 32w0x80000000, _) : rev_translate();
            (32w0xffffffc4 &&& 32w0xfffffffc, 8w49) : rev_withhold_open();
            (32w0xffffffc8 &&& 32w0xfffffff8, 8w49) : rev_withhold_open();
            (32w0xffffffd0 &&& 32w0xfffffff0, 8w49) : rev_withhold_open();
            (32w0xffffffe0 &&& 32w0xffffffe0, 8w49) : rev_withhold_open();

            (32w0xffffffc3 &&& 32w0xffffffff, 8w61) : rev_withhold_open();
            (32w0xffffffc4 &&& 32w0xfffffffc, 8w61) : rev_withhold_open();
            (32w0xffffffc8 &&& 32w0xfffffff8, 8w61) : rev_withhold_open();
            (32w0xffffffd0 &&& 32w0xfffffff0, 8w61) : rev_withhold_open();
            (32w0xffffffe0 &&& 32w0xffffffe0, 8w61) : rev_withhold_open();
            (32w0xffffff73 &&& 32w0xffffffff, 8w91) : rev_withhold_open();
            (32w0xffffff74 &&& 32w0xfffffffc, 8w91) : rev_withhold_open();
            (32w0xffffff78 &&& 32w0xfffffff8, 8w91) : rev_withhold_open();
            (32w0xffffff80 &&& 32w0xffffff80, 8w91) : rev_withhold_open();
            (32w0xffffff62 &&& 32w0xfffffffe, 8w134) : rev_withhold_open();
            (32w0xffffff64 &&& 32w0xfffffffc, 8w134) : rev_withhold_open();
            (32w0xffffff68 &&& 32w0xfffffff8, 8w134) : rev_withhold_open();
            (32w0xffffff70 &&& 32w0xfffffff0, 8w134) : rev_withhold_open();
            (32w0xffffff80 &&& 32w0xffffff80, 8w134) : rev_withhold_open();
               }
    }

    Hash<bit<16>>(HashAlgorithm_t.IDENTITY) narrow_win;
    action window_exact() { hdr.tcp.window = narrow_win.get({m.wnd[22:7]}); }
    action window_clamp() { hdr.tcp.window = 0xffff; }
    action window_zero() { hdr.tcp.window = 0; }
    @stage(9)
    table window_t {
        key = { m.wnd : ternary; m.r : ternary; }
        actions = { window_exact; window_clamp; window_zero; } size = 3; const default_action = window_clamp();
        const entries = { (_, 32w0x80000000 &&& 32w0x80000000) : window_zero(); (32w0 &&& 32w0xFF800000, _) : window_exact(); (_, _) : window_clamp(); }
    }

    /* settle_t drops untranslatable shapes on mapped connections (drop_odd) and gives m.result its value on
       paths no classifier writes. */
    action drop_odd() { m.result = r_OUT_DROP_ODD; md.drop_ctl = 3w1; }
    action native() { m.result = r_OUT_NATIVE; }
    action armed_map() { m.result = r_OUT_ARM_MAP; }
    action armed_nat() { m.result = r_OUT_ARM_NAT; }
    table settle_t {
        key = { m.dir : ternary; m.shape : ternary; m.mode : ternary; }
        actions = { drop_odd; native; armed_map; armed_nat; NoAction; } size = 8; const default_action = NoAction();
        const entries = {(0, _, _): NoAction();(1, (bit<3>)r_SH_SYNACK_OK, _): armed_map();(1, (bit<3>)r_SH_SYN, _): armed_nat();(_, (bit<3>)r_SH_ODD, 1): drop_odd();(_, _, 0): native();}
    }

    apply {
        /* DIAG MIRROR: always select mirror entry 1 (session 0 = no copy); the session is chosen at the end. */
        md.mirror_type = r_DIAG_MIRROR_TYPE;
        /* stage 0 */
        conn.apply();
        normalization_ack_t.apply(); prepare_open_t.apply();
        shape_t.apply();
        lifecycle_access.apply();
        leff_t.apply(); prep_t.apply();
        if (hdr.dl.isValid()) { in_dl_t.apply(); }
        if (hdr.rh.isValid()) { read_profile.apply(); }
        if (hdr.cb0.isValid()) { ctl_profile.apply(); in_cb0_t.apply(); in_ct_t.apply(); status_crc_t.apply(); crc_ctl_tail2_t.apply(); }
        if ((bit<8>)m.dir != 0 && hdr.tcp.isValid()) {
            if (m.life_bad == 0 || (hdr.prov.kind != 8w0xe7 && m.life_bad == 32w0x80000000)) {
                isn_access.apply();
                if (m.normalize == 1) { normalization_result.apply(); }
                mode_t.apply();
        /* mapper state */
        settle_t.apply();      // outcomes no classifier produces; the classifiers overwrite m.result later
        front_t.apply();
        derive_t.apply();
        /* padder native-CRC verdict */
        if (hdr.dl.crc != (m.in_dl[7:0] ++ m.in_dl[15:8])) { m.badh = 1; }
        if (hdr.cb0.crc0 != (m.in_cb0[7:0] ++ m.in_cb0[15:8])) { m.cbad0 = 1; }
        if (hdr.ctn.crc1 != (m.in_ct[7:0] ++ m.in_ct[15:8]) || hdr.cstatus.crc != (m.in_rt[7:0] ++ m.in_rt[15:8])) { m.cbadt = 1; }
        /* rbad0/rbad1/rbadt checks removed: c0/c1/c2 are only extracted by read_b0, which no state reaches */
        ina_img_t.apply();
        acct_t.apply();
        img_end_t.apply();
        img_start_t.apply();
        envelope_result.apply();
        if ((bit<8>)m.dir == 2 && (bit<8>)m.shape == r_SH_ACK && (bit<8>)m.mode == 1 && m.normalize == 1) {
            reverse_gap_t.apply(); reverse_window_base_t.apply();
        }
        if ((bit<8>)m.dir == 1 && ((bit<8>)m.shape == r_SH_ACK || (bit<8>)m.shape == r_SH_NOACK)) {
            fwd_prep_t.apply();
        }
        if (((bit<8>)m.dir == 1 && (bit<8>)m.shape == r_SH_SYNACK_OK) || (bit<8>)m.mode == 1) { img_wend_t.apply(); }
        if ((bit<8>)m.dir == 1 && ((bit<8>)m.shape == r_SH_ACK || (bit<8>)m.shape == r_SH_NOACK) && (bit<8>)m.mode == 1) {
            classify_fwd.apply();
            if ((bit<8>)m.shape == r_SH_ACK) { finish_forward_sequence_t.apply(); }
        }
        /* pad only on commit or replay; the verdict r_that allowed either also fixes the profile */
        if (m.pad == 1) {
            if (m.read_shape == 1) { read_pad_t.apply(); } else { ctl_pad_t.apply(); }
        } else if ((bit<8>)m.dir == 2 && (bit<8>)m.shape == r_SH_ACK && (bit<8>)m.mode == 1 && m.normalize == 1) {   // exclusive with padding
            classify_rev.apply();
            if ((bit<8>)m.wide == 1) { window_t.apply(); }
        }

            } else { drop_lifetime(); }
        } else {
            if ((bit<8>)m.ip_odd == 1) { odd_ip_t.apply(); drop_lifetime(); }
            else if ((bit<8>)m.dir != 0) { drop_lifetime(); }
            else if (hdr.prov.kind == 8w0xe0) { unbound_normalization(); }
            else { strip_provenance(); }
        }
        /* DIAG MIRROR: copy only a frame that leaves on the relay port. drop_ctl bit 0 drops the frame but does not
           stop an egress mirror copy (tofino1_base.p4: bit 2 does), so a dropped frame must not name a session. */
        if (eg.egress_port == r_DIAG_RELAY_PORT && md.drop_ctl[0:0] == 1w0) { m.diag_ses = r_DIAG_SESSION_TX; }
        else { m.diag_ses = r_DIAG_NO_SESSION; }
    }
}

control r_EgDeparser(packet_out pkt, inout r_headers_t hdr, in r_meta_t m, in egress_intrinsic_metadata_for_deparser_t md) {
    Checksum() ip_new; Checksum() tcp_plain; Checksum() tcp_read; Checksum() tcp_ctl;
    Mirror() r_diag_mirror;   /* DIAG MIRROR */
    apply {
        if (md.mirror_type == r_DIAG_MIRROR_TYPE) { r_diag_mirror.emit(m.diag_ses); }   /* DIAG MIRROR */
        if (m.pad == 1w1) {
            hdr.ip.checksum = ip_new.update({hdr.ip.version, hdr.ip.ihl, hdr.ip.tos, hdr.ip.len, hdr.ip.id, hdr.ip.flags,
                                             hdr.ip.frag, hdr.ip.ttl, hdr.ip.proto, hdr.ip.src, hdr.ip.dst});
        }
        /* Absent padding-header storage may share PHV with live metadata.
           Each checksum branch therefore includes padding headers under their validity conditions. */
        if (m.changed == 1w1) {
            /* Incremental: r_residual + current values of every word the parser r_subtracted. Field order keeps
               each header's byte parity equal to its parity in the segment; 8w0 pads the odd-length ones. */
            hdr.tcp.checksum = tcp_plain.update({hdr.tcp.seq, hdr.tcp.ack, hdr.tcp.window, m.len_delta, hdr.tso.a, hdr.tso.b, hdr.tso.c,
                hdr.dl.start, hdr.dl.len, hdr.dl.ctrl, hdr.dl.dst, hdr.dl.src, hdr.dl.crc,
                hdr.rh.tpctrl, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, hdr.robj.g_group, hdr.robj.g_var, hdr.robj.g_qual,
                hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d, hdr.c0.crc,
                hdr.p69.d, hdr.p1012.d, hdr.p1321.d, hdr.c1.crc,
                hdr.p22.d, hdr.c2.crc, 8w0,
                hdr.cb0.tpctrl, hdr.cb0.appctrl, hdr.cb0.func, hdr.cb0.iin, hdr.cb0.g_group, hdr.cb0.g_var, hdr.cb0.g_qual,
                hdr.cb0.g_count, hdr.cb0.index, hdr.cb0.crob_code, hdr.cb0.crob_count, hdr.cb0.on_hi, hdr.cb0.crc0,
                hdr.ctn.off, hdr.ctn.status, hdr.ctn.index2, hdr.ctn.code2, hdr.ctn.count2, hdr.ctn.on2, hdr.ctn.off2, hdr.ctn.crc1, hdr.cstatus.status, hdr.cstatus.crc, 8w0,
                m.r_residual});
        }
        if (hdr.cd2.isValid()) {
            /* Incremental: r_residual + current values of every word the parser r_subtracted. Field order keeps
               each header's byte parity equal to its parity in the segment; 8w0 pads the odd-length ones. */
            hdr.tcp.checksum = tcp_ctl.update({hdr.tcp.seq, hdr.tcp.ack, hdr.tcp.window, m.len_delta, hdr.tso.a, hdr.tso.b, hdr.tso.c,
                hdr.dl.start, hdr.dl.len, hdr.dl.ctrl, hdr.dl.dst, hdr.dl.src, hdr.dl.crc,
                hdr.rh.tpctrl, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, hdr.robj.g_group, hdr.robj.g_var, hdr.robj.g_qual,
                hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d, hdr.c0.crc,
                hdr.p69.d, hdr.p1012.d, hdr.p1321.d, hdr.c1.crc,
                hdr.p22.d, hdr.c2.crc, 8w0,
                hdr.cb0.tpctrl, hdr.cb0.appctrl, hdr.cb0.func, hdr.cb0.iin, hdr.cb0.g_group, hdr.cb0.g_var, hdr.cb0.g_qual,
                hdr.cb0.g_count, hdr.cb0.index, hdr.cb0.crob_code, hdr.cb0.crob_count, hdr.cb0.on_hi, hdr.cb0.crc0,
                hdr.cd2.start, hdr.cd2.len, hdr.cd2.ctrl, hdr.cd2.dst, hdr.cd2.src, hdr.cd2.crc,
                hdr.cs2.tpctrl, hdr.cs2.off, hdr.cs2.status, hdr.cs2.index2, hdr.cs2.code2, hdr.cs2.count2, hdr.cs2.on2, hdr.cs2.off_hi, hdr.cs2.crc,
                hdr.cs3.off_lo, hdr.cs3.status, hdr.cs3.crc,
                m.r_residual});
        }
        pkt.emit(hdr.prov); pkt.emit(hdr.eth); pkt.emit(hdr.ip); pkt.emit(hdr.tcp); pkt.emit(hdr.mss); pkt.emit(hdr.tso); pkt.emit(hdr.oa); pkt.emit(hdr.ob); pkt.emit(hdr.dl);
        pkt.emit(hdr.rh); pkt.emit(hdr.robj); pkt.emit(hdr.p03); pkt.emit(hdr.p45); pkt.emit(hdr.c0);
        pkt.emit(hdr.p69);
        pkt.emit(hdr.p1012); pkt.emit(hdr.p1321); pkt.emit(hdr.c1); pkt.emit(hdr.p22); pkt.emit(hdr.c2);
        pkt.emit(hdr.cb0); pkt.emit(hdr.ctn); pkt.emit(hdr.cstatus); pkt.emit(hdr.cd2); pkt.emit(hdr.cs2); pkt.emit(hdr.cd3); pkt.emit(hdr.cs3);
    }
}


/* Generated isolated T reconnect candidate. */
// timing_contract: response_ready_ack_d_no_j_v3
// Queue-resident ACK/response timing: originals use qid6/qid4 and blockers qid7/qid5.
// READ, SELECT and OPERATE share response-ready ACK commit and the configured D release gap.
#ifndef CASE4_READ_PORTS_P4
#define CASE4_READ_PORTS_P4
// Current T private-port constants; p0 binds N/E and p1 binds T/x_Egress.
// Device port = pipe * 128 + pipe-local port (9 bits).
// Internal recirculation uses dev68 in pipe0 and dev196 in pipe1.
// Front-panel dev48/180/182 require MAC loopback in the current installer.
// Endpoint ports are master dev9 and relay dev64.
// scripts/hardware/build_ports.py checks compiled constants and endpoint/loop roles.
// scripts/hardware/t_config.py creates queue, mirror and supported app0 generator operations.
// t_IngressParser distinguishes clone tags and supported timer headers by their content.
//
//
//
//
//
//
//
//
const PortId_t t_PKTGEN_RETURN = 9w196; // ingress pipe 1 local 68: mirror-clone recirculation into T ($mirror.cfg)
const PortId_t t_T_IN          = 9w180; /* dev180, pipe1 local52: N-to-T handoff; matches n_READ_HANDOFF_PORT. */
const PortId_t t_HELD_RETURN   = 9w182; /* dev182, pipe1 local54: front-panel return for held ACK/response traffic. */
const PortId_t t_FORWARD_PORT  = 9w9;   // egress pipe 0 local 9: master side (cross-pipe, egress pipe not bypassed)
const PortId_t t_RELAY_PORT    = 9w64; /* egress dev64, pipe0 local64: outstation relay. */
const PortId_t t_N_RETURN      = 9w68;  // peer pipe 0 local 68: N's own recirculation
const PortId_t t_MODEL_PKTGEN_IN = 9w0; // peer pipe 0 local 0: ingress_port the tofino-model gives generator packets
                                      // (a pipe-0 port, so it never reaches T's pipe 1 t_on silicon)
const bit<2> t_PKTGEN_PIPE = 1;         // pipe whose packet generator drives T (T's pipe)
#endif

// t_PKTGEN_RETURN is the mirror-clone return port at dev196.
// t_IngressDeparser emits the clone tag through mirror type1.
// md.clone_ses carries the selected session to clone_mirror.emit.
// scripts/hardware/t_config.py configures the session from compiled constants.
//
const bit<3> t_MIRROR_TYPE_CLONE = 1;
// t_IngressParser distinguishes clone tags from timer headers by content.
// Clone tags begin with the exact byte t_CLONE_MARKER.
// parse_timer admits the configured pipe/app0 timer format.
// Keep the full-byte clone marker match so the two formats remain distinct.
const bit<8> t_CLONE_MARKER = 0xE1;
const MirrorId_t t_CLONE_SESSION_ID = 10w7;
// Each pass selects the clone-mirror type; md.clone_ses controls the session.
// Request admission selects t_CLONE_SESSION_ID; other paths use t_NO_MIRROR_SESSION.
// The clone tag/session fields have dedicated PHV constraints above.
// Source assignments alone do not prove PHV isolation; preserve those constraints when changing placement.
// t_IngressDeparser passes md.clone_ses to clone_mirror.emit.
//
//
//
//
//
const MirrorId_t t_NO_MIRROR_SESSION = 10w0;

// Active ladder roles: ACK blocker, response blocker, held ACK and held response.
const bit<8> t_ROLE_ACK_BLK  = 11; const bit<8> t_ROLE_RESP_BLK = 12;
const bit<8> t_ROLE_ACK_HELD = 14; const bit<8> t_ROLE_RESP_HELD = 15;

// tev.kind/stage occupy wire bytes12-13 on the front-panel t_T_IN loop.
// Their combined value must remain an EtherType, not an 802.3 length or reserved control type.
// Current event kinds are declared below; RESET is13.
// N emit_reset and these T constants must agree on this private format.
// scripts/model/port_map.py defines the current reserved-type check.
const bit<8> t_KIND_REQUEST = 9; const bit<8> t_KIND_ACK = 10; const bit<8> t_KIND_RESPONSE = 11;
const bit<8> t_KIND_OPERATE = 12; const bit<8> t_KIND_RESET = 13; const bit<8> t_KIND_OPEN = 14;
// An identical OPERATE TCP retry: suppress while a response is retained; never clone or rearm.
const bit<8> t_KIND_OPERATE_DUP = 15;
const bit<8> t_KIND_REQUEST_DUP = 16;


header t_tev_t { bit<32> epoch; bit<32> wgen; bit<32> t0q; bit<8> kind; bit<8> stage; bit<16> reserved; }
header t_ladder_t { bit<8> role; bit<8> child; bit<16> generation; bit<32> budget; }
header t_clone_hdr_t { bit<32> tag; }
header t_ethernet_t { bit<48> dst; bit<48> src; bit<16> type; }
struct t_header_t { pktgen_timer_header_t timer; t_clone_hdr_t clone; t_tev_t tev; t_ladder_t ladder; t_ethernet_t eth; }

struct t_metadata_t {
    // 1 when the parser t_saw a generator token of the expected format (pipe t_PKTGEN_PIPE, app 0) t_on a
    // generator port; the only way into the token branch.
    bit<8> token_ok;
    // Per-pass action data: response release gap, blocker lap budget and timing enable.
    bit<32> gap; bit<32> budget_cap; bit<32> enabled;
    bit<32> now;
    // hdr.tev.epoch XOR the quarantined epoch, from quarantine_read: 0 exactly when this event's epoch is
    // quarantined. One value, so register actions that need the condition take one input (see t0_admit).
    // e_bad: 0 exactly when the event's epoch is the current epoch and not quarantined (epoch_check).
    bit<32> e_bad;  bit<32> packet_epoch; bit<32> cur_epoch_val; bit<32> epoch_delta; bit<32> quarantined_epoch; bit<8> event_kind;
    bit<32> cur_gen; 
    // lgen_diff: the ladder record's 16-bit generation XOR the live generation's low 16 bits; 0 = current.
    bit<16> lgen_diff;
    // Narrow: these only ever hold a 3-bit child mask or a 0/1 flag -- bit<32> would occupy 4x the
    // PHV this design doesn't have to spare (see TIMING_QUEUE_MIGRATION_STATUS.md's PHV finding).
    // seen<k>_diff: child_seen<k>_reg XOR cur_gen, 0 = response child k admitted in this generation.
    // dup_diff: the same for the child being admitted t_on this t_T_IN pass, before it is recorded.
    bit<32> seen0_diff; bit<32> seen1_diff; bit<32> seen2_diff; bit<32> dup_diff;
    bit<32> commit_diff;   // ack_commit_gen_reg XOR cur_gen: 0 = genuine ACK commit in this generation
    // 1 when this held ACK / held response may commit t_on this pass; the input to ack_done_try /
    // resp_done_try, computed before the register so the register needs no later dependent write.
    bit<8> ack_go; bit<8> resp_go;
    // Tofino's conditional-execution gateway cannot evaluate a live comparison between two fully
    // dynamic values (bf-p4c: "condition too complex ... one operand must be constant"), so every
    // now-vs-deadline check here is precomputed as delta = now - deadline, and its sign bit is matched
    // as a ternary key (32w0 &&& 32w0x80000000 = "deadline passed") in the go and verdict tables --
    // response_completion_access matches the signed response-gap delta after ACK commit.
    // now_m_X = now - X: delta = now - (t0 + X) is computed as now_m_X - t0, the same value mod 2^32
    // in one subtraction after the register read instead of two (stage budget).
    
    bit<32> ack_diff; bit<32> resp_diff;
    bit<32> now_m_gap; bit<32> gap_delta;
    bit<32> clone_tag;
    // Generator token's batch_id XOR each domain's live generation (low 16 bits); 0 = current.
    bit<16> rd_tok_diff;
    MirrorId_t clone_ses;
}

parser t_IngressParser(packet_in pkt, out t_header_t hdr, out t_metadata_t md,
                     out ingress_intrinsic_metadata_t ig_intr_md) {
    state start {
        md.event_kind = 0; md.packet_epoch = 0; pkt.extract(ig_intr_md); pkt.advance(PORT_METADATA_SIZE);
        md.token_ok = 0;
        transition select(ig_intr_md.ingress_port) {
            t_T_IN : parse_tev;
            t_HELD_RETURN : parse_ladder;
            t_PKTGEN_RETURN : clone_or_token;
            t_MODEL_PKTGEN_IN : parse_timer;   // the model's generator; t_on silicon tokens come in t_on t_PKTGEN_RETURN
            // Any other pipe-1 ingress (front-panel 164-191 included) parses nothing and is dropped explicitly
            // in the apply block: no frame from a front-panel port can enter the token or clone t_path.
            default : accept;
        }
    }
    state parse_tev {
        pkt.extract(hdr.tev); md.event_kind = hdr.tev.kind; md.packet_epoch = hdr.tev.epoch;
        md.epoch_delta = 1w1 ++ hdr.tev.epoch[30:0];
        transition select(hdr.tev.kind, hdr.tev.reserved) {
            (9, 0) : opaque_ethernet;
            (10, 0) : opaque_ethernet;
            (11, 0) : single_response_child;
            (12, 0) : opaque_ethernet;
            (t_KIND_OPERATE_DUP, 0) : opaque_ethernet;
            (t_KIND_REQUEST_DUP, 0) : opaque_ethernet;
            (t_KIND_RESET, 0) : opaque_ethernet;
            (t_KIND_OPEN, 0) : opaque_ethernet;
            default : reject;
        }
    }
    state single_response_child { transition select(hdr.tev.stage) { 0: opaque_ethernet; default: reject; } }
    state parse_ladder {
        pkt.extract(hdr.ladder); md.packet_epoch = hdr.ladder.budget;
        transition select(hdr.ladder.child) { 0: single_ladder_role; default: reject; }
    }
    state single_ladder_role {
        transition select(hdr.ladder.role) {
            11 : accept;
            12 : accept;
            14 : opaque_ethernet;
            15 : opaque_ethernet;
            default : reject;
        }
    }
    // Common E100 admission clones trigger the app0 blockers; their pristine originals
    // have already forwarded and the clone itself is dropped. Legacy command trigger tags reject.
    state clone_or_token {
        transition select(pkt.lookahead<bit<8>>()) {
            t_CLONE_MARKER : parse_clone;
            default : parse_timer;
        }
    }
    state parse_clone {
        pkt.extract(hdr.clone);
        transition select(hdr.clone.tag[31:16]) {
            16w0xE100 : parse_clone_tev;
            default : reject;
        }
    }
    state parse_clone_tev {
        pkt.extract(hdr.tev); md.event_kind = hdr.tev.kind; md.packet_epoch = hdr.tev.epoch;
        md.epoch_delta = 1w1 ++ hdr.tev.epoch[30:0];
        transition select(hdr.tev.kind, hdr.tev.reserved) {
            (9, 0) : opaque_ethernet;
            (12, 0) : opaque_ethernet;
            default : reject;
        }
    }
    state parse_timer {
        pkt.extract(hdr.timer);
        // Only the common response-timing app0 format is a token on T's pipe.
        transition select(hdr.timer.pipe_id, hdr.timer.app_id) {
            (t_PKTGEN_PIPE, 0) : token_format_ok;
            default : accept;
        }
    }
    state token_format_ok { md.token_ok = 1; transition accept; }
    state opaque_ethernet { pkt.extract(hdr.eth); transition accept; }
}

@pa_no_overlay("ingress", "ig_intr_md_for_dprsr.mirror_type")
@pa_no_overlay("ingress", "md.clone_ses")
control t_Ingress(inout t_header_t hdr, inout t_metadata_t md,
                in ingress_intrinsic_metadata_t ig_intr_md,
                in ingress_intrinsic_metadata_from_parser_t ig_prsr_md,
                inout ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md,
                inout ingress_intrinsic_metadata_for_tm_t ig_tm_md) {
    // ---- configuration (per-pass action data, not registers) --------------------------------
    action set_params(bit<32> gap, bit<32> budget, bit<32> enabled) {
        md.gap=gap; md.budget_cap=budget; md.enabled=enabled;
    }
    table params { actions={set_params;} default_action=set_params(19534,60000,1); size=1; }
    action clock_sample() { md.now = ig_prsr_md.global_tstamp[39:8] & 32w0xfffffffe; }
    table clock { actions = { clock_sample; } default_action = clock_sample(); size = 1; }

    // ---- epoch / generation state -------------------------------------------------------------
    // bit31 seals the current lifetime; bits30:0 retain its bounded epoch.
    Register<bit<32>, bit<1>>(1, 0) cur_epoch_reg;
    RegisterAction<bit<32>, bit<1>, bit<32>>(cur_epoch_reg) epoch_open = {
        void apply(inout bit<32> value, out bit<32> out_value) {
            // A live epoch is positive; a sealed epoch is negative as int32.
            // Exactly one comparison can accept each encoding. Bounds are
            // rejected by lifetime_access before this action can write.
            if (value < md.packet_epoch || (int<32>)value < (int<32>)md.epoch_delta) {
                value = md.packet_epoch; out_value = 0;
            } else { out_value = 1; }
        }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(cur_epoch_reg) epoch_read = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(cur_epoch_reg) epoch_match = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value ^ md.packet_epoch; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(cur_epoch_reg) epoch_close = {
        void apply(inout bit<32> value, out bit<32> out_value) {
            out_value = value ^ md.packet_epoch;
            if (value == md.packet_epoch && md.packet_epoch != 0) { value = value | 32w0x80000000; }
        }
    };
    action open_epoch() { md.epoch_delta = epoch_open.execute(0); }
    action read_epoch() { md.packet_epoch = epoch_read.execute(0); md.epoch_delta = 0; }
    action match_epoch() { md.epoch_delta = epoch_match.execute(0); }
    action close_epoch() { md.epoch_delta = epoch_close.execute(0); }
    action reject_open() { md.epoch_delta = 1; }
    table lifetime_access {
        key = { ig_intr_md.ingress_port : ternary; md.event_kind : ternary;
                hdr.ladder.role : ternary; md.packet_epoch : ternary; }
        actions = { open_epoch; read_epoch; match_epoch; close_epoch; reject_open; }
        const entries = {
            (t_T_IN, t_KIND_OPEN, _, 0) : reject_open();
            (t_T_IN, t_KIND_OPEN, _, 32w0x7fffffff) : reject_open();
            (t_T_IN, t_KIND_OPEN, _, 32w0x80000000 &&& 32w0x80000000) : reject_open();
            (t_T_IN, t_KIND_OPEN, _, _) : open_epoch();
            (t_T_IN, t_KIND_RESET, _, _) : close_epoch();
            (t_T_IN, _, _, _) : match_epoch();
            (t_HELD_RETURN, _, t_ROLE_ACK_HELD, _) : match_epoch();
            (t_HELD_RETURN, _, t_ROLE_RESP_HELD, _) : match_epoch();
        }
        default_action = read_epoch(); size = 8;
    }
    Register<bit<32>, bit<1>>(1, 0) gen_alloc_reg;
    RegisterAction<bit<32>, bit<1>, bit<32>>(gen_alloc_reg) gen_peek = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(gen_alloc_reg) gen_bump = {
        void apply(inout bit<32> value, out bit<32> out_value) { if (value < 32w0xffff) { value = value + 1; } out_value = value; }
    };
    // An enabled REQUEST pass: opens a new generation unless the request's epoch is quarantined.
    RegisterAction<bit<32>, bit<1>, bit<32>>(gen_alloc_reg) gen_admit = {
        void apply(inout bit<32> value, out bit<32> out_value) {
            if (value < 32w0xfffe) { value = value + 1; }
            else { value = 32w0xffff; }
            out_value = value;
        }
    };
    // Request admission allocates a generation; this contract has no request-age t0 register.
    // ACK readiness uses current epoch/generation and admitted child0 state.
    // Response release is anchored at ACK commit through commit_at_gap.
//
    
    
    // Current generation access is through gen_access below.
    // Whole-response admission is recorded by child_seen0_reg; ACK commit supplies the response-delay anchor.
//
//
    
    // Tofino requires every table (and every bare action call becomes one) to address at most one
    // indirect extern, so reads/writes spanning multiple registers are always split into separate
    // single-register actions called as separate statements, never bundled into one action body.
    action peek_gen() { md.cur_gen = gen_peek.execute(0); }
    action admit_gen() { md.cur_gen = gen_admit.execute(0); }
    action reset_bump_gen() { md.cur_gen = gen_bump.execute(0); }
    // gen_access selects one current-generation action after epoch classification.
    // live_gen/bad_gen/duplicate_close_gen read; live_admit_gen allocates; live_reset_gen advances.
    // Disabled REQUEST/OPERATE rows read rather than allocating.
    // The explicit rows below define current OPEN/RESET and epoch behavior.
//
//
//
    action live_gen() { md.cur_gen = gen_peek.execute(0); md.e_bad = 0; }
    action bad_gen() { md.cur_gen = gen_peek.execute(0); md.e_bad = 1; }
    action duplicate_close_gen() { md.cur_gen = gen_peek.execute(0); md.e_bad = 2; }
    action live_admit_gen() { md.cur_gen = gen_admit.execute(0); md.e_bad = 0; }
    action live_reset_gen() { md.cur_gen = gen_bump.execute(0); md.e_bad = 0; }
    table gen_access {
        key = { ig_intr_md.ingress_port : ternary; md.event_kind : ternary;
                md.enabled : ternary; md.packet_epoch : ternary; md.epoch_delta : ternary; }
        actions = { live_gen; bad_gen; duplicate_close_gen; live_admit_gen; live_reset_gen; }
        const entries = {
            (_, _, _, 0, _) : bad_gen();
            (_, _, _, 32w0x7fffffff, _) : bad_gen();
            (_, _, _, 32w0x80000000 &&& 32w0x80000000, _) : bad_gen();
            (t_T_IN, t_KIND_OPEN, _, _, 0) : live_reset_gen();
            (t_T_IN, t_KIND_RESET, _, _, 32w0x80000000) : duplicate_close_gen();
            (t_T_IN, t_KIND_RESET, _, _, 0) : live_reset_gen();
            (t_T_IN, t_KIND_REQUEST, 0, _, 0) : live_gen();
            (t_T_IN, t_KIND_REQUEST, _, _, 0) : live_admit_gen();
            (t_T_IN, t_KIND_OPERATE, 0, _, 0) : live_gen();
            (t_T_IN, t_KIND_OPERATE, _, _, 0) : live_admit_gen();
            (_, _, _, _, 0) : live_gen();
        }
        default_action = bad_gen(); size = 11;
    }
    
    
    
    // ack_done_reg stores the generation for which ACK completion committed.
    // ack_done_read/try compare by XOR; ack_done_try writes only when ack_go is1.
//
    Register<bit<32>, bit<1>>(1,0) ack_done_reg;
    RegisterAction<bit<32>,bit<1>,bit<32>>(ack_done_reg) ack_done_read={
        void apply(inout bit<32> v,out bit<32> r){r=v^md.cur_gen;}
    };
    RegisterAction<bit<32>,bit<1>,bit<32>>(ack_done_reg) ack_done_try={
        void apply(inout bit<32> v,out bit<32> r){r=v^md.cur_gen;if(md.ack_go==1){v=md.cur_gen;}}
    };
    action read_ack_completion(){md.ack_diff=ack_done_read.execute(0);}
    action try_ack_completion(){md.ack_diff=ack_done_try.execute(0);}
    table ack_completion_access {
        key={ig_intr_md.ingress_port:ternary;hdr.ladder.role:ternary;}
        actions={read_ack_completion;try_ack_completion;}
        const entries={(t_HELD_RETURN,t_ROLE_ACK_HELD):try_ack_completion();}
        default_action=read_ack_completion();size=1;
    }
    // ACK commit uses ack_commit_at_reg for md.now and ack_commit_gen_reg for md.cur_gen.
    // Their access tables guard writes using held-ACK eligibility.
    // commit_diff compares the recorded commit generation with cur_gen.
    // commit_at_gap computes now_m_gap minus the stored ACK-commit timestamp.
    // response_completion_access combines that signed delta with the current-generation association.
    // A generation change invalidates an older commit association without clearing the timestamp.
//
//
//
    Register<bit<32>, bit<1>>(1, 0) ack_commit_at_reg;
    // Returns the response gap delta directly: (now - gap) - a_commit = now - (a_commit + gap).
    RegisterAction<bit<32>, bit<1>, bit<32>>(ack_commit_at_reg) commit_at_gap = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = md.now_m_gap - value; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(ack_commit_at_reg) commit_at_write = {
        void apply(inout bit<32> value, out bit<32> out_value) { value = md.now; out_value = value; }
    };
    // Initial value 0xffffffff, not 0: generation 0 is the live READ generation before the first request,
    // so a register holding 0 would read as "a genuine commit in generation 0" (commit_diff == 0). Any
    // control-t_plane or hardware clear of this register must restore 0xffffffff, not 0.
    Register<bit<32>, bit<1>>(1, 0xffffffff) ack_commit_gen_reg;
    // value XOR cur_gen: 0 exactly when a genuine ACK commit happened in the current generation.
    RegisterAction<bit<32>, bit<1>, bit<32>>(ack_commit_gen_reg) commit_gen_read = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value ^ md.cur_gen; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(ack_commit_gen_reg) commit_gen_write = {
        void apply(inout bit<32> value, out bit<32> out_value) { value = md.cur_gen; out_value = value; }
    };

    // ---- response domain --------------------------------------------------------------------
    Register<bit<32>, bit<1>>(1, 0) resp_done_reg;
    RegisterAction<bit<32>, bit<1>, bit<32>>(resp_done_reg) resp_done_read = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value ^ md.cur_gen; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(resp_done_reg) resp_done_commit = {
        void apply(inout bit<32> value, out bit<32> out_value) {
            out_value = value ^ md.cur_gen;
            value = md.cur_gen;
        }
    };
    // No resp_deadline register (removed 2026-10-09, route_ab_01/b28). It was armed (once per RESET, only
    // while 0) and cleared, but no decision ever read it: response release is decided from
    // ack_commit_at_reg (commit_at_gap) and the configured gap. Its value, a_commit + gap, is derivable
    // from ack_commit_at_reg + gap; the tests now check ack_commit_at_reg directly.
    // Response children (route_ab_01/b40): one single-word register per child k (tev.stage 0, 1, 2+),
    // holding the READ generation in which child k was last admitted; initial 0xffffffff so that no
    // child reads as seen in generation 0 (restore that value, not 0, t_on any clear). Replaces a {gen,
    // mask} pair whose `(value.mask & BIT) != 0` condition bfas rejects ("expecting register slice").
    Register<bit<32>, bit<1>>(1, 0xffffffff) child_seen0_reg;
    RegisterAction<bit<32>, bit<1>, bit<32>>(child_seen0_reg) child_try0 = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value ^ md.cur_gen; value = md.cur_gen; }
    };
    RegisterAction<bit<32>, bit<1>, bit<32>>(child_seen0_reg) child_read0 = {
        void apply(inout bit<32> value, out bit<32> out_value) { out_value = value ^ md.cur_gen; }
    };






    action read_seen0() { md.seen0_diff = child_read0.execute(0); }



    action try_seen0() { md.seen0_diff = child_try0.execute(0); }
    table child_seen0_access {
        key = { ig_intr_md.ingress_port : ternary; md.event_kind : ternary;
                hdr.tev.stage : ternary; md.e_bad : ternary; md.enabled : ternary; }
        actions = { read_seen0; try_seen0; NoAction; }
        const entries = {
            (t_HELD_RETURN, _, _, _, _) : read_seen0();
            (t_T_IN,t_KIND_REQUEST_DUP,_,0,_):read_seen0();
            (t_T_IN,t_KIND_OPERATE_DUP,_,0,_):read_seen0();
            (t_T_IN, t_KIND_RESPONSE, 0, _, 0) : NoAction();
            (t_T_IN, t_KIND_RESPONSE, 0, 0, _) : try_seen0();
        }
        default_action = NoAction(); size = 5;
    }




    // ---- request admission ---------------------------------------------------------------------
    // new_gen is gen_access's output from an earlier stage, so masking it here is an ordinary ALU op
    // (masking a stateful ALU's output in the action that receives it was IMPOSSIBLE_ALIGNMENT, b7).
    action admit_request() {
        
        ig_tm_md.ucast_egress_port = t_RELAY_PORT;
        ig_dprsr_md.mirror_type = 1;
        md.clone_ses = t_CLONE_SESSION_ID;
        md.clone_tag = 16w0xE100 ++ md.cur_gen[15:0];   // t_CLONE_MARKER in the top byte
    }
    action bypass_request() {
        
        ig_tm_md.ucast_egress_port = t_RELAY_PORT;
    }
    // ---- hold admission (ACK / response) --------------------------------------------------------
    action hold_ack() {
        hdr.tev.setInvalid();
        hdr.ladder.setValid();
        hdr.ladder.role = t_ROLE_ACK_HELD; hdr.ladder.child = 0;
        hdr.ladder.generation = (bit<16>)md.cur_gen; hdr.ladder.budget = md.packet_epoch;
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 6;
    }
    action admit_response() {
        hdr.ladder.setValid();
        hdr.ladder.role = t_ROLE_RESP_HELD; hdr.ladder.child = (bit<8>)hdr.tev.stage;
        hdr.ladder.generation = (bit<16>)md.cur_gen; hdr.ladder.budget = md.packet_epoch;
        hdr.tev.setInvalid();
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 4;
    }
    action drop_duplicate_response() { ig_dprsr_md.drop_ctl = 1; }
    action passthrough_tev_forward() {  ig_tm_md.ucast_egress_port = t_FORWARD_PORT; }
    action drop_clone() { ig_dprsr_md.drop_ctl = 1; }
    action passthrough_tev_relay() {  ig_tm_md.ucast_egress_port = t_RELAY_PORT; }

    // ---- generator token -> blocker (ports 0, generator app) -----------------------------------
    action seed_ack_blocker() {
        hdr.ladder.setValid();
        hdr.ladder.role = t_ROLE_ACK_BLK; hdr.ladder.child = 0;
        hdr.ladder.generation = hdr.timer.batch_id; hdr.ladder.budget = md.budget_cap;
        hdr.timer.setInvalid();   // after reading batch_id
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 7;
    }
    action seed_resp_blocker() {
        hdr.ladder.setValid();
        hdr.ladder.role = t_ROLE_RESP_BLK; hdr.ladder.child = 0;
        hdr.ladder.generation = hdr.timer.batch_id; hdr.ladder.budget = md.budget_cap;
        hdr.timer.setInvalid();   // after reading batch_id
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 5;
    }
    // Token staleness without a gateway comparing two runtime fields: `token_gen != (gen & 0xffff)` in a
    // gateway (token_gen is the zero-extended 16-bit batch_id) was what turned this program's placement
    // errors into bf-p4c's bare "Internal compiler error" (route_ab_01/b19_port0_bisect: removing both such
    // comparisons, p3, gives readable errors; removing either alone, p1/p2, still crashes). The XOR is
    // zero exactly when batch_id equals the generation's low 16 bits, so `tok_diff != 0` is the same test.
    action token_diffs() {
        md.rd_tok_diff = hdr.timer.batch_id ^ (bit<16>)md.cur_gen;
    }
    action drop_timer_stale_read() { hdr.timer.setInvalid(); ig_dprsr_md.drop_ctl = 1; }

    // ---- ladder dispatch: blockers re-circulate or die ------------------------------------------
    action keep_blocking(PortId_t port, bit<5> qid) {
        hdr.ladder.budget = hdr.ladder.budget - 1;
        ig_tm_md.ucast_egress_port = port; ig_tm_md.qid = qid;
    }
    action stop_blocking() { ig_dprsr_md.drop_ctl = 1; }
    action stop_blocking_stale() { ig_dprsr_md.drop_ctl = 1; }
    action stop_blocking_tmo() { ig_dprsr_md.drop_ctl = 1; }
    action stop_blocking_off() { ig_dprsr_md.drop_ctl = 1; }

    // ---- response deadline: delta followed by a ternary sign-bit match ------------------------
    // held_offsets computes now-gap; commit_at_gap subtracts the stored ACK-commit timestamp.
    // response_completion_access matches the signed delta with a ternary key.
    // This avoids a direct dynamic now>=deadline gateway comparison and an explicit bit31 PHV slice.
//
//
//
//
    action held_offsets() { md.now_m_gap=md.now-md.gap; }
    
    action read_gap_delta() { md.gap_delta = commit_at_gap.execute(0); }
    action read_lgen_diff() { md.lgen_diff = hdr.ladder.generation ^ (bit<16>)md.cur_gen; }
    // ACK completion is updated by ack_done_try through ack_completion_access.
    // ACK-commit timestamp/generation writes use separate single-register access actions.
    // ack_go_check requires current epoch/generation, held-ACK role and admitted child0.
    // Its default sets ack_go to0; the current contract has no request-age/readiness fallback.
//
//
//
//
//
//
//
//
    action set_ack_go(bit<8> go){md.ack_go=go;}
    table ack_go_check { key = { md.e_bad : ternary; ig_intr_md.ingress_port : ternary; hdr.ladder.role : ternary; md.lgen_diff : ternary; md.seen0_diff : ternary; }
        actions = { set_ack_go; }
        const entries = {
            (0, t_HELD_RETURN, t_ROLE_ACK_HELD, 0, 0) : set_ack_go(1);
        } default_action = set_ack_go(0); size = 1;
    }
    action export_held() {
        hdr.tev.setValid(); hdr.tev.epoch = hdr.ladder.budget;
        hdr.tev.wgen = 0; hdr.tev.t0q = 0; hdr.tev.kind = 8w0xe3;
        hdr.tev.stage = 0; hdr.tev.reserved = 0; hdr.ladder.setInvalid();
    }
    action release_ack() {
        export_held();
        ig_tm_md.ucast_egress_port = t_FORWARD_PORT;
    }
    action mark_ack_commit_at() { commit_at_write.execute(0); }
    action mark_ack_commit_gen() { commit_gen_write.execute(0); }
    action read_commit_gen() { md.commit_diff = commit_gen_read.execute(0); }
    table commit_at_access { key = { ig_intr_md.ingress_port : ternary; hdr.ladder.role : ternary; md.ack_diff : ternary; md.ack_go : ternary; }
        actions = { mark_ack_commit_at; read_gap_delta; NoAction; }
        const entries = {
            (t_HELD_RETURN, t_ROLE_ACK_HELD, 0, _) : NoAction();
            (t_HELD_RETURN, t_ROLE_ACK_HELD, _, 1) : mark_ack_commit_at();
            (t_HELD_RETURN, t_ROLE_RESP_HELD, _, _) : read_gap_delta();
            (t_HELD_RETURN, t_ROLE_RESP_BLK, _, _) : read_gap_delta();
        } default_action = NoAction(); size = 4;
    }
    table commit_generation_access { key = { ig_intr_md.ingress_port : ternary; hdr.ladder.role : ternary; md.ack_diff : ternary; md.ack_go : ternary; }
        actions = { mark_ack_commit_gen; read_commit_gen; NoAction; }
        const entries = {
            (t_HELD_RETURN, t_ROLE_ACK_HELD, 0, _) : NoAction();
            (t_HELD_RETURN, t_ROLE_ACK_HELD, _, 1) : mark_ack_commit_gen();
            (t_HELD_RETURN, t_ROLE_RESP_HELD, _, _) : read_commit_gen();
            (t_HELD_RETURN, t_ROLE_RESP_BLK, _, _) : read_commit_gen();
        } default_action = NoAction(); size = 4;
    }
    action rewait_ack() {
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 6;
    }
    action flush_ack_stale() { ig_dprsr_md.drop_ctl = 1; }
    action flush_ack_off(){rewait_ack();}

    // response_completion_access checks current epoch/generation, signed D delta and ACK-commit association.
    // The matching held-response row commits resp_done_reg; the response-blocker row reads completion state.
    // Nonmatching rows wait; there is no request-age/readiness fallback.
//
    action response_done_wait() { md.resp_go = 0; md.resp_diff = resp_done_read.execute(0); }
    action response_done_blocker_ready() { md.resp_go = 1; md.resp_diff = resp_done_read.execute(0); }
    action response_done_commit() { md.resp_go = 1; md.resp_diff = resp_done_commit.execute(0); }
    // One global access point keeps T_IN reads and held commits in one
    // physical stateful bank; separate call sites may be replicated by bf-p4c.
    table response_completion_access { key = { ig_intr_md.ingress_port : ternary; md.event_kind : ternary; md.e_bad : ternary; md.lgen_diff : ternary; md.gap_delta : ternary; md.commit_diff : ternary; hdr.ladder.role : ternary; }
        actions = { response_done_wait; response_done_blocker_ready; response_done_commit; NoAction; }
        const entries = {
            (t_T_IN, t_KIND_RESPONSE, 0, _, _, _, _) : response_done_wait();
            (t_T_IN, t_KIND_REQUEST_DUP, 0, _, _, _, _) : response_done_wait();
            (t_T_IN, t_KIND_OPERATE_DUP, 0, _, _, _, _) : response_done_wait();
            (t_HELD_RETURN, _, 0, 0, 32w0 &&& 32w0x80000000, 0, t_ROLE_RESP_HELD) : response_done_commit();
            (t_HELD_RETURN, _, _, _, _, _, t_ROLE_RESP_HELD) : response_done_wait();
            (t_HELD_RETURN, _, 0, 0, 32w0 &&& 32w0x80000000, 0, t_ROLE_RESP_BLK) : response_done_blocker_ready();
            (t_HELD_RETURN, _, _, _, _, _, t_ROLE_RESP_BLK) : response_done_wait();
        } default_action = NoAction(); size = 7;
    }
    // Release only; resp_done_reg was already committed by resp_done_try t_on this same pass.
    action release_response() {
        export_held();
        ig_tm_md.ucast_egress_port = t_FORWARD_PORT;
    }
    action rewait_response() {
        ig_tm_md.ucast_egress_port = t_HELD_RETURN; ig_tm_md.qid = 4;
    }
    action flush_response_stale() { ig_dprsr_md.drop_ctl = 1; }
    action flush_response_off(){rewait_response();}

    action release_ack_commit() { release_ack(); }
    action drop_request_duplicate(){ig_dprsr_md.drop_ctl=1;}
    action release_response_counted() { release_response(); }
    action drop_tin() { ig_dprsr_md.drop_ctl = 1; }
    action drop_old_epoch() { ig_dprsr_md.drop_ctl = 1; }
    // The duplicate leaves as an OPERATE passthrough: E accepts only provenance kinds it knows.
    action passthrough_operate_dup(){hdr.tev.kind=t_KIND_OPERATE;ig_tm_md.ucast_egress_port=t_RELAY_PORT;}
    action passthrough_request_dup(){hdr.tev.kind=t_KIND_REQUEST;ig_tm_md.ucast_egress_port=t_RELAY_PORT;}
    action drop_exhausted() { ig_dprsr_md.drop_ctl = 1; }
    action unmatched() { ig_dprsr_md.drop_ctl = 1; }
    // Not T's traffic (front-panel ingress, or a generator-port frame of the wrong format): dropped explicitly,
    // nothing counted, no register touched (every prologue default above only reads).
    action drop_foreign() { ig_dprsr_md.drop_ctl = 1; }

    // ---- verdict tables (route_ab_01/b35) ---------------------------------------------------------
    // Each port's terminal decision is one const-entries ternary table instead of a chain of gateways and
    // one-action tables: bf-p4c ran out of logical tables per stage ("too many tables total", b30..b33).
    // Rows are in the original if/else priority order and the first matching row wins. A row matching
    // 0 t_on a key makes "_" t_on that key mean "!= 0" in every later row of the same role/kind. Keys:
    // lgen_diff == 0 (ladder generation is current), 32w0 &&& 32w0x80000000 t_on a delta (that deadline has passed), commit_diff == 0
    // (genuine a_commit in this generation), seen<k>_diff == 0 (response child k seen in this generation;
    // one row per child), budget == 0 (blocker budget exhausted).
    table tin_verdict { key = { md.event_kind : ternary; md.enabled : ternary; md.e_bad : ternary; md.ack_diff : ternary; md.resp_diff : ternary; md.dup_diff : ternary; md.seen0_diff : ternary; hdr.tev.stage : ternary; md.cur_gen : ternary; }
        actions = { passthrough_tev_relay; passthrough_tev_forward; drop_tin; admit_request; hold_ack; drop_duplicate_response; admit_response; drop_old_epoch; drop_exhausted; passthrough_request_dup; passthrough_operate_dup; drop_request_duplicate; }
        const entries = {
            (t_KIND_OPEN, _, 0, _, _, _, _, _, _) : passthrough_tev_relay();
            (t_KIND_RESET, _, 32w2, _, _, _, _, 1, _) : passthrough_tev_relay();
            (t_KIND_RESET, _, 32w2, _, _, _, _, 2, _) : passthrough_tev_forward();
            (t_KIND_RESET, _, 0, _, _, _, _, 1, _) : passthrough_tev_relay();
            (t_KIND_RESET, _, 0, _, _, _, _, 2, _) : passthrough_tev_forward();
            (t_KIND_RESET, _, 0, _, _, _, _, _, _) : drop_tin();
            (t_KIND_REQUEST, _, 0, _, _, _, _, _, 32w0xffff) : drop_exhausted();
            (t_KIND_OPERATE, _, 0, _, _, _, _, _, 32w0xffff) : drop_exhausted();
            (t_KIND_REQUEST_DUP, 0, 0, _, _, _, _, _, _) : passthrough_request_dup();
            (t_KIND_OPERATE_DUP, 0, 0, _, _, _, _, _, _) : passthrough_operate_dup();
            (t_KIND_REQUEST_DUP, _, 0, _, 0, _, _, _, _) : passthrough_request_dup();
            (t_KIND_REQUEST_DUP, _, 0, _, _, _, 0, _, _) : drop_request_duplicate();
            (t_KIND_REQUEST_DUP, _, 0, _, _, _, _, _, _) : passthrough_request_dup();
            (t_KIND_OPERATE_DUP, _, 0, _, 0, _, _, _, _) : passthrough_operate_dup();
            (t_KIND_OPERATE_DUP, _, 0, _, _, _, 0, _, _) : drop_request_duplicate();
            (t_KIND_OPERATE_DUP, _, 0, _, _, _, _, _, _) : passthrough_operate_dup();
            (t_KIND_REQUEST, 0, 0, _, _, _, _, _, _) : passthrough_tev_relay();
            (t_KIND_OPERATE, 0, 0, _, _, _, _, _, _) : passthrough_tev_relay();
            (_, 0, 0, _, _, _, _, _, _) : passthrough_tev_forward();
            (t_KIND_REQUEST, _, 0, _, _, _, _, _, _) : admit_request();
            (t_KIND_ACK, _, 0, 0, _, _, _, _, _) : drop_tin();
            (t_KIND_ACK, _, 0, _, _, _, _, _, _) : hold_ack();
            (t_KIND_RESPONSE, _, 0, _, 0, _, _, _, _) : passthrough_tev_forward();
            (t_KIND_RESPONSE, _, 0, _, _, 0, _, _, _) : drop_duplicate_response();
            (t_KIND_RESPONSE, _, 0, _, _, _, _, _, _) : admit_response();
            (t_KIND_OPERATE, _, 0, _, _, _, _, _, _) : admit_request();
        } default_action = drop_old_epoch(); size = 26;
    }
    table token_verdict {
        key = { md.e_bad : ternary; hdr.timer.app_id : ternary; hdr.timer.packet_id : ternary;
                md.rd_tok_diff : ternary; hdr.timer.batch_id : ternary; }
        actions = { seed_ack_blocker; seed_resp_blocker; drop_timer_stale_read; }
        const entries = {
            (_, _, _, _, 16w0xffff) : drop_timer_stale_read();
            (0, 0, 16w0 &&& 16w1, 0, _) : seed_ack_blocker();
            (0, 0, 16w0 &&& 16w1, _, _) : drop_timer_stale_read();
            (0, 0, _, 0, _) : seed_resp_blocker();
        }
        default_action = drop_timer_stale_read(); size = 4;
    }
    table held_verdict { key = { md.e_bad : ternary; hdr.ladder.role : ternary; md.lgen_diff : ternary; md.ack_diff : ternary; md.ack_go : ternary; md.resp_go : ternary; md.resp_diff : ternary; hdr.ladder.budget : ternary; md.seen0_diff : ternary; }
        actions = { stop_blocking; stop_blocking_tmo; stop_blocking_stale; keep_blocking; drop_tin; release_ack_commit; rewait_ack; flush_ack_stale; drop_duplicate_response; release_response_counted; rewait_response; flush_response_stale; drop_old_epoch; }
        const entries = {
            (0, t_ROLE_ACK_BLK, 0, 0, _, _, _, _, _) : stop_blocking();
            (0, t_ROLE_ACK_BLK, 0, _, _, _, _, _, 0) : stop_blocking();
            (0, t_ROLE_ACK_BLK, 0, _, _, _, _, 0, _) : stop_blocking_tmo();
            (0, t_ROLE_ACK_BLK, 0, _, _, _, _, _, _) : keep_blocking(t_HELD_RETURN,7);
            (0, t_ROLE_ACK_BLK, _, _, _, _, _, _, _) : stop_blocking_stale();
            (0, t_ROLE_RESP_BLK, 0, _, _, 1, _, _, _) : stop_blocking();
            (0, t_ROLE_RESP_BLK, 0, _, _, _, 0, _, _) : stop_blocking();
            (0, t_ROLE_RESP_BLK, 0, _, _, _, _, 0, _) : stop_blocking_tmo();
            (0, t_ROLE_RESP_BLK, 0, _, _, _, _, _, _) : keep_blocking(t_HELD_RETURN,5);
            (0, t_ROLE_RESP_BLK, _, _, _, _, _, _, _) : stop_blocking_stale();
            (0, t_ROLE_ACK_HELD, 0, 0, _, _, _, _, _) : drop_tin();
            (0, t_ROLE_ACK_HELD, 0, _, 1, _, _, _, _) : release_ack_commit();
            (0, t_ROLE_ACK_HELD, 0, _, _, _, _, _, _) : rewait_ack();
            (0, t_ROLE_ACK_HELD, _, _, _, _, _, _, _) : flush_ack_stale();
            (0, t_ROLE_RESP_HELD, 0, _, _, _, 0, _, _) : drop_duplicate_response();
            (0, t_ROLE_RESP_HELD, 0, _, _, 1, _, _, _) : release_response_counted();
            (0, t_ROLE_RESP_HELD, 0, _, _, _, _, _, _) : rewait_response();
            (0, t_ROLE_RESP_HELD, _, _, _, _, _, _, _) : flush_response_stale();
        } default_action = drop_old_epoch(); size = 18;
    }
    apply {
        if ((!hdr.ladder.isValid() || hdr.ladder.child == 0) &&
            (!hdr.tev.isValid() || hdr.tev.kind != t_KIND_RESPONSE || hdr.tev.stage == 0)) {
        ig_tm_md.bypass_egress = 0;
        ig_dprsr_md.mirror_type = t_MIRROR_TYPE_CLONE; md.clone_ses = t_NO_MIRROR_SESSION;   // see t_NO_MIRROR_SESSION
        params.apply(); clock.apply(); held_offsets();
        lifetime_access.apply(); gen_access.apply();
        
        child_seen0_access.apply(); md.seen1_diff = 32w0xffffffff; md.seen2_diff = 32w0xffffffff;  
        
        read_lgen_diff(); ack_go_check.apply(); ack_completion_access.apply();
        commit_at_access.apply(); commit_generation_access.apply(); response_completion_access.apply();

        if (hdr.clone.isValid()) {   // a clone by content, not by arrival port (a token t_on 196 is not one)
            drop_clone();
        } else if (ig_intr_md.ingress_port == t_T_IN) {
            // Genuine retries never allocate a new response generation or emit a clone.

            // Register work first, each under a gateway of at most 40 bits; then one verdict. e_bad is
            // nonzero whenever the policy is off (epoch_access), so no child register is touched then.
            // The child is recorded before resp_done_reg is read (stage-ordering loop, b11): the child
            // registers' only other consumer is the ACK gate (read_seen<k> -> ack_go_check and the ACK
            // roles' verdict rows), which tests only "some child seen in this generation", already true
            // once a response has been released in this generation.
            if (md.event_kind == t_KIND_RESPONSE && md.e_bad == 0 && md.enabled != 0) {
                md.dup_diff = md.seen0_diff;
            }
            // Its own gateway: resp_done_reg sits in a late stage (resp_done_try t_on the held response), and
            // bf-p4c places a gateway with the first table it guards, so sharing the mask's gateway held
            // everything after it back to that late stage (b36).
            tin_verdict.apply();
        } else if (md.token_ok == 1) {   // a generator token: right port (196 / model 0) AND expected format
            token_diffs();
            token_verdict.apply();
        } else if (ig_intr_md.ingress_port == t_HELD_RETURN) {


            // The ACK and response roles are exclusive,
            // ordered by the stage its first table needs: bf-p4c places each gateway with the first table
            // it guards, and a later gateway in the chain cannot precede an earlier one, so a late branch
            // first (read_resp_done) held every branch after it back to that stage (b36).
            // Only the response roles read the gap delta and the genuine-commit tag (a held ACK's commit pass
            // must not access ack_commit_at_reg twice, b25). Inside the chain, after the ACK-commit branch,
            // these reads land in the stage of the commit writes they share registers with (b37).

            held_verdict.apply();
        } else { drop_foreign(); }
    
        } else {
            ig_tm_md.bypass_egress = 0;
            ig_dprsr_md.drop_ctl = 1; ig_dprsr_md.mirror_type = t_MIRROR_TYPE_CLONE;
            md.clone_ses = t_NO_MIRROR_SESSION;
        }
    }
}

control t_IngressDeparser(packet_out pkt, inout t_header_t hdr, in t_metadata_t md,
                       in ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md) {
    // The no-argument Mirror instance uses the emitted mirror-type/session fields.
    // clone_mirror.emit below takes md.clone_ses and the explicit clone tag.
    Mirror() clone_mirror;
    apply {
        if (ig_dprsr_md.mirror_type == t_MIRROR_TYPE_CLONE) {
            clone_mirror.emit<t_clone_hdr_t>(md.clone_ses, { md.clone_tag });
        }
        pkt.emit(hdr);
    }
}
#ifndef CASE4_PROBE_SHELL_P4
#define CASE4_PROBE_SHELL_P4
// No target side effects: the shell forwards diagnostic events to ingress port.
parser t_EmptyEgressParser(packet_in pkt, out t_header_t hdr, out t_metadata_t md,
                        out egress_intrinsic_metadata_t eg_intr_md) {
    state start { pkt.extract(eg_intr_md); transition accept; }
}
control t_EmptyEgress(inout t_header_t hdr, inout t_metadata_t md,
                   in egress_intrinsic_metadata_t eg_intr_md,
                   in egress_intrinsic_metadata_from_parser_t eg_prsr_md,
                   inout egress_intrinsic_metadata_for_deparser_t eg_dprsr_md,
                   inout egress_intrinsic_metadata_for_output_port_t eg_oport_md) {
    apply { }
}
control t_EmptyEgressDeparser(packet_out pkt, inout t_header_t hdr,
                          in t_metadata_t md,
                          in egress_intrinsic_metadata_for_deparser_t eg_dprsr_md) {
    apply { }
}
#endif




/* ==== pipe-1 egress: current two-READ prefix construction and checksums ==== */
header x_ip_h { bit<4> version; bit<4> ihl; bit<8> tos; bit<16> len; bit<16> id; bit<3> flags;
              bit<13> frag; bit<8> ttl; bit<8> proto; bit<16> checksum; bit<32> src; bit<32> dst; }
header x_tcp_h { bit<16> sport; bit<16> dport; bit<32> seq; bit<32> ack; bit<4> offset; bit<4> reserved;
               bit<8> flags; bit<16> window; bit<16> checksum; bit<16> urgent; }
header x_dl_h { bit<16> start; bit<8> len; bit<8> ctrl; bit<16> dst; bit<16> src; bit<16> crc; }
header x_rh_h { bit<8> tpctrl; bit<8> appctrl; bit<8> func; bit<16> iin; }
header x_robj_h { bit<8> g_group; bit<8> g_var; bit<8> g_qual; bit<8> g_start; bit<8> g_stop; }
header x_d32_h { bit<32> d; }
header x_d16_h { bit<16> d; }
header x_crc_h { bit<16> crc; }
header x_pl_u_h { bit<8> tp; bit<32> app; bit<56> padobj; bit<32> padobj2; }   // mixed prefix block 0 (16 B)
header x_pl_u2_h { bit<8> tp; bit<32> app; bit<56> padobj; }                   // full prefix block 0 (12 B)
header x_pl_z_h { bit<64> w0;bit<64> w1;bit<48> w2; }                                                  // mixed prefix blocks 1-2 (22 B)
header x_ts12_h{bit<32> a;bit<32> b;bit<32> c;}
struct x_headers_t { t_tev_t tev; t_ethernet_t eth; x_ip_h ip; x_tcp_h tcp; x_ts12_h tso; x_dl_h pll; x_pl_u_h plu; x_pl_u2_h plu2;
                     x_crc_h pluc; x_pl_z_h plz; x_dl_h dl; x_rh_h rh; x_robj_h robj; x_d32_h p03; x_d16_h p45; x_crc_h c0; }
struct x_meta_t { bit<16> residual; bit<16> len_delta; bit<8> pl_tp; bit<8> co_tp; bit<16> pl_uc; bit<16> pl_uc2;
                  bit<16> co_c0; bit<16> in_rb0; bit<1> pad; bit<1> full; bit<1> conn_ok; bit<2> p1_res; bit<1> mx; bit<1> fl; }
parser x_EgParser(packet_in pkt, out x_headers_t hdr, out x_meta_t m, out egress_intrinsic_metadata_t eg) {
    Checksum() tcp_old;
    state start { pkt.extract(eg); m.pad = 0; m.full = 0; m.len_delta = 0; m.conn_ok = 0; m.mx = 0; m.fl = 0; m.p1_res = 2w2;
        transition select(eg.egress_port) { 9w180: tev; default: accept; } }
    state tev { pkt.extract(hdr.tev); transition select(hdr.tev.kind, hdr.tev.stage) { (8w11, 8w0): eth; default: accept; } }
    state eth { pkt.extract(hdr.eth); transition select(hdr.eth.type) { 16w0x0800: ip; default: accept; } }
    state ip { pkt.extract(hdr.ip);
        transition select(hdr.ip.version, hdr.ip.ihl, hdr.ip.proto) { (4w4, 4w5, 8w6): ip_len; default: accept; } }
    state ip_len { transition select(hdr.ip.len) { 16w143: ip_frag; 16w186: ip_frag; default: accept; } }
    state ip_frag { transition select(hdr.ip.frag, hdr.ip.flags) { (13w0, 3w0): tcp; (13w0, 3w2): tcp; default: accept; } }
    state tcp { pkt.extract(hdr.tcp);
        tcp_old.subtract({hdr.tcp.checksum});
        tcp_old.subtract_all_and_deposit(m.residual);
        transition select(hdr.tcp.offset) { 4w8: ts12; default: accept; } }
    state ts12 { pkt.extract(hdr.tso); transition select(hdr.tso.a) { 32w0x0101080a: dl; default: accept; } }
    state dl { pkt.extract(hdr.dl); transition select(hdr.dl.len) { 8w0x4c: dl_start; 8w0x73: dl_start; default: accept; } }
    state dl_start { transition select(hdr.dl.start) { 16w0x0564: b0; default: accept; } }
    state b0 { pkt.extract(hdr.rh); pkt.extract(hdr.robj); pkt.extract(hdr.p03); pkt.extract(hdr.p45); pkt.extract(hdr.c0); transition accept; }
}
@pa_solitary("egress","m.in_rb0")
control x_Egress(inout x_headers_t hdr, inout x_meta_t m, in egress_intrinsic_metadata_t eg,
                 in egress_intrinsic_metadata_from_parser_t eg_prsr_md,
                 inout egress_intrinsic_metadata_for_deparser_t eg_dprsr_md,
                 inout egress_intrinsic_metadata_for_output_port_t eg_oport_md) {
    CRCPolynomial<bit<16>>(16w0x3D65, true, false, false, 16w0, 16w0xFFFF) poly;
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM, poly) hash_in_rb0;
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM, poly) hash_pl_uc;
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM, poly) hash_pl_uc2;
    Hash<bit<16>>(HashAlgorithm_t.CUSTOM, poly) hash_co_c0;
    action in_rb0() { m.in_rb0 = hash_in_rb0.get({hdr.rh.tpctrl, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, hdr.robj.g_group,
        hdr.robj.g_var, hdr.robj.g_qual, hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d, hdr.c0.crc}); }
    table in_rb0_t { actions = { in_rb0; } size = 1; const default_action = in_rb0(); }
    action set_tp(bit<8> a, bit<8> b) { m.pl_tp = a; m.co_tp = b; }
    table set_tp_t { key = { hdr.rh.tpctrl : exact; } actions = { set_tp; NoAction; } size = 64; const default_action = NoAction();
        const entries = { (8w0xc0):set_tp(8w0x40,8w0x81);(8w0xc1):set_tp(8w0x41,8w0x82);(8w0xc2):set_tp(8w0x42,8w0x83);(8w0xc3):set_tp(8w0x43,8w0x84);(8w0xc4):set_tp(8w0x44,8w0x85);(8w0xc5):set_tp(8w0x45,8w0x86);(8w0xc6):set_tp(8w0x46,8w0x87);(8w0xc7):set_tp(8w0x47,8w0x88);(8w0xc8):set_tp(8w0x48,8w0x89);(8w0xc9):set_tp(8w0x49,8w0x8a);(8w0xca):set_tp(8w0x4a,8w0x8b);(8w0xcb):set_tp(8w0x4b,8w0x8c);(8w0xcc):set_tp(8w0x4c,8w0x8d);(8w0xcd):set_tp(8w0x4d,8w0x8e);(8w0xce):set_tp(8w0x4e,8w0x8f);(8w0xcf):set_tp(8w0x4f,8w0x90);(8w0xd0):set_tp(8w0x50,8w0x91);(8w0xd1):set_tp(8w0x51,8w0x92);(8w0xd2):set_tp(8w0x52,8w0x93);(8w0xd3):set_tp(8w0x53,8w0x94);(8w0xd4):set_tp(8w0x54,8w0x95);(8w0xd5):set_tp(8w0x55,8w0x96);(8w0xd6):set_tp(8w0x56,8w0x97);(8w0xd7):set_tp(8w0x57,8w0x98);(8w0xd8):set_tp(8w0x58,8w0x99);(8w0xd9):set_tp(8w0x59,8w0x9a);(8w0xda):set_tp(8w0x5a,8w0x9b);(8w0xdb):set_tp(8w0x5b,8w0x9c);(8w0xdc):set_tp(8w0x5c,8w0x9d);(8w0xdd):set_tp(8w0x5d,8w0x9e);(8w0xde):set_tp(8w0x5e,8w0x9f);(8w0xdf):set_tp(8w0x5f,8w0xa0);(8w0xe0):set_tp(8w0x60,8w0xa1);(8w0xe1):set_tp(8w0x61,8w0xa2);(8w0xe2):set_tp(8w0x62,8w0xa3);(8w0xe3):set_tp(8w0x63,8w0xa4);(8w0xe4):set_tp(8w0x64,8w0xa5);(8w0xe5):set_tp(8w0x65,8w0xa6);(8w0xe6):set_tp(8w0x66,8w0xa7);(8w0xe7):set_tp(8w0x67,8w0xa8);(8w0xe8):set_tp(8w0x68,8w0xa9);(8w0xe9):set_tp(8w0x69,8w0xaa);(8w0xea):set_tp(8w0x6a,8w0xab);(8w0xeb):set_tp(8w0x6b,8w0xac);(8w0xec):set_tp(8w0x6c,8w0xad);(8w0xed):set_tp(8w0x6d,8w0xae);(8w0xee):set_tp(8w0x6e,8w0xaf);(8w0xef):set_tp(8w0x6f,8w0xb0);(8w0xf0):set_tp(8w0x70,8w0xb1);(8w0xf1):set_tp(8w0x71,8w0xb2);(8w0xf2):set_tp(8w0x72,8w0xb3);(8w0xf3):set_tp(8w0x73,8w0xb4);(8w0xf4):set_tp(8w0x74,8w0xb5);(8w0xf5):set_tp(8w0x75,8w0xb6);(8w0xf6):set_tp(8w0x76,8w0xb7);(8w0xf7):set_tp(8w0x77,8w0xb8);(8w0xf8):set_tp(8w0x78,8w0xb9);(8w0xf9):set_tp(8w0x79,8w0xba);(8w0xfa):set_tp(8w0x7a,8w0xbb);(8w0xfb):set_tp(8w0x7b,8w0xbc);(8w0xfc):set_tp(8w0x7c,8w0xbd);(8w0xfd):set_tp(8w0x7d,8w0xbe);(8w0xfe):set_tp(8w0x7e,8w0xbf);(8w0xff):set_tp(8w0x7f,8w0x80); } }
    action crc_pl_uc() { m.pl_uc = hash_pl_uc.get({m.pl_tp, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, 56w283678295202052, 32w0}); }
    table crc_pl_uc_t { actions = { crc_pl_uc; } size = 1; const default_action = crc_pl_uc(); }
    action crc_pl_uc2() { m.pl_uc2 = hash_pl_uc2.get({m.pl_tp, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, 56w283678295196420}); }
    table crc_pl_uc2_t { actions = { crc_pl_uc2; } size = 1; const default_action = crc_pl_uc2(); }
    action crc_co_c0() { m.co_c0 = hash_co_c0.get({m.co_tp, 32w0, hdr.robj.g_group, hdr.robj.g_var, hdr.robj.g_qual,
        hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d}); }
    table crc_co_c0_t { actions = { crc_co_c0; } size = 1; const default_action = crc_co_c0(); }
    action pad_mx() { m.pad = 1; m.full = 0; m.mx = 1; m.p1_res = 2w1; }
    action pad_full() { m.pad = 1; m.full = 1; m.fl = 1; m.p1_res = 2w1; }
    /* Size enable per connection, installed by the control plane exactly when E's fwd_conn row enables padding
       for the same outstation->master 4-tuple (cp.p1_pad_rows). No row = no padding: a size-off arm or a native
       connection stays native end to end. */
    action p1_pad_ok() { m.conn_ok = 1; m.p1_res = 2w3; }
    table p1_conn { key = { hdr.ip.src : exact; hdr.ip.dst : exact; hdr.tcp.sport : exact; hdr.tcp.dport : exact; }
        actions = { p1_pad_ok; NoAction; } size = 16; const default_action = NoAction(); }
    /* the shape is the exact (IP length, link LEN) PAIR, as N's parser dispatches it (review of m12p_c23: keying LEN
       alone would let an IP-287 frame with LEN 0x4c be padded as mixed) */
    table read_profile { key = { hdr.ip.len : exact; hdr.dl.len : exact; hdr.rh.tpctrl : ternary; hdr.rh.appctrl : ternary; hdr.rh.func : exact;
            hdr.robj.g_group : exact; hdr.robj.g_var : exact; hdr.robj.g_qual : exact; hdr.robj.g_start : exact; hdr.robj.g_stop : exact; }
        actions = { pad_mx; pad_full; NoAction; } size = 2; const default_action = NoAction();
        const entries = { (16w143, 8w0x4c, 8w0xC0 &&& 8w0xC0, 8w0xC0 &&& 8w0xF0, 8w0x81, 8w0x01, 8w0x02, 8w0x00, 8w0x00, 8w0x0f): pad_mx();
                          (16w186, 8w0x73, 8w0xC0 &&& 8w0xC0, 8w0xC0 &&& 8w0xF0, 8w0x81, 8w0x01, 8w0x02, 8w0x00, 8w0x00, 8w0x0f): pad_full(); } }
    action prefix_mx() {
        hdr.pll.setValid(); hdr.pll.start = 16w0x0564; hdr.pll.len = 8w39; hdr.pll.ctrl = hdr.dl.ctrl;
        hdr.pll.dst = hdr.dl.dst; hdr.pll.src = hdr.dl.src; hdr.pll.crc = hdr.dl.crc ^ 16w29526;
        hdr.plu.setValid(); hdr.plu.tp = m.pl_tp; hdr.plu.app = hdr.rh.appctrl ++ hdr.rh.func ++ hdr.rh.iin;
        hdr.plu.padobj = 56w283678295202052; hdr.plu.padobj2 = 32w0;
        hdr.pluc.setValid(); hdr.pluc.crc = m.pl_uc[7:0] ++ m.pl_uc[15:8];
        hdr.plz.setValid(); hdr.plz.w0=64w0x0000000000000000;hdr.plz.w1=64w0x0000000000000000;hdr.plz.w2=48w0xffff0000ffff;
        hdr.rh.tpctrl = m.co_tp; hdr.rh.appctrl = 8w0; hdr.rh.func = 8w0; hdr.rh.iin = 16w0;
        hdr.c0.crc = m.co_c0[7:0] ++ m.co_c0[15:8];
        hdr.ip.len = 16w193; m.len_delta = 16w50;
    }
    table prefix_mx_t { actions = { prefix_mx; } size = 1; const default_action = prefix_mx(); }
    action prefix_full() {
        hdr.pll.setValid(); hdr.pll.start = 16w0x0564; hdr.pll.len = 8w17; hdr.pll.ctrl = hdr.dl.ctrl;
        hdr.pll.dst = hdr.dl.dst; hdr.pll.src = hdr.dl.src; hdr.pll.crc = hdr.dl.crc ^ 16w18553;
        hdr.plu2.setValid(); hdr.plu2.tp = m.pl_tp; hdr.plu2.app = hdr.rh.appctrl ++ hdr.rh.func ++ hdr.rh.iin;
        hdr.plu2.padobj = 56w283678295196420;
        hdr.pluc.setValid(); hdr.pluc.crc = m.pl_uc2[7:0] ++ m.pl_uc2[15:8];
        hdr.rh.tpctrl = m.co_tp; hdr.rh.appctrl = 8w0; hdr.rh.func = 8w0; hdr.rh.iin = 16w0;
        hdr.c0.crc = m.co_c0[7:0] ++ m.co_c0[15:8];
        hdr.ip.len = 16w210; m.len_delta = 16w24;
    }
    table prefix_full_t { actions = { prefix_full; } size = 1; const default_action = prefix_full(); }
    apply {
        if (hdr.c0.isValid()) {
            p1_conn.apply();
            in_rb0_t.apply(); set_tp_t.apply(); crc_pl_uc_t.apply(); crc_pl_uc2_t.apply(); crc_co_c0_t.apply();
            if (m.conn_ok == 1w1 && m.in_rb0 == 16w0x993a) { read_profile.apply(); }   // CRC residue: block CRC correct
            if (m.pad == 1w1) {
                if (m.full == 1w0) { prefix_mx_t.apply(); } else { prefix_full_t.apply(); }
            }
        }
    }
}
control x_EgDeparser(packet_out pkt, inout x_headers_t hdr, in x_meta_t m, in egress_intrinsic_metadata_for_deparser_t md) {
    Checksum() ip_new; Checksum() tcp_mx; Checksum() tcp_full;
    apply {
        if (m.pad == 1w1) {
            hdr.ip.checksum = ip_new.update({hdr.ip.version, hdr.ip.ihl, hdr.ip.tos, hdr.ip.len, hdr.ip.id, hdr.ip.flags,
                                             hdr.ip.frag, hdr.ip.ttl, hdr.ip.proto, hdr.ip.src, hdr.ip.dst});
        }
        if (m.mx == 1w1) {   // mixed: 50-B prefix (the 22-B constant remainder is folded into m.len_delta)
            hdr.tcp.checksum = tcp_mx.update({m.len_delta, hdr.tso.a, hdr.tso.b, hdr.tso.c,
                hdr.pll.start, hdr.pll.len, hdr.pll.ctrl, hdr.pll.dst, hdr.pll.src, hdr.pll.crc,
                hdr.plu.tp, hdr.plu.app, hdr.plu.padobj, hdr.plu.padobj2, hdr.pluc.crc,
                hdr.dl.start, hdr.dl.len, hdr.dl.ctrl, hdr.dl.dst, hdr.dl.src, hdr.dl.crc,
                hdr.rh.tpctrl, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, hdr.robj.g_group, hdr.robj.g_var, hdr.robj.g_qual,
                hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d, hdr.c0.crc,
                m.residual});
        }
        if (m.fl == 1w1) {  // full: 24-B prefix
            hdr.tcp.checksum = tcp_full.update({m.len_delta, hdr.tso.a, hdr.tso.b, hdr.tso.c,
                hdr.pll.start, hdr.pll.len, hdr.pll.ctrl, hdr.pll.dst, hdr.pll.src, hdr.pll.crc,
                hdr.plu2.tp, hdr.plu2.app, hdr.plu2.padobj, hdr.pluc.crc,
                hdr.dl.start, hdr.dl.len, hdr.dl.ctrl, hdr.dl.dst, hdr.dl.src, hdr.dl.crc,
                hdr.rh.tpctrl, hdr.rh.appctrl, hdr.rh.func, hdr.rh.iin, hdr.robj.g_group, hdr.robj.g_var, hdr.robj.g_qual,
                hdr.robj.g_start, hdr.robj.g_stop, hdr.p03.d, hdr.p45.d, hdr.c0.crc,
                m.residual});
        }
        pkt.emit(hdr.tev); pkt.emit(hdr.eth); pkt.emit(hdr.ip); pkt.emit(hdr.tcp); pkt.emit(hdr.tso);
        pkt.emit(hdr.pll); pkt.emit(hdr.plu); pkt.emit(hdr.plu2); pkt.emit(hdr.pluc); pkt.emit(hdr.plz);
        pkt.emit(hdr.dl); pkt.emit(hdr.rh); pkt.emit(hdr.robj); pkt.emit(hdr.p03); pkt.emit(hdr.p45); pkt.emit(hdr.c0);
    }
}
Pipeline(n_IgParser(), n_Ingress(), n_IgDeparser(), r_EgParser(), r_Egress(), r_EgDeparser()) p0;
Pipeline(t_IngressParser(), t_Ingress(), t_IngressDeparser(), x_EgParser(), x_Egress(), x_EgDeparser()) p1;
Switch(p0, p1) main;
