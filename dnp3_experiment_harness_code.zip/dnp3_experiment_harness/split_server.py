"""
split_server.py -- self-contained TCP replay/split server (no pydnp3 needed).

Run it with no arguments:

    python split_server.py

It stands in for the outstation on 0.0.0.0:20000 (settings from lab_config.py),
and for each master request it:

  - parses the DNP3 function code + application sequence,
  - selects the matching captured response (request->response map built from the
    baseline capture's payloads/replay/*.bin + metadata.json),
  - splits a READ response on existing DNP3 CRC boundaries -- no byte is altered
    and no CRC is recomputed, so b"".join(chunks) == response,
  - sends the chunks with socket.sendall(), holds the connection open, and logs
    the master's DNP3 CONFIRM.

It refuses to serve a captured response to a request it cannot match (no blind
byte dumping). Everything it needs -- request parser, CRC-boundary splitter,
captured-exchange map, and the TCP server -- lives in this one file; at runtime
only this file and lab_config.py are loaded from the harness. This is a plain
TCP socket server, so it does NOT require pydnp3.

Stop the real outstation first -- both need port 20000:

    sudo fuser -k 20000/tcp

(Alternatives, run directly: dnp3_ordered_replay_server.py for positional/ordered
replay; legacy_single_response_server.py for the legacy single-shot byte-split
server.)
"""

import json
import logging
import os
import socket
import sys
import time

from datetime import datetime

HARNESS_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# Lab config (inlined so this server loads only itself at runtime).
# This is a mirror of lab_config.py; if lab roles change, update these values
# here AND in lab_config.py (still used by the extract/map/analyze wrappers).
# ---------------------------------------------------------------------------
BIND_IP = "0.0.0.0"                          # bind the replay server on all interfaces
DNP3_PORT = 20000
DEFAULT_SPLIT_MODE = "crc-boundary"
DEFAULT_BLOCKS_PER_CHUNK = 1
DEFAULT_CHUNK_DELAY_MS = 10
DEFAULT_HOLD_AFTER_RESPONSE_SEC = 20
DEFAULT_REPLAY_DIR = "payloads/replay"
LOG_DIR = "logs"

stdout_stream = logging.StreamHandler(sys.stdout)
stdout_stream.setFormatter(logging.Formatter('%(asctime)s\t%(name)s\t%(levelname)s\t%(message)s'))
logging.getLogger().addHandler(stdout_stream)
logging.getLogger().setLevel(logging.DEBUG)
_log = logging.getLogger(__name__)

# --- DNP3 framing constants -------------------------------------------------
START_BYTES = b"\x05\x64"        # DNP3 link-frame start octets
READ_FUNCTION_CODE = 0x01
RECV_BUFSIZE = 65535
CRC_SPLIT_MODES = ("crc", "crc-boundary")

# Application function codes, enough to identify a master request.
FUNCTION_CODES = {
    0x00: "CONFIRM",
    0x01: "READ",
    0x02: "WRITE",
    0x14: "ENABLE_UNSOLICITED",
    0x15: "DISABLE_UNSOLICITED",
    0x81: "RESPONSE",
}
# A frame must reach at least the application function code (offset 12) to parse.
_MIN_FRAME_LEN = 13

# On-wire DNP3 block layout used to locate CRC boundaries:
#   header block = 8 header bytes + 2 CRC ; data block = up to 16 bytes + 2 CRC
HEADER_BLOCK = 8
CRC_LEN = 2
DATA_BLOCK = 16
LEN_FIXED = 5            # LEN counts control+dest+src; user bytes = LEN - 5


# ------------------------------------------------------------------ #
# Minimal DNP3 request parsing (function code + application sequence)
# ------------------------------------------------------------------ #

def parse_dnp3_request(data):
    """Identify a master request from the first link frame of ``data``.

    DNP3 frame byte offsets used here:
        0-1 start (0x05 0x64); 2 length; 3 link control; 4-5 dest (LE);
        6-7 src (LE); 8-9 header CRC; 10 transport byte; 11 application
        control (sequence in low nibble); 12 application function code.

    Returns a dict with ``valid`` plus the decoded fields. ``valid`` is False
    (fields None) when the bytes are too short or lack the DNP3 start bytes.
    """
    if len(data) < _MIN_FRAME_LEN or data[0:2] != START_BYTES:
        return {
            "valid": False,
            "src": None,
            "dst": None,
            "transport_seq": None,
            "transport_fir": None,
            "transport_fin": None,
            "app_seq": None,
            "function_code": None,
            "function_name": None,
            "payload_len": len(data),
        }

    dst = data[4] | (data[5] << 8)
    src = data[6] | (data[7] << 8)
    transport = data[10]
    app_control = data[11]
    function_code = data[12]
    return {
        "valid": True,
        "src": src,
        "dst": dst,
        "transport_seq": transport & 0x3F,
        "transport_fir": bool(transport & 0x40),
        "transport_fin": bool(transport & 0x80),
        "app_seq": app_control & 0x0F,
        "function_code": function_code,
        "function_name": FUNCTION_CODES.get(function_code, "UNKNOWN"),
        "payload_len": len(data),
    }


def describe_request(parsed):
    """Render a parsed request as a one-line string for logs."""
    if not parsed["valid"]:
        return "non-DNP3/short ({} bytes)".format(parsed["payload_len"])
    return "{} (0x{:02x}) app_seq={} src={} dst={}".format(
        parsed["function_name"], parsed["function_code"],
        parsed["app_seq"], parsed["src"], parsed["dst"])


# ------------------------------------------------------------------ #
# CRC-boundary splitter (reuse existing CRCs, recompute nothing)
# ------------------------------------------------------------------ #

class DNP3CRCSplitter(object):
    """
        Split a captured DNP3 byte stream at its existing CRC boundaries -- without
        recomputing any CRC.

        Every DNP3 block (the header block and each <=16-byte data block) already
        ends with its own 2-byte CRC. This splitter locates those boundaries and
        cuts the byte stream so each piece ends exactly on a CRC that is already
        present in the capture. No bytes are altered and no CRC is recalculated:
        the concatenation of the pieces is byte-identical to the input.
    """

    def crc_boundaries(self, data):
        """
            Return the byte offsets that immediately follow each CRC in ``data``.

            These are exactly the positions where the stream can be cut so every
            piece ends on an existing CRC.
        """
        bounds = []
        offset = 0
        n = len(data)
        while offset < n - 1:
            if data[offset:offset + 2] != START_BYTES:
                offset += 1
                continue
            length = data[offset + 2]
            user_total = length - LEN_FIXED
            if user_total < 0:
                _log.warning('Invalid LEN=%s at offset %s; stopping scan.', length, offset)
                break
            # boundary after the header block's CRC
            pos = offset + HEADER_BLOCK + CRC_LEN
            bounds.append(pos)
            remaining = user_total
            while remaining > 0:
                chunk = min(DATA_BLOCK, remaining)
                pos += chunk + CRC_LEN          # boundary after this data block's CRC
                bounds.append(pos)
                remaining -= chunk
            offset = pos
        return [b for b in bounds if 0 < b <= n]

    def split(self, data, blocks_per_chunk=1):
        """
            Split ``data`` into chunks of ``blocks_per_chunk`` whole CRC blocks.

            Each chunk ends on an existing CRC; no CRC is recomputed. The
            concatenation of the returned chunks equals ``data`` exactly.
        """
        if blocks_per_chunk < 1:
            raise ValueError('blocks_per_chunk must be >= 1')
        bounds = self.crc_boundaries(data)
        # keep every Nth boundary as a cut point
        cuts = bounds[blocks_per_chunk - 1::blocks_per_chunk]
        chunks = []
        prev = 0
        for cut in cuts:
            if cut > prev:
                chunks.append(data[prev:cut])
                prev = cut
        if prev < len(data):                    # trailing bytes (shouldn't happen on clean input)
            chunks.append(data[prev:])
        if b''.join(chunks) != data:
            raise ValueError('CRC split did not reconstruct the original stream')
        return chunks


# ------------------------------------------------------------------ #
# Captured request -> response map
# ------------------------------------------------------------------ #

class CapturedExchange:
    """The captured request->response entries, with request matching.

    A baseline capture is extracted into orig_*.bin (master requests), resp_*.bin
    (outstation responses) and metadata.json (an ordered list of packet records).
    In capture order, each request is followed by the run of responses it
    produced; that run, concatenated, is the captured reply to that request. This
    refuses to serve a captured response to a request it cannot match -- the
    safety rule that keeps the server from being a blind byte dumper.
    """

    def __init__(self, payload_dir):
        self.payload_dir = payload_dir
        self.entries = self._load_entries(payload_dir)
        self._used = [False] * len(self.entries)

        _log.info("Loaded %s captured request->response entr(ies) from %s.",
                  len(self.entries), payload_dir)
        for i, entry in enumerate(self.entries):
            _log.info("  entry %s: %s (0x%02x) app_seq=%s -> %s (%s bytes)%s",
                      i + 1, entry["function_name"], entry["function_code"],
                      entry["app_seq"], "+".join(entry["response_files"]),
                      len(entry["response_bytes"]),
                      " [READ -- will be split]" if entry["is_read"] else "")

    def has_pending_responses(self):
        """True while at least one captured response has not been served yet."""
        return not all(self._used)

    def match_response(self, parsed_request):
        """Return the captured entry for ``parsed_request``, or None.

        Match priority:
          1. same function code AND application sequence,
          2. otherwise the next unused entry with the same function code.

        On a match the entry is marked used so it is not served twice. A request
        that matches nothing returns None -- a captured response is never served
        to a request that does not match one.
        """
        if not parsed_request["valid"]:
            return None

        index = self._find(parsed_request, require_app_seq=True)
        if index is None:
            index = self._find(parsed_request, require_app_seq=False)
        if index is None:
            _log.warning("No captured response matches function code %s app_seq %s; "
                         "serving nothing.",
                         "0x{:02x}".format(parsed_request["function_code"]),
                         parsed_request["app_seq"])
            return None

        self._used[index] = True
        return self.entries[index]

    def _find(self, parsed_request, require_app_seq):
        """Index of the first unused entry matching the request, or None."""
        for i, entry in enumerate(self.entries):
            if self._used[i]:
                continue
            if entry["function_code"] != parsed_request["function_code"]:
                continue
            if require_app_seq and entry["app_seq"] != parsed_request["app_seq"]:
                continue
            return i
        return None

    def _load_entries(self, payload_dir):
        """Read metadata.json and build the ordered request->response entries."""
        with open(os.path.join(payload_dir, "metadata.json")) as fh:
            events = json.load(fh)

        # Group each request ('orig') with the consecutive responses ('resp')
        # that follow it before the next request, in capture order.
        groups = []
        request_file = None
        response_files = []
        for event in events:
            if event["direction"] == "orig":
                if request_file is not None:
                    groups.append((request_file, response_files))
                request_file = event["filename"]
                response_files = []
            else:
                response_files.append(event["filename"])
        if request_file is not None:
            groups.append((request_file, response_files))

        entries = []
        for request_file, response_files in groups:
            with open(os.path.join(payload_dir, request_file), "rb") as fh:
                parsed = parse_dnp3_request(fh.read())
            response_bytes = bytearray()
            for name in response_files:
                with open(os.path.join(payload_dir, name), "rb") as fh:
                    response_bytes += fh.read()
            entries.append({
                "request_file": request_file,
                "response_files": response_files,
                "response_bytes": bytes(response_bytes),
                "function_code": parsed["function_code"],
                "function_name": parsed["function_name"],
                "app_seq": parsed["app_seq"],
                "is_read": parsed["function_code"] == READ_FUNCTION_CODE,
            })
        return entries


# ------------------------------------------------------------------ #
# Single-connection TCP replay/split server
# ------------------------------------------------------------------ #

class TCPSplitReplayServer:
    """Single-connection TCP server that replays matched captured responses.

    It opens a plain TCP server on the outstation's port, accepts the master's
    connection, and for each master request selects the matching captured
    response, splits a READ response on existing DNP3 CRC boundaries (no byte
    altered, no CRC recomputed, so b"".join(chunks) == response), and sends the
    chunks with socket.sendall(). The single connection is held open so the
    master's DNP3 CONFIRM arrives on the same socket.
    """

    def __init__(self, host, port, exchange, split_mode="crc-boundary",
                 blocks_per_chunk=1, delay_between_chunks_ms=0,
                 request_timeout_sec=10.0, hold_after_response_sec=10.0,
                 log_dir=None):
        self.host = host
        self.port = port
        self.exchange = exchange
        self.split_mode = split_mode
        self.blocks_per_chunk = blocks_per_chunk
        self.delay_between_chunks_ms = delay_between_chunks_ms
        self.request_timeout_sec = request_timeout_sec
        self.hold_after_response_sec = hold_after_response_sec
        self.log_dir = log_dir

        self._splitter = DNP3CRCSplitter()
        self._request_count = 0
        if self.log_dir:
            os.makedirs(self.log_dir, exist_ok=True)

    def serve_once(self):
        """Accept one master connection and replay the matched responses."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((self.host, self.port))
            server.listen(1)
            _log.info("Listening on %s:%s", self.host, self.port)

            conn, addr = server.accept()
            _log.info("Accepted connection from %s at %s", addr, datetime.now().isoformat())

            with conn:
                while self.exchange.has_pending_responses():
                    request = self._receive_request(conn)
                    if not request:
                        _log.warning("No further master request (idle or closed); stopping.")
                        break

                    self._request_count += 1
                    self._dump("request_{:02d}.bin".format(self._request_count), request)
                    parsed = parse_dnp3_request(request)
                    _log.info("Received request: %s [%s byte(s)]",
                              describe_request(parsed), len(request))
                    if parsed["valid"] and parsed["function_name"] == "CONFIRM":
                        _log.info("Received CONFIRM (app_seq=%s).", parsed["app_seq"])

                    entry = self.exchange.match_response(parsed)
                    if entry is None:
                        # Safety: never fire a captured response at a request we
                        # cannot match. Wait for the next master message.
                        continue

                    chunks = self._make_chunks(entry)
                    if b"".join(chunks) != entry["response_bytes"]:
                        raise ValueError("split did not reconstruct the response for {}".format(
                            entry["request_file"]))

                    _log.info("Matched response file(s): %s", "+".join(entry["response_files"]))
                    _log.info("Split mode: %s",
                              self.split_mode if entry["is_read"] else "full (single write)")
                    _log.info("Chunk count: %s", len(chunks))
                    _log.info("Chunk sizes: %s", [len(c) for c in chunks])
                    _log.info("Byte-preservation check: PASS")
                    self._send_chunks(conn, chunks)
                    if entry["is_read"]:
                        _log.info("READ response sent; waiting for the master CONFIRM.")

                if not self.exchange.has_pending_responses():
                    _log.info("All captured responses replayed.")
                self._receive_trailing_data(conn)

            _log.info("Connection closed cleanly.")

    def _receive_request(self, conn):
        """Block up to request_timeout_sec for one master message; b'' on timeout/close."""
        conn.settimeout(self.request_timeout_sec)
        try:
            return conn.recv(RECV_BUFSIZE)
        except (socket.timeout, OSError):
            return b""

    def _make_chunks(self, entry):
        """Split a READ response on CRC boundaries; send anything else as one write."""
        response_bytes = entry["response_bytes"]
        if entry["is_read"] and self.split_mode in CRC_SPLIT_MODES:
            return self._splitter.split(response_bytes, self.blocks_per_chunk)
        return [response_bytes]

    def _send_chunks(self, conn, chunks):
        """Write each chunk with sendall(), optionally pausing between writes."""
        for index, chunk in enumerate(chunks):
            conn.sendall(chunk)
            _log.info("Sent chunk %s/%s: %s byte(s)", index + 1, len(chunks), len(chunk))
            if self.delay_between_chunks_ms > 0 and index < len(chunks) - 1:
                time.sleep(self.delay_between_chunks_ms / 1000.0)

    def _receive_trailing_data(self, conn):
        """Hold the socket open briefly and log any trailing bytes (e.g. a CONFIRM)."""
        if self.hold_after_response_sec <= 0:
            return
        _log.info("Holding connection for trailing data / final CONFIRM (up to %ss).",
                  self.hold_after_response_sec)
        deadline = time.time() + self.hold_after_response_sec
        trailing = bytearray()
        conn.settimeout(0.5)
        while time.time() < deadline:
            try:
                data = conn.recv(RECV_BUFSIZE)
            except socket.timeout:
                continue
            except OSError:
                break
            if not data:
                _log.info("Master closed the connection.")
                break
            trailing += data
            parsed = parse_dnp3_request(data)
            if parsed["valid"] and parsed["function_name"] == "CONFIRM":
                _log.info("Received CONFIRM (app_seq=%s).", parsed["app_seq"])
            else:
                _log.info("Trailing bytes received: %s (%s)", len(data), describe_request(parsed))
        if trailing:
            self._dump("trailing.bin", bytes(trailing))

    def _dump(self, name, data):
        """Save a byte buffer under log_dir, if logging to a directory."""
        if not self.log_dir:
            return
        with open(os.path.join(self.log_dir, name), "wb") as fh:
            fh.write(data)


def main():
    """Stand in for the outstation and replay captured responses, split on CRC boundaries."""
    payload_dir = os.path.join(HARNESS_DIR, DEFAULT_REPLAY_DIR)
    if not os.path.exists(os.path.join(payload_dir, "metadata.json")):
        _log.error("Missing %s/metadata.json. Run the baseline capture and "
                   "extract_payloads.py first.", DEFAULT_REPLAY_DIR)
        sys.exit(1)

    log_dir = os.path.join(HARNESS_DIR, LOG_DIR, "replay")
    os.makedirs(log_dir, exist_ok=True)
    file_handler = logging.FileHandler(
        os.path.join(log_dir, "split_replay_server_{}.log".format(int(time.time()))))
    file_handler.setFormatter(logging.Formatter('%(asctime)s\t%(name)s\t%(levelname)s\t%(message)s'))
    logging.getLogger().addHandler(file_handler)

    _log.info("Split server replacing the outstation on %s:%s (split-mode=%s).",
              BIND_IP, DNP3_PORT, DEFAULT_SPLIT_MODE)
    _log.info("Reminder: stop the real outstation first -- sudo fuser -k %s/tcp", DNP3_PORT)

    exchange = CapturedExchange(payload_dir)
    server = TCPSplitReplayServer(
        host=BIND_IP,
        port=DNP3_PORT,
        exchange=exchange,
        split_mode=DEFAULT_SPLIT_MODE,
        blocks_per_chunk=DEFAULT_BLOCKS_PER_CHUNK,
        delay_between_chunks_ms=DEFAULT_CHUNK_DELAY_MS,
        request_timeout_sec=10.0,
        hold_after_response_sec=DEFAULT_HOLD_AFTER_RESPONSE_SEC,
        log_dir=log_dir,
    )
    server.serve_once()


if __name__ == "__main__":
    main()
