# DNP3 Experiment Harness

A reproducible, scriptable harness for generating controlled DNP3 READ/RESPONSE
traffic, capturing PCAPs, extracting raw response bytes, replaying them
(verbatim and split across TCP writes), mapping DNP3 header fields, and
analyzing TCP ACK behavior.

It is built on `pydnp3` (OpenDNP3 bindings) and reuses the coding style of the
original example scripts preserved in `archive_original/`.

## Quick Start — No-IP Short Commands

All lab settings (IPs, port, DNP3 link addresses, default payload, split mode)
live in **`lab_config.py`**. Edit that one file if the lab roles change; you
never type an IP in a command. Three short runners cover the whole experiment —
each is a thin wrapper over the reusable classes and works with no arguments:

```bash
python run_outstation.py   # baseline: start the real outstation (large DB)
python run_master.py       # send one READ (baseline OR replay/split phase)
python split_server.py     # replay/split: replace the outstation, serve captured bytes
```

**Baseline phase** (master <-> real outstation):

```bash
# outstation host
python run_outstation.py
# master host
python run_master.py        # -> logs/master/soe.csv
```

**Replay / split phase** (split server replaces the outstation at its IP:port):

```bash
# outstation host: free the port, then serve the captured response
sudo fuser -k 20000/tcp
python split_server.py      # crc-boundary split by default; bytes preserved exactly
# master host (same command as baseline -- it cannot tell the difference)
python run_master.py
```

Default split mode is **`crc-boundary`**: the captured stream is cut only on
existing DNP3 CRC block boundaries, so every chunk ends on an already-valid CRC —
no CRC is recomputed and `b"".join(chunks) == original`. The split server holds
the socket open after sending and logs any follow-up DNP3 CONFIRM.

Convenience wrappers (also no-IP, reading `lab_config.py`):

```bash
python extract_payloads.py  # PCAP -> payloads/baseline/*.bin + metadata.json
python map_response.py      # decode DNP3 header fields -> reports/field_map_results.md
python analyze_ack.py       # TCP ACK/timing fingerprint -> reports/tcp_ack_*.csv
```

The longer `--flag` commands in the sections below still work and override the
config defaults (the runners forward any extra arguments to the underlying CLI).

## 1. Purpose

Experimentally answer, in order:

1. Can we generate clean, controlled DNP3 READ/RESPONSE traffic?
2. Can we scale the outstation database to force larger responses?
3. Does OpenDNP3 naturally split large responses into multiple TCP payloads or
   DNP3 frames?
4. Can we capture and extract the raw DNP3 TCP payload bytes?
5. Can a plain TCP socket replay server send captured responses back to the
   OpenDNP3 master?
6. Can the same response be delivered in multiple TCP writes without breaking
   the master?
7. What fields are needed later for true DNP3-aware splitting and padding?

This is a **protocol experiment harness**, not a final obfuscation
implementation, and not a P4 project.

## 2. Why It Is General (Not Project-Branded)

The harness uses neutral, descriptive names and carries no project-specific
branding so it can serve as a general DNP3 protocol lab. All Python sources live
in a single flat folder (`dnp3_experiment_harness/`); each of the three entry
points is self-contained.

## 3. Install

```bash
pip install -r requirements.txt
```

`pydnp3` is a native extension (OpenDNP3 bindings); `scapy` is used by the PCAP
tools. The argparse `--help` of the replay/analysis scripts works even without
`pydnp3` installed (heavy imports are deferred until after argument parsing).
`run_master.py` and `run_outstation.py` are self-contained (the master/outstation
class + CLI in one file) and import `pydnp3` at load, so those two require the
native extension. `split_server.py` is self-contained and needs **no** pydnp3.

## Layout

All Python sources are in this one flat folder. The three entry points are
self-contained -- each inlines its own lab-config block and at runtime loads
only itself. `lab_config.py` is the shared config for the tool wrappers below.

```
lab_config.py                  shared config for the tool wrappers (no IPs in commands)
run_master.py                  self-contained master (ExperimentMaster + visitors + CSV SOE)
run_outstation.py              self-contained outstation (ExperimentOutstation + handler)
split_server.py                self-contained request-aware split server (no pydnp3)
extract_payloads.py            PCAP -> raw DNP3 payloads + metadata.json (no-IP; flags override)
map_response.py                decode DNP3 header fields -> reports/ (no-IP; flags override)
analyze_ack.py                 TCP ACK behavior analyzer -> reports/ (no-IP; flags override)
dnp3_crc.py                    CRC-16/DNP helpers (used by map_response.py)
dnp3_crc_splitter.py           standalone CRC-boundary splitter CLI
dnp3_replay_server.py          exact verbatim replay server
dnp3_ordered_replay_server.py  positional/ordered confirm-aware replay server
legacy_single_response_server.py  legacy single-shot byte-split server
scripts/           capture + replay orchestration shell scripts
captures/          PCAPs (baseline / replay / split / raw)
payloads/          extracted raw DNP3 bytes (baseline / replay / split)
logs/              per-run logs + SOE CSVs (master / outstation / replay / analysis)
reports/           audit + results write-ups
future_work/       experimental recompute-based codec/splitter (archived, not used)
archive_original/  unmodified original scripts (preserved, never deleted)
```

## 3. Run the Outstation

No-IP runner (settings from `lab_config.py`):

```bash
python run_outstation.py
```

Or with explicit flags (the runner forwards them):

```bash
python run_outstation.py \
  --host 0.0.0.0 --port 20000 --local-addr 10 --remote-addr 1 \
  --db-size 20 --num-analog 5 --num-binary 5 --num-counter 0 \
  --log-dir logs/outstation
```

Defaults are safety-first: **unsolicited responses OFF** and **controls
rejected** (`NOT_SUPPORTED`) unless `--allow-unsolicited` / `--allow-controls`
are passed. A no-arg run applies initial values and holds until Ctrl+C; pass
`--no-apply-initial-values` / `--no-hold` to change that.

## 4. Run the Master

No-IP runner (settings from `lab_config.py`):

```bash
python run_master.py        # -> logs/master/soe.csv
```

Or with explicit flags:

```bash
python run_master.py \
  --host <OUTSTATION_IP> --local 0.0.0.0 --port 20000 \
  --master-addr 1 --outstation-addr 10 \
  --action scan-all-classes --repeat 1 --wait-after-action 5 \
  --csv logs/master/soe.csv --log-dir logs/master
```

Actions: `connect-only`, `scan-class0`, `scan-all-classes`, `scan-range`,
`scan-all-objects`, `disable-unsolicited`. Periodic background scans are OFF
unless `--enable-periodic-scans` is given. The CLI exposes **no control
commands** (DirectOperate/SelectAndOperate); those remain only as warning-gated
methods on the `ExperimentMaster` class.

## 5. Capture Traffic

```bash
sudo tcpdump -i <INTERFACE> -w captures/baseline/run.pcap 'tcp port 20000'
```

## 6. Small READ

```bash
OUTSTATION_IP=<OUTSTATION_IP> IFACE=<INTERFACE> PORT=20000 \
  bash scripts/run_small_read_capture.sh
```

## 7. Large READ

```bash
OUTSTATION_IP=<OUTSTATION_IP> IFACE=<INTERFACE> PORT=20000 \
  bash scripts/run_large_read_capture.sh
```

## 8. Range Sweep

```bash
OUTSTATION_IP=<OUTSTATION_IP> IFACE=<INTERFACE> PORT=20000 \
  bash scripts/run_range_sweep.sh   # sweeps 0..9, 0..49, 0..99, 0..199
```

(Set `START_OUTSTATION=1` on any capture script to also launch a local
outstation for a self-contained run.)

## 9. Extract Payloads

```bash
python extract_payloads.py          # no args: uses lab_config defaults
# or override any default with flags:
python extract_payloads.py \
  --pcap captures/baseline/large_read.pcap \
  --master-ip <MASTER_IP> --outstation-ip <OUTSTATION_IP> \
  --port 20000 --output-dir payloads/baseline
```

Writes `orig_NNNN.bin` (master→outstation), `resp_NNNN.bin`
(outstation→master), and `metadata.json` (timestamps, IPs, ports, lengths, TCP
flags/seq/ack, direction). Only raw application bytes are saved — no
Ethernet/IP/TCP headers.

## 10. Replay Exact Responses

```bash
# Terminal 1
python dnp3_replay_server.py \
  --host 0.0.0.0 --port 20000 \
  --response payloads/baseline/resp_0001.bin \
  --delay-before-response-ms 0 --hold-after-response-sec 5 --log-dir logs/replay
# Terminal 2: point the master at the replay server IP
```

Uses an ordinary OS socket — the kernel owns TCP seq/ACK/retransmit/checksums.
The exact captured bytes are sent unmodified.

## 11. Split Replay Responses (request-aware)

The main replay path stands in for the outstation, matches each master request to
its captured response, and splits the READ response on existing DNP3 CRC
boundaries. Use the no-IP runner:

```bash
python split_server.py            # reads lab_config.py; crc-boundary split by default
```

`split_server.py` is self-contained: the request parser, CRC-boundary splitter,
captured-exchange map, and TCP server all live in that one file (it loads only
itself + `lab_config.py` at runtime, and needs no pydnp3). To vary the split
granularity, edit `DEFAULT_BLOCKS_PER_CHUNK` / `DEFAULT_CHUNK_DELAY_MS` in
`lab_config.py`.

Before sending, the server asserts `b"".join(chunks) == response`; bytes are never
altered, only the TCP write boundaries change. It refuses to serve a captured
response to a request it cannot match (no blind byte dumping).

**Legacy single-shot** byte-split server (arbitrary `full`/`half`/`byte`/`fixed`/
`offsets` modes on one `--response` file) now lives separately:

```bash
python legacy_single_response_server.py \
  --response payloads/from_live/read_response_full.bin --split-mode fixed --fixed-size 40
```

## 12. Map DNP3 Fields

```bash
python map_response.py              # no args: uses lab_config defaults
# or override:
python map_response.py \
  --payload payloads/baseline/resp_0001.bin --output reports/field_map_results.md
```

Decodes the link header, header CRC (validated via `dnp3_crc.py`,
CRC-16/DNP), transport byte, application control/function/IIN, and the likely
first object-header offset.

## 13. Analyze TCP ACK Behavior

```bash
python analyze_ack.py               # no args: uses lab_config defaults
# or override:
python analyze_ack.py \
  --pcap captures/baseline/large_read.pcap \
  --master-ip <MASTER_IP> --outstation-ip <OUTSTATION_IP> --port 20000 \
  --output-csv reports/tcp_ack_details.csv --summary reports/tcp_ack_summary.csv
```

Reports pure vs piggybacked ACKs, request→ACK and request→response delays, and
TCP/IP fingerprint fields (options, window, TTL, IP ID, PSH).

## 14. What NOT To Do

- **Do not** send control commands (`DirectOperate`, `SelectAndOperate`,
  `Operate`, cold restart) in baseline experiments. Baseline is READ/RESPONSE
  only.
- **Do not** enable unsolicited responses for clean captures.
- **Do not** modify raw DNP3 bytes yet. First prove exact-byte replay and
  split replay work.
- **Do not** append random bytes as "padding". Real padding must be
  protocol-valid (dummy measurement objects, unconfigured indices,
  reserved/proprietary frames) — and only after replay/split is proven.
- **Do not** implement P4 in this phase.

## 15. How To Interpret Results

- **Baseline (small/large/range):** compare response payload length and the
  number of DNP3 application fragments / link frames / TCP segments as the
  database grows. Note whether OpenDNP3 itself splits large responses. Record in
  `reports/baseline_segmentation.md`.
- **Replay:** the master should decode a verbatim response identically to the
  live outstation; `received_request.bin` vs `sent_response.bin` confirm
  byte-for-byte fidelity. Record in `reports/replay_results.md`.
- **Split replay:** if the master decodes the response regardless of TCP write
  boundaries, the stream is robust to fragmentation — a prerequisite (not a
  substitute) for DNP3-aware splitting. Record in `reports/split_results.md`.
- **Field map:** confirms which header fields/offsets later splitting/padding
  logic must preserve and recompute (notably per-block CRCs).
- **TCP ACK analysis:** the pure/piggyback ACK ratio, timing, and TCP/IP
  options form a device response fingerprint. Record in
  `reports/tcp_ack_fingerprinting.md`.

## Live Results (Vision → Hulk)

Run on the real rig — Vision `10.10.54.19` (master) → Hulk `10.10.54.158` (slave),
management network, pydnp3 on Python 3.12 (pybind11 v2.13 swap). Full write-ups in
`reports/`:

- **Baseline segmentation** (`reports/baseline_segmentation.md`): one Class 0 read of a
  200+50+50-point DB → OpenDNP3 splits the response into **9 application fragments / 49 link
  frames (292 B max)**, delivered in **20 TCP segments (≤1448 B)**; DNP3 and TCP boundaries do
  not align. (Research Q2/Q3: yes, it segments at both layers.)
- **Exact replay** (`reports/replay_results.md`, Phase 6): the master **ingests and parses**
  verbatim replayed bytes (full transport reassembly, reads IIN, reacts to a stale restart
  IIN) but delivers **0 values** — DNP3 gates solicited data on a matching **application
  sequence number**. So a replayed/modified response must rewrite the app-control byte and
  recompute CRCs (research Q7).
- **Split replay** (`reports/split_results.md`, Phase 7): the same response sent as **902
  one-byte TCP writes** parses **identically** to the verbatim case — **TCP-boundary
  independence proven**. ✔ Prerequisite for any DNP3-aware work met.
- **Field map** (`reports/field_map_results.md`, Phase 8): real 292 B data frame decoded —
  CRC verified, transport FIR/FIN/seq, app-control (CON=1), RESPONSE, first object header.
- **TCP-ACK fingerprint** (`reports/tcp_ack_fingerprinting.md`, Phase 9): Hulk answers
  piggyback-ACK (9/9), ~0.24 ms ACK / ~1.0 ms response, options `NOP-NOP-Timestamp`.
- **Application-level acceptance** (`reports/request_aware_replay_results.md`): the Phase-6
  "0 values" gating was solved *without modifying any byte*. Replaying the captured responses
  in their captured order (request-aware / ordered) keeps the master on its captured
  trajectory, so its READ lands on the matching **app sequence**. The READ response is split
  into **141 CRC-boundary chunks** (byte-preserving) and the live master **accepts it,
  delivers 800 measurements, and sends a DNP3 CONFIRM**. Clean pcaps
  (`captures/replay/{ordered_rig,request_aware_rig,refactor_rig}.pcap`, 301 pkts, 0
  retransmits/resets). The replay server was refactored 2026-06-18 into small modules and
  re-validated on the rig with identical results.

## Order Of Operations

Exact replay (Phase 6), split replay (Phase 7), and **byte-preserving
application-level acceptance** (request-aware / ordered replay — master delivers
800 measurements and CONFIRMs) are all now demonstrated on the rig (see Live
Results). The current obfuscation primitive — CRC-boundary splitting — works
**without modifying any DNP3 byte**. Next, still within the no-byte-modification
rule: characterize the obfuscation envelope (split-aggressiveness sweep,
`blocks_per_chunk` / chunk delay), then decide whether to begin the in-network
proxy / true DNP3-aware modification phase (P4) — gated until explicitly started.
